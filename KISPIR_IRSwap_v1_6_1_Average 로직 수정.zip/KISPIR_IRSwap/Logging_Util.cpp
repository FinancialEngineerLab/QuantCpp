// Logging_Util v1.1.0 121114 �ڿ��� - int���� ����Լ� �߰�, �Լ� �̸����� 10->50����
// Logging_Util v1.2.0 121122 �ڿ��� - PrintTimeNow�Լ� �߰�,
// Logging_Util v1.3.0 130128 �ڿ��� - Vector��� �Լ� �߰�
// Logging_Util v1.3.1 130418 �ڿ��� - ���� ���� ���� ����ó�� �߰�
// Logging_Util v1.3.2 131122 �ڿ��� - ���ּҴ���100����
// Logging_Util v1.4.0 140519 �ڿ��� - KIS_Module_Log���� �Ʒ��� �����ϵ��� ����, C++���� ����

#include "Logging_Util.h"
#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <direct.h>
#include <sys/timeb.h>
//#include <vector>
#define LOGGING_VALUE_LENGTH			100

void LoggingData(const char *lpszFolder, const char *filename, const char *buf1)
{
	char *lpszFolder_Path = (char *)malloc( (strlen(lpszFolder)+25)*sizeof(char) );
	char *lpszPath = (char *)malloc( (strlen(lpszFolder)+strlen(filename)+25)*sizeof(char) );
	
	sprintf(lpszFolder_Path, "%s\\%s", "KIS_Module_Log", lpszFolder);
	sprintf(lpszPath, "%s\\%s", lpszFolder_Path, filename);
//	sprintf(lpszPath, "%s\\%s", lpszFolder, filename);

	_mkdir("KIS_Module_Log");
	_mkdir(lpszFolder_Path);
//	mkdir(lpsFolder,777);
//	char	lpszBuffer[100000];

	char *lpszBuffer = (char *)malloc( (strlen(buf1)+10)*sizeof(char) );
	strcpy(lpszBuffer, buf1);
	strcat(lpszBuffer, "\r\n");

	FILE *fp = fopen(lpszPath, "a+");
	{
		fputs(lpszBuffer, fp);
 		fclose(fp);
	}

	if(lpszFolder_Path) free(lpszFolder_Path);
	if(lpszPath) free(lpszPath);
	if(lpszBuffer) free(lpszBuffer);
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, double *dblValue)
{
	char *lpszBuffer = (char *)malloc( (LOGGING_VALUE_LENGTH*nSize+50) * sizeof(char) );
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[LOGGING_VALUE_LENGTH];
		sprintf(Temp, "%f", dblValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) free(lpszBuffer);
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, long *nValue)
{
	char *lpszBuffer = (char *)malloc( (LOGGING_VALUE_LENGTH*nSize+50)*sizeof(char) );
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[LOGGING_VALUE_LENGTH];
		sprintf(Temp, "%d", nValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);

	if(lpszBuffer) free(lpszBuffer);
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, int nSize, int *nValue)
{
	char *lpszBuffer = (char *)malloc( (LOGGING_VALUE_LENGTH*nSize+50)*sizeof(char) );
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[LOGGING_VALUE_LENGTH];
		sprintf(Temp, "%d", nValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) (lpszBuffer);
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, short nSize, short *nValue)
{
	char *lpszBuffer = (char *)malloc( (LOGGING_VALUE_LENGTH*nSize+50)*sizeof(char) );
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[LOGGING_VALUE_LENGTH];
		sprintf(Temp, "%d", nValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) free(lpszBuffer);
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, double dblValue)
{
	char lpszBuffer[2000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[LOGGING_VALUE_LENGTH];
	sprintf(Temp, "%f", dblValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, long nValue)
{
	char lpszBuffer[5000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[LOGGING_VALUE_LENGTH];
	sprintf(Temp, "%d", nValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, int nValue)
{
	char lpszBuffer[5000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[LOGGING_VALUE_LENGTH];
	sprintf(Temp, "%d", nValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, short nValue)
{
	char lpszBuffer[5000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[LOGGING_VALUE_LENGTH];
	sprintf(Temp, "%d", nValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}
/*
void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<short> VectorMember)
{
	int i;
	int nArraySize = VectorMember.size();
	if(nArraySize==0)
	{
		char lpszBuffer[5000];
		sprintf(lpszBuffer, "%s : Empty", lpszTitle);
		LoggingData(lpszFolder, filename, lpszBuffer);
	}
	else
	{
		short *ArrayMember = (short *)malloc(nArraySize*sizeof(short));

		for(i=0;i<nArraySize;i++)
		{
			ArrayMember[i] = VectorMember.at(i);
		}
	
		LoggingDataArray(lpszFolder, filename, lpszTitle, nArraySize, ArrayMember);
	
		if(ArrayMember) free(ArrayMember);
	}
}

void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<int> VectorMember)
{
	int i;
	int nArraySize = VectorMember.size();
	if(nArraySize==0)
	{
		char lpszBuffer[5000];
		sprintf(lpszBuffer, "%s : Empty", lpszTitle);
		LoggingData(lpszFolder, filename, lpszBuffer);
	}
	else
	{
		int *ArrayMember = (int *)malloc(nArraySize*sizeof(int));


		for(i=0;i<nArraySize;i++)
		{
			ArrayMember[i] = VectorMember.at(i);
		}
	
		LoggingDataArray(lpszFolder, filename, lpszTitle, nArraySize, ArrayMember);
	
		if(ArrayMember) free(ArrayMember);
	}
}

void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<long> VectorMember)
{
	int i;
	int nArraySize = VectorMember.size();
	if(nArraySize==0)
	{
		char lpszBuffer[5000];
		sprintf(lpszBuffer, "%s : Empty", lpszTitle);
		LoggingData(lpszFolder, filename, lpszBuffer);
	}
	else
	{
		long *ArrayMember = (long *)malloc(nArraySize*sizeof(long));

		for(i=0;i<nArraySize;i++)
		{
			ArrayMember[i] = VectorMember.at(i);
		}
	
		LoggingDataArray(lpszFolder, filename, lpszTitle, nArraySize, ArrayMember);
	
		if(ArrayMember) free(ArrayMember);
	}
}

void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<double> VectorMember)
{
	int i;
	int nArraySize = VectorMember.size();
	if(nArraySize==0)
	{
		char lpszBuffer[5000];
		sprintf(lpszBuffer, "%s : Empty", lpszTitle);
		LoggingData(lpszFolder, filename, lpszBuffer);
	}
	else
	{
		double *ArrayMember = (double *)malloc(nArraySize*sizeof(double));

		for(i=0;i<nArraySize;i++)
		{
			ArrayMember[i] = VectorMember.at(i);
		}
	
		LoggingDataArray(lpszFolder, filename, lpszTitle, nArraySize, ArrayMember);
	
		if(ArrayMember) free(ArrayMember);
	}
}
*/
void get_filename( char *filename, char *modulename )
{
	struct _timeb tb;
	struct tm st_time;
	char buff[100];
	char milsec[4];

	_ftime(&tb);
	st_time = *localtime(&tb.time);

	strftime(buff, 100, "_%Y%m%d__%H_%M_%S_", &st_time);
	sprintf(milsec, "%d", tb.millitm);

	strcpy(filename, modulename);
	strcat(filename, buff);
	strcat(filename, milsec);
	strcat(filename, ".txt");
}

void PrintTimeNow(char *szLoggingName, char *szFileName, char *szModuleName)
{
	struct _timeb tb;
	struct tm st_time;
	char buff[100];
	char szOutString[200];
	char milsec[4];

	_ftime(&tb);
	st_time = *localtime(&tb.time);

	strftime(buff, 100, "%Y%m%d__%H:%M:%S_", &st_time);
	sprintf(milsec, "%d", tb.millitm);

	sprintf(szOutString, "%s : ", szLoggingName);
	strcat(szOutString, buff);
	strcat(szOutString, milsec);
	
	LoggingData(szModuleName, szFileName, szOutString);
}