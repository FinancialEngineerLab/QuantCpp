// Logging_Util v1.1.0 121114 �ڿ��� - int���� ����Լ� �߰�, �Լ� �̸����� 10->50����
// Logging_Util v1.2.0 121122 �ڿ��� - PrintTimeNow�Լ� �߰�,
// Logging_Util v1.3.0 130128 �ڿ��� - Vector��� �Լ� �߰�
// Logging_Util v1.3.1 130418 �ڿ��� - ���� ���� ���� ����ó�� �߰�

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif _CRT_SECURE_NO_WARNINGS

//#include <vector>

void LoggingData(const char *lpszFolder, const char *filename, const char *buf1);

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, double *dblValue);
void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, long *nValue);
void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, int nSize, int *nValue);
void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, short nSize, short *nValue);

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, double dblValue);
void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, long nValue);
void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, int nValue);
void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, short nValue);

//void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<short> VectorMember);
//void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<int> VectorMember);
//void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<long> VectorMember);
//void LoggingVector(char *lpszFolder, char *filename, char *lpszTitle, std::vector<double> VectorMember);

void get_filename( char *filename, char *modulename );
void PrintTimeNow(char *szLoggingName, char *szFileName, char *szModuleName);