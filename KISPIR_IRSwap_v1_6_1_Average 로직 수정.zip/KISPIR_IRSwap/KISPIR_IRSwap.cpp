// KISPIR_IRSwap.cpp : DLL ���� ���α׷��� ���� ������ �Լ��� �����մϴ�.
//

#include "stdafx.h"
#include <math.h>
#include <stdlib.h>
#include "TransDate.h"
#include "IR_Util.h"
#include "Logging_Util.h"
#include "ErrorCode.h"
#include <string.h>

#ifndef DLLEXPORT(A)
#ifdef WIN32
#define DLLEXPORT(A) extern "C" __declspec(dllexport) A _stdcall
#elif _WIN64
#define DLLEXPORT(A) extern "C" __declspec(dllexport) A _stdcall
#elif __linux__
#define DLLEXPORT(A) extern "C" A
#elif __hpux
#define DLLEXPORT(A) extern "C" A
#elif __unix__
#define DLLEXPORT(A) extern "C" A
#else
#define DLLEXPORT(A) extern "C" __declspec(dllexport) A _stdcall
#endif
#endif 

long sumation(long* array, long narray)
{
	long i;
	long s = 0;
	for (i = 0; i < narray; i++)
	{
		s += array[i];
	}
	return s;
}

double sumation(double* array, long narray)
{
	long i;
	double s = 0;
	for (i = 0; i < narray; i++)
	{
		s += array[i];
	}
	return s;
}

long isin(long x, long* array, long narray)
{
	long i;
	long s = 0;
	for (i = 0; i < narray; i++)
	{
		if (x == array[i])
		{
			s = 1;
			break;
		}
	}
	return s;
}

long isin(long x, long* array, long narray, long& startidx)
{
	long i;
	long s = 0;
	for (i= startidx; i < narray; i++)
	{
		if (x == array[i])
		{
			s = 1;
			startidx = i;
			break;
		}
	}
	return s;
}

long isinfindindex(long x, long *array, long narray)
{
	long i;
	for (i = 0 ; i < narray; i++)
	{
		if (x == array[i])
		{
			return i;
		}
	}
	return -1;
}

long SaveErrorName(char* Error, char* ErrorName)
{
	char ErrorNameTemp[100];
	strcpy_s(ErrorNameTemp, ErrorName);
	long k;
	long i;
	long Ascii;
	k = 0;
	for (i = 0; i < 100; i++)
	{
		Ascii = (long)ErrorNameTemp[i];
		if ((Ascii >= 48 && Ascii <= 57) || (Ascii >= 65 && Ascii <= 90) || (Ascii >= 97 && Ascii <= 122) || (Ascii == 32) || (Ascii == 95))
		{
			Error[k] = ErrorNameTemp[i];
			k++;
		}
		else
		{
			break;
		}
	}
	return -1;
}

long isweekend(long ExlDate)
{
	// ������ 1�̸� �Ͽ���, 2�̸� ������, 3�̸� ȭ����, 4�̸� ������, 5�̸� �����, 6�̸� �ݿ���, 0�̸� �����
	long MOD7 ;
	if (ExlDate > 0)
	{
		MOD7 = ExlDate%7;
		if (MOD7 == 1 || MOD7 == 0) return 1;
	}
	return 0;
}

double Calc_Forward_Rate_Daily(
	double* Term, 
	double* Rate, 
	long LengthArray,  
	double T1,         
	long* TimePos
)
{
	long i;
	long startidx = *TimePos + 0;
	double dt = 0.00273972602739726; // 1/365 �� ��
	double T2 = T1 + dt;
	double r1, r2;
	double DF1, DF2, FRate;

	if (T1 <= Term[0]) r1 = Rate[0];
	else if (T1 >= Term[LengthArray - 1]) r1 = Rate[LengthArray - 1]; // �糡���̸� �� �� �״�� ���
	else
	{
		for (i = max(1, startidx); i < LengthArray; i++)
		{
			if (T1 < Term[i])
			{
				*TimePos = i - 1;
				r1 = (Rate[i] - Rate[i - 1]) / (Term[i] - Term[i - 1]) * (T1 - Term[i - 1]) + Rate[i - 1];
				break;
			}
		}
	}

	if (T2 <= Term[0]) r2 = Rate[0];
	else if (T2 >= Term[LengthArray - 1]) r2 = Rate[LengthArray - 1];
	else
	{
		for (i = max(1, startidx); i < LengthArray; i++)
		{
			if (T2 < Term[i])
			{
				r2 = (Rate[i] - Rate[i - 1]) / (Term[i] - Term[i - 1]) * (T2 - Term[i - 1]) + Rate[i - 1];
				break;
			}
		}
	}

	DF1 = exp(-r1 * T1);
	DF2 = exp(-r2 * T2);
	FRate = 1.0 / dt * (DF1 / DF2 - 1.0);
	return FRate;
}

double Calc_Forward_Rate_Daily(
	double* Term, 
	double* Rate, 
	long LengthArray,  
	double T1,         
	long* TimePos,
	long NHoliday
)
{
	long i;
	long startidx = *TimePos + 0;
	double dt = 0.00273972602739726;
	double T2 = T1 + ((double)(NHoliday + 1)) * dt; // ���ϸ�ŭ dt�߰�.
	double r1, r2;
	double DeltaT = T2 - T1;
	double DF1, DF2, FRate;

	if (T1 <= Term[0]) r1 = Rate[0];
	else if (T1 >= Term[LengthArray - 1]) r1 = Rate[LengthArray - 1];
	else
	{
		for (i = max(1, startidx); i < LengthArray; i++)
		{
			if (T1 < Term[i])
			{
				*TimePos = i - 1;
				r1 = (Rate[i] - Rate[i - 1]) / (Term[i] - Term[i - 1]) * (T1 - Term[i - 1]) + Rate[i - 1];
				break;
			}
		}
	}

	if (T2 <= Term[0]) r2 = Rate[0];
	else if (T2 >= Term[LengthArray - 1]) r2 = Rate[LengthArray - 1];
	else
	{
		for (i = max(1, startidx); i < LengthArray; i++)
		{
			if (T2 < Term[i])
			{
				r2 = (Rate[i] - Rate[i - 1]) / (Term[i] - Term[i - 1]) * (T2 - Term[i - 1]) + Rate[i - 1];
				break;
			}
		}
	}

	DF1 = exp(-r1 * T1);
	DF2 = exp(-r2 * T2);
	FRate = 1.0 / DeltaT * (DF1 / DF2 - 1.0);
	return FRate;
}

double Calc_Forward_Rate_Daily_Cubic(
	double* Term,
	double* Rate,
	double* C_Array,
	long nRate,
	double T1,
	long* TimePos
	)
{
	long i;
	long startidx = *TimePos + 0;
	double dt = 0.00273972602739726;
	double T2 = T1 + dt;
	double r1, r2;
	double DF1, DF2, FRate;
	double hi, xp, a, b, d;

	if (T1 <= Term[0]) r1 = Rate[0];
	else if (T1 >= Term[nRate - 1]) r1 = Rate[nRate - 1];
	else
	{
		for (i = max(1, startidx); i < nRate; i++)
		{
			if (Term[i] > T1) {
				*TimePos = i - 1;
				hi = Term[i] - Term[i - 1];
				xp = T1 - Term[i - 1];
				a = Rate[i - 1];
				b = (Rate[i] - Rate[i - 1]) / hi - hi * (2.0 * C_Array[i - 1] + C_Array[i]) / 3.0;
				d = (C_Array[i] - C_Array[i - 1]) / (3.0 * hi);
				r1 = a + b * xp + C_Array[i - 1] * xp * xp + d * xp * xp * xp;
				break;
			}
		}
	}

	if (T2 <= Term[0]) r2 = Rate[0];
	else if (T2 >= Term[nRate - 1]) r2 = Rate[nRate - 1];
	else
	{
		for (i = max(1, startidx); i < nRate; i++)
		{
			if (Term[i] > T2) {
				hi = Term[i] - Term[i - 1];
				xp = T2 - Term[i - 1];
				a = Rate[i - 1];
				b = (Rate[i] - Rate[i - 1]) / hi - hi * (2.0 * C_Array[i - 1] + C_Array[i]) / 3.0;
				d = (C_Array[i] - C_Array[i - 1]) / (3.0 * hi);
				r2 = a + b * xp + C_Array[i - 1] * xp * xp + d * xp * xp * xp;
				break;
			}
		}
	}

	DF1 = exp(-r1 * T1);
	DF2 = exp(-r2 * T2);
	FRate = 1.0/dt * (DF1/DF2 - 1.0);
	return FRate;
}

double Calc_Forward_Rate_Daily_Cubic(
	double* Term,
	double* Rate,
	double* C_Array,
	long nRate,
	double T1,
	long* TimePos,
	long NHoliday
	)
{
	long i;
	long startidx = *TimePos + 0;
	double dt = 0.00273972602739726;
	double T2 = T1 + ((double)(NHoliday + 1)) * dt;
	double r1, r2;
	double DF1, DF2, FRate;
	double DeltaT = T2 - T1;
	double hi, xp, a, b, d;

	if (T1 <= Term[0]) r1 = Rate[0];
	else if (T1 >= Term[nRate - 1]) r1 = Rate[nRate - 1];
	else
	{
		for (i = max(1, startidx); i < nRate; i++)
		{
			if (Term[i] > T1) {
				*TimePos = i - 1;
				hi = Term[i] - Term[i - 1];
				xp = T1 - Term[i - 1];
				a = Rate[i - 1];
				b = (Rate[i] - Rate[i - 1]) / hi - hi * (2.0 * C_Array[i - 1] + C_Array[i]) / 3.0;
				d = (C_Array[i] - C_Array[i - 1]) / (3.0 * hi);
				r1 = a + b * xp + C_Array[i - 1] * xp * xp + d * xp * xp * xp;
				break;
			}
		}
	}

	if (T2 <= Term[0]) r2 = Rate[0];
	else if (T2 >= Term[nRate - 1]) r2 = Rate[nRate - 1];
	else
	{
		for (i = max(1, startidx); i < nRate; i++)
		{
			if (Term[i] > T2) {
				hi = Term[i] - Term[i - 1];
				xp = T2 - Term[i - 1];
				a = Rate[i - 1];
				b = (Rate[i] - Rate[i - 1]) / hi - hi * (2.0 * C_Array[i - 1] + C_Array[i]) / 3.0;
				d = (C_Array[i] - C_Array[i - 1]) / (3.0 * hi);
				r2 = a + b * xp + C_Array[i - 1] * xp * xp + d * xp * xp * xp;
				break;
			}
		}
	}

	DF1 = exp(-r1 * T1);
	DF2 = exp(-r2 * T2);
	FRate = 1.0/DeltaT * (DF1/DF2 - 1.0);
	return FRate;
}

void LockOutCheck(long& LockOutFlag, long LockOutDay, long Today, double& LockOutDayRate, double& ForwardRate)
{
    if (LockOutFlag == 1) ForwardRate = LockOutDayRate + 0.0;
    else
    {
        if (LockOutDay <= Today)
        {
            LockOutDayRate = ForwardRate + 0.0;
            LockOutFlag = 1;
        }
    }
}

double SOFR_ForwardRate_Compound(
	long NRefCrvTerm,	
	double* RefCrvTerm,		
	double* RefCrvRate,	
	double* C_Array,
	long ForwardStartIdx,		
	long ForwardEndIdx,		
	long ForwardStartExlDate,
	long ForwardEndExlDate,
	long LockOutDays,		
	long LookBackDays,		
	long ObservShift,		
	long HolidayFlag,	// 0: Forward Fill Holi 1: BackWard Fill Holi 2: Interp Holi
	long NHoliday,		
	long *Holiday,		
	long NSaturSunDay,
	long *SaturSunDay,
	long UseHistorySOFR,			
	long NRefHistory,		
	long *RefHistoryDate,			
	double *RefHistory,	
	double denominator,
	double& AnnualizedOISRate,
	long DailyLoggingFlag,
	long InterpolateFlag,
	long SOFRUseFlag,
	char *szModuleName,				
	char *szFileName)
{
	long i;
	long j;
	long k;
	long n;
	long nday = ForwardEndIdx - ForwardStartIdx; // ��¥ ������ ���� Count

	long HistDayIdx = 0;
	long AverageFlag = 0;
	if (SOFRUseFlag == 3) AverageFlag = 1;

	// ���� Holidayã��� TimePos Pointer
	long HoliStartIdx = 0;
	long HoliStartIdx2 = 0;
	long SatSunIdx = 0;
	long SatSunIdx2 = 0;
	long ExlDate = ForwardStartExlDate;

	long isHolidayFlag = 0;
	long isHolidayFlag2 = 0;

	long CountHoliday = 0;
	long CountHoliday2 = 0;

	long TimePos = 0;
	long TimePos2 = 0;

	double dt = 1.0 / 365.0;
	double Prev_PI;
	double ForwardRate;

	double t = 0.0;
	double PI_0;
	double T;
	T = (double)(ForwardEndIdx - ForwardStartIdx)/denominator;

	double DataForLogging[5] = {0.0,0.0,0.0,0.0,0.0};

	double CurrentRate ;
	if (InterpolateFlag == 0) CurrentRate = Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm,dt );
	else CurrentRate = CubicInterpolation(NRefCrvTerm, RefCrvTerm, RefCrvRate, C_Array, dt); // Ȥ�� ���� Interpolate�� �ٸ� ���� �����, ���⸦ �ٲ�� ��.

	long ObservShiftFlag = 0;
	if (LookBackDays > 0 && ObservShift > 0) 	ObservShiftFlag = 1;


	///////////////////////////
	// Average Ű������ �߰� //
	///////////////////////////
	long NCumpound = 0;
	double AverageRate = 0.0;

	////////////////////////////////
	// N������ �� LockOutDay ��� //
	////////////////////////////////
	long LockOutDay = ForwardEndIdx;
	long LockOutFlag = 0;

	if (LockOutDays > 0)
	{
		k = 0;
		for (i = 1; i < 30; i++)
		{
			LockOutDay -= 1;
			// N�����ϱ��� ��¥ �ڷΰ��� ( ������ �ִ��� ������ Ȯ��, ������ ������ �ִ� ������ŭ k ���� )
			if (max(isin(LockOutDay, Holiday, NHoliday),isin(LockOutDay, SaturSunDay,NSaturSunDay)) == 0) k += 1;
			if (k == LockOutDays) break; // LockOutDays
		}
	}
	double LockOutDayRate = 0.0;


	///////////////////////////
	// Holiday Rate�� Interpolate�� �� ����� ����
	///////////////////////////
	double TargetRate[2] = { 0.0,0.0 };
	double TargetT[2] = { 0.0,0.0 };

	long lookbackday;
	Prev_PI = 1.0;
	PI_0 = 1.0;
	if (UseHistorySOFR == 1 && ObservShiftFlag == 0)
	{
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Forward Start ��¥�� ���� ����Ϻ��� �տ� ���� ��� History Rate ���������� + Observe Shift ���� ���ϴ� ��� //
		//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		HistDayIdx = 0;
		if (LookBackDays < 1)
		{
			////////////////////////////
			// LookBack ������� ��� //
			////////////////////////////
			if (ForwardEndIdx >= 0)
			{
				if (HolidayFlag == 3) // ������
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						HistDayIdx = isinfindindex(i, RefHistoryDate, NRefHistory);

						if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
						else ForwardRate = CurrentRate;

						Prev_PI *= 1.0 + ForwardRate * 1.0/denominator;
						AverageRate += ForwardRate;

						if (ExlDate>0)
						{
							DataForLogging[0] = (double)ExlDate;
							DataForLogging[4] = (double)ExlDate;
						}
						else
						{
							DataForLogging[0] = (double)i;
							DataForLogging[4] = (double)i;
						}
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0;
						DataForLogging[3] = Prev_PI;
						
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
						if (ExlDate >0) ExlDate +=1;
						NCumpound +=1;
					}
				}
				else if (HolidayFlag == 0) // Forward
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						if (i == ForwardStartIdx) isHolidayFlag = 0; // ù���� ���� �Ǵ� X.. 
						else isHolidayFlag = max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay)); // i��° �ϼ��� �������� �Ǵ�

						if (isHolidayFlag == 0) // ������ �ƴ� ���,
						{
							HistDayIdx = isinfindindex(i, RefHistoryDate, NRefHistory);

							if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;

							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = i + 1; j < 0; j++)
							{
								isHolidayFlag2 = max(isin(j, Holiday, NHoliday, HoliStartIdx), isin(j, SaturSunDay, NSaturSunDay,SatSunIdx));
								if (isHolidayFlag2 == 0) break;
								else 
								{
									CountHoliday += 1;
								}
							}
							Prev_PI *= 1.0 + ForwardRate * (1.0 + (double)CountHoliday)/denominator;
							AverageRate += ForwardRate; // Ȥ�� ����� CountHoliday�� ������ �ʾƵ� ��� ����??

							if (ExlDate >0) 
							{
								DataForLogging[0] = (double)ExlDate;
								DataForLogging[4] = (double)ExlDate;
							}
							else
							{
								DataForLogging[0] = (double)i;
								DataForLogging[4] = (double)i;
							}
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0 + (double)CountHoliday;
							DataForLogging[3] = Prev_PI;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
							NCumpound += 1;
						}
						if (ExlDate>0) ExlDate +=1;
					}
				}
				else if (HolidayFlag == 1) // Backward
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						if (i == ForwardStartIdx) isHolidayFlag = 0;
						else isHolidayFlag = max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay));
						
						if (isHolidayFlag == 0)
						{
							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = i + 1; j < ForwardEndIdx; j++)
							{
								isHolidayFlag2 = max(isin(j, Holiday, NHoliday, HoliStartIdx), isin(j, SaturSunDay, NSaturSunDay,SatSunIdx));
								if (isHolidayFlag2 == 0) break; // ����ã�� �ý���
								else 
								{
									CountHoliday += 1;
								}
							}
							HistDayIdx = isinfindindex(i + CountHoliday + 1, RefHistoryDate, NRefHistory); // ���� ������ ã�� �ý���

							if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx]; // ���ſ��� ã������ ����
							else ForwardRate = CurrentRate; // ��ã������ ���� ������ ����,, �ٵ� HistDayIdx=0 ���� �ʱ�ȭ�ϴµ�, �׷� �׻� ã�� �ɷ� �Ǿ�����°� �ƴѰ� �ͱ⵵ �ϰ�
															// ������� 2021-11-09 �϶�, History�� 2021-11-09 ��¥�� �ԷµǾ��ִ��� �ƴ����� Ȯ���ϴ� �� ������,

							Prev_PI *= 1.0 + ForwardRate * (1.0 + (double)CountHoliday)/denominator;
							AverageRate += ForwardRate;

							if (ExlDate >0)
							{
								DataForLogging[0] = (double)ExlDate;
								DataForLogging[4] = (double)ExlDate;
							}
							else 
							{
								DataForLogging[0] = (double)i;
								DataForLogging[4] = (double)i;
							}
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0 + (double)CountHoliday;
							DataForLogging[3] = Prev_PI;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
							NCumpound += 1;
						}
						if (ExlDate >0) ExlDate += 1;
					}
				}
				if (HolidayFlag == 2) // Interpolate
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						if (i == ForwardStartIdx) isHolidayFlag = 0;
						else isHolidayFlag = max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay));

						if (isHolidayFlag == 0)
						{
							///////////////////////////////
							// �������� ��� ���� ������ //
							///////////////////////////////
							HistDayIdx = isinfindindex(i, RefHistoryDate, NRefHistory);
							if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;
							CountHoliday = 0;
						}
						else if (isHolidayFlag == 1 && NRefHistory > 0)
						{
							///////////////////////////////////////////////////////////
							// �������� �ƴ� ��� ����, ���� ������ ForwardRate ã�� //
							///////////////////////////////////////////////////////////

							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = j - 1; j < ForwardStartIdx; j--)
							{
								isHolidayFlag2 = max(isin(j, Holiday, NHoliday, HoliStartIdx), isin(j, SaturSunDay, NSaturSunDay,SatSunIdx));
								if (isHolidayFlag2 == 0) break;
								else 
								{
									CountHoliday += 1;
								}
							}
							HistDayIdx = isinfindindex(i - CountHoliday - 1, RefHistoryDate, NRefHistory);
							if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;							

							TargetRate[0] = ForwardRate;
							TargetT[0] = (-(double)(CountHoliday)-1.0) ;

							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = i + 1; j < ForwardEndIdx; j++)
							{
								isHolidayFlag2 = max(isin(j, Holiday, NHoliday, HoliStartIdx), isin(j, SaturSunDay, NSaturSunDay,SatSunIdx));
								if (isHolidayFlag2 == 0) break;
								else 
								{
									CountHoliday += 1;
								}

							}
							HistDayIdx = isinfindindex(i + CountHoliday + 1, RefHistoryDate, NRefHistory);
							if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;

							TargetRate[1] = ForwardRate;
							TargetT[1] = ((double)(CountHoliday)+1.0) ;
							ForwardRate = Linear_Interpolation_1D(TargetT, TargetRate, 2, 0.0);
						}
						else ForwardRate = CurrentRate;

						Prev_PI *= 1.0 + ForwardRate * 1.0/denominator;
						AverageRate += ForwardRate;

						if (ExlDate >0)
						{
							DataForLogging[0] = (double)ExlDate;
							DataForLogging[4] = (double)ExlDate;
						}
						else
						{
							DataForLogging[0] = (double)i;
							DataForLogging[4] = (double)i;
						}
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0;
						DataForLogging[3] = Prev_PI;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
						if (ExlDate>0) ExlDate += 1;
						NCumpound += 1;
					}
				}
			}
			////////////////////////////////////////////////////////
			// ���� �ݿ� �� �������� ForwardStartIdx 0���� �ٲٱ� //
			////////////////////////////////////////////////////////
			ExlDate = ForwardStartExlDate + (0 - ForwardStartIdx);
			ForwardStartIdx = 0;
		}
		else if (LookBackDays > 0)
		{
			//////////////////////////
			// LookBack ������ ��� //
			//////////////////////////
			if (ForwardEndIdx >= 0)
			{
				if (HolidayFlag == 3)
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						lookbackday = i;

						k = 0;

						for (n = 1; n < 120; n++)
						{
							///////////////////////////
							// N������ �� LookBackDay ���
							///////////////////////////
							lookbackday -= 1; // lookbackday �� ��¥�� �� ����.
							if ( max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday,SaturSunDay, NSaturSunDay)) == 0 ) k += 1; // k= ���ϰ���??
							if (k == LookBackDays) break;
						}	
						HistDayIdx = isinfindindex(lookbackday, RefHistoryDate, NRefHistory);
						if (HistDayIdx >= 0) ForwardRate =  RefHistory[HistDayIdx];
						else ForwardRate = CurrentRate;
						Prev_PI *= 1.0 + ForwardRate * 1.0/denominator;
						AverageRate += ForwardRate;

						if (ExlDate >0)
						{
							DataForLogging[0] = (double)ExlDate;
							DataForLogging[4] = (double)lookbackday;
						}
						else 
						{
							DataForLogging[0] = (double)i;
							DataForLogging[4] = (double)lookbackday;
						}
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0;
						DataForLogging[3] = Prev_PI;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
						if (ExlDate >0) ExlDate += 1;
						NCumpound += 1;
					}
				}
				else if (HolidayFlag == 0)
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						if (i == ForwardStartIdx) isHolidayFlag = 0 ;
						else isHolidayFlag = max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay));

						if (isHolidayFlag == 0)
						{
							lookbackday = i;

							k = 0;

							for (n = 1; n < 120; n++)
							{
								///////////////////////////
								// N������ �� LookBackDay ���
								///////////////////////////
								lookbackday -= 1;

								if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay) ) == 0) k += 1;
								if (k == LookBackDays) break;
							}	
							HistDayIdx = isinfindindex(lookbackday, RefHistoryDate, NRefHistory);
							if (HistDayIdx >= 0) ForwardRate =  RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;

							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = i + 1; j < ForwardEndIdx; j++)
							{
								isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx),isin(j , SaturSunDay, NSaturSunDay, SatSunIdx));
								if (isHolidayFlag2 == 0) break;
								else
								{
									CountHoliday += 1;
								}

							}
							Prev_PI *= 1.0 + ForwardRate * (1.0 + (double)CountHoliday)/denominator;
							AverageRate += ForwardRate;

							if (ExlDate >0)
							{
								DataForLogging[0] = (double)ExlDate;
								DataForLogging[4] = (double)(lookbackday);
							}
							else 
							{
								DataForLogging[0] = (double)i;
								DataForLogging[4] = (double)lookbackday;
							}
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0 + (double)CountHoliday;
							DataForLogging[3] = Prev_PI;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
							NCumpound += 1;
						}
						if (ExlDate>0) ExlDate += 1;
					}
				}
				else if (HolidayFlag == 1)
				{
					for (i = ForwardStartIdx; i < 0; i++)
					{
						if (i == ForwardStartIdx) isHolidayFlag = 0;
						else isHolidayFlag =  max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay));
						
						if (isHolidayFlag == 0)
						{
							CountHoliday = 0;
							HoliStartIdx = 0;
							SatSunIdx = 0;

							for (j = i + 1; j < ForwardEndIdx; j++)
							{
								isHolidayFlag2 =max(isin(j , Holiday, NHoliday, HoliStartIdx),isin(j , SaturSunDay, NSaturSunDay, SatSunIdx));
								if (isHolidayFlag2 == 0) break;
								else
								{
									CountHoliday += 1;
								}
							}

							if (CountHoliday == 0) 
							{
								lookbackday = i;
							}
							else
							{
								lookbackday = i + CountHoliday + 1;
							}

							k = 0;
							for (n = 1; n < 120; n++)
							{
								///////////////////////////
								// N������ �� LookBackDay ���
								///////////////////////////
								lookbackday -= 1;
								if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay) ) == 0) k += 1;
								if (k == LookBackDays) break;
							}	
							HistDayIdx = isinfindindex(lookbackday, RefHistoryDate, NRefHistory);
							if (HistDayIdx >= 0) ForwardRate =  RefHistory[HistDayIdx];
							else ForwardRate = CurrentRate;

							Prev_PI *= 1.0 + ForwardRate * (1.0 + (double)CountHoliday)/denominator;
							AverageRate += ForwardRate;

							if (ExlDate >0)
							{
								DataForLogging[0] = (double)ExlDate;
								DataForLogging[4] = (double)(lookbackday);
							}
							else 
							{
								DataForLogging[0] = (double)i;
								DataForLogging[4] = (double)lookbackday;
							}
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0 + (double)CountHoliday;
							DataForLogging[3] = Prev_PI;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
							NCumpound += 1;
						}
						if (ExlDate>0) ExlDate +=1;
					}
				}
			}
			ExlDate = ForwardStartExlDate + (0 - ForwardStartIdx);
			ForwardStartIdx = 0;
		}
	}
	else if (UseHistorySOFR == 1 && ObservShiftFlag == 1)
	{
		///////////////////////////
		// Forward Start ��¥�� ���� ����Ϻ��� �տ� ���� ���
		// ���� ObservShift�� �ִ� ���
		///////////////////////////
		HistDayIdx = 0;
		if (ForwardEndIdx >= 0)
		{
			for (i = ForwardStartIdx; i < 0; i++)
			{
				lookbackday = i;
				isHolidayFlag =  max(isin(i, Holiday, NHoliday), isin(i, SaturSunDay,NSaturSunDay));

				if (isHolidayFlag == 0)
				{
					//////////////////
					// Holiday�� �ƴ϶�� LookBack������ Back
					//////////////////

					k = 0;
					if (LookBackDays > 0)
					{
						for (n = 1; n < 120; n++)
						{
							lookbackday -= 1;
							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
					}
					HistDayIdx = isinfindindex(lookbackday, RefHistoryDate, NRefHistory);
					if (HistDayIdx >= 0) ForwardRate =  RefHistory[HistDayIdx];
					else ForwardRate = Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm,dt );

					///////////////////////////
					// Observation Dt ���
					///////////////////////////
					CountHoliday = 0;
					HoliStartIdx = 0;
					SatSunIdx = 0;

					for (j = lookbackday + 1; j < 0; j++)
					{
						isHolidayFlag2 =max(isin(j , Holiday, NHoliday, HoliStartIdx),isin(j , SaturSunDay, NSaturSunDay, SatSunIdx));
						if (isHolidayFlag2 == 0) break;
						else CountHoliday += 1;
					}

					if (CountHoliday == 0) Prev_PI *= 1.0 + ForwardRate * 1.0/denominator;
					else Prev_PI *= 1.0 + ForwardRate * ((double)(1 + CountHoliday)/denominator); 
					AverageRate += ForwardRate;

					if (ExlDate >0)
					{
						DataForLogging[0] = (double)ExlDate;
						DataForLogging[4] = (double)(lookbackday);
					}
					else
					{
						DataForLogging[0] = (double)i;
						DataForLogging[4] = (double)lookbackday;
					}
					DataForLogging[1] = ForwardRate;
					DataForLogging[2] = 1.0 + (double)CountHoliday;
					DataForLogging[3] = Prev_PI;
					if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
					NCumpound += 1;
				}
				if (ExlDate >0) ExlDate += 1;
			}
		}
		ExlDate = ForwardStartExlDate + (0 - ForwardStartIdx);
		ForwardStartIdx = 0;
	}

	PI_0 = Prev_PI;
	HoliStartIdx = 0;
	HoliStartIdx2 = 0;
	TimePos = 0;
	TimePos2 = 0;
	LockOutFlag = 0;
	NCumpound = 0;
	SatSunIdx = 0;
	SatSunIdx2 = 0;

	if (ObservShiftFlag == 0)
	{
		if (HolidayFlag == 0)
		{
			//////////////////
			// HolidayRate Forward Fill
			//////////////////
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				//////////////////////////
				// ù ���� �����Ϸ� ó��
				//////////////////////////
				if (i == ForwardStartIdx) 
				{
					if (UseHistorySOFR == 0) isHolidayFlag = 0;
					else isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));
				}
				else isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					lookbackday = i + 0;

					////////////////////
					// Forward Rate Time ���� LookBack �ݿ�
					////////////////////
					if (LookBackDays < 1) t = ((double)i)/denominator;
					else
					{
						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -= 1;

							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}

					////////////////////
					// �ش��� ���� Holiday���� üũ�Ͽ� dt����
					////////////////////
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;
					for (j = i + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else
						{
							CountHoliday += 1;
						}
					}
					
					if (CountHoliday == 0)
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);
					}
					else
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos,CountHoliday);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos,CountHoliday);
					}

					LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

					PI_0 *= (1.0 + ForwardRate * (1.0 + (double)CountHoliday)  /denominator);
					AverageRate += ForwardRate;

					if (ExlDate > 0)
					{
						DataForLogging[0] = (double)ExlDate;
						DataForLogging[4] = (double)lookbackday;
					}
					else
					{
						DataForLogging[0] = (double)i;
						DataForLogging[4] = (double)lookbackday;
					}
					DataForLogging[1] = ForwardRate;
					DataForLogging[2] = 1.0 + (double)CountHoliday;
					DataForLogging[3] = PI_0;
					if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
					NCumpound += 1;
				}
				if (ExlDate > 0) ExlDate += 1;
			}
		}
		else if (HolidayFlag == 1)
		{
			//////////////////
			// HolidayRate Backward Fill
			//////////////////
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				//////////////////////////
				// ù ���� �����Ϸ� ó��
				//////////////////////////
				if (i == ForwardStartIdx) 
				{
					if (UseHistorySOFR == 0) isHolidayFlag = 0;
					else isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));
				}
				else isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					////////////////////
					// �ش��� ���� Holiday���� üũ�Ͽ� dt����
					////////////////////
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					for (j = i + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else 
						{
							CountHoliday += 1;
						}
					}

					if (CountHoliday == 0) 
					{
						lookbackday = i + 0;
					}
					else
					{
						lookbackday = i + CountHoliday + 1;
					}

					////////////////////
					// Forward Rate Time ���� LookBack �ݿ�
					////////////////////
					if (LookBackDays < 1) t = ((double)lookbackday)/denominator;
					else
					{
						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -= 1;

							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}

					CountHoliday2 = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					for (j = lookbackday + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else 
						{
							CountHoliday2 += 1;
						}
					}

					if (CountHoliday2 == 0)
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);
					}
					else
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos,CountHoliday2);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos,CountHoliday2);
					}

					LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

					PI_0 *= (1.0+ ForwardRate * (1.0 + (double)CountHoliday) /denominator);
					AverageRate += ForwardRate;

					if (ExlDate > 0)
					{
						DataForLogging[0] = (double)ExlDate;
						DataForLogging[4] = (double)lookbackday;
					}
					else
					{
						DataForLogging[0] = (double)i;
						DataForLogging[4] = (double)lookbackday;
					}
					DataForLogging[1] = ForwardRate;
					DataForLogging[2] = 1.0 + (double)CountHoliday;
					DataForLogging[3] = PI_0;
					if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
					NCumpound += 1;
				}
				if (ExlDate > 0) ExlDate += 1;
			}
		}
		else if (HolidayFlag == 2)
		{
			//////////////////
			// HolidayRate Interpolated Fill
			//////////////////
			TimePos2 = 0;
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				if (i == ForwardStartIdx) 
				{
					if (UseHistorySOFR == 0) isHolidayFlag = 0;
					else isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));
				}
				else isHolidayFlag =max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					lookbackday = i + 0;

					if (LookBackDays < 1) t = ((double)i)/denominator;
					else
					{
						///////////////////////////
						// N������ �� LookBackDay ���
						///////////////////////////

						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -=1;

							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}
					if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
					else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);

					TargetRate[0] = ForwardRate;
					TargetT[0] = 0.0;
					
					////////////////////
					// �ش��� ���� Holiday���� üũ�Ͽ� dt����
					////////////////////
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					for (j = i + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));

						if (isHolidayFlag2 == 0) break;
						else
						{
							CountHoliday += 1;
						}
					}

					if (CountHoliday == 0)
					{
						LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

						PI_0 *= (1.0 + ForwardRate * 1.0/denominator);
						AverageRate += ForwardRate;
						if (ExlDate > 0) DataForLogging[0] = (double)ExlDate;
						else DataForLogging[0] = (double)i;
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0 + (double)CountHoliday;
						DataForLogging[3] = PI_0;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 4, DataForLogging);
						NCumpound += 1;
					}
					else
					{
						////////////////////
						// Holiday ���� ����������
						////////////////////
						lookbackday = i + CountHoliday + 1;

						if (LookBackDays < 1) t = ((double)lookbackday)/denominator;
						else
						{
							k = 0;
							for (n = 1; n < 120; n++)
							{
								/////////////////////
								// N������ ������ ����
								/////////////////////
								lookbackday -= 1;

								if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
								if (k == LookBackDays) break;
							}
							t = ((double)lookbackday)/denominator;
						}
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos2);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos2);

						LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

						TargetRate[1] = ForwardRate;
						TargetT[1] = ((double)(CountHoliday + 1)) ;

						PI_0 *= (1.0+ TargetRate[0] * 1.0/denominator);
						AverageRate += TargetRate[0];
						if (ExlDate > 0) 
						{
							DataForLogging[0] = (double)ExlDate;
							DataForLogging[4] = (double)lookbackday;
						}
						else 
						{
							DataForLogging[0] = (double)i;
							DataForLogging[4] = (double)lookbackday;
						}
						DataForLogging[1] = TargetRate[0];
						DataForLogging[2] = 1.0;
						DataForLogging[3] = PI_0;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
						NCumpound += 1;
						for (j = 0 ; j < CountHoliday; j++)
						{
							//////////////////////////////////////
							// Holiday���� Linterp Rate�� Compound
							//////////////////////////////////////
							if (LockOutFlag == 0) ForwardRate = Linear_Interpolation_1D(TargetT, TargetRate, 2, (double)(j+1));
							PI_0 *= (1.0 + ForwardRate * 1.0/denominator);
							AverageRate += ForwardRate;
							if (ExlDate > 0) DataForLogging[0] = (double)(ExlDate+j+1);
							else DataForLogging[0] = (double)(i+j+1);
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0 ;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 3, DataForLogging);
							NCumpound += 1;
						}
					}
				}
				if (ExlDate >0) ExlDate += 1;
			}
		}
		else
		{
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				lookbackday = i + 0;
				
				////////////////////
				// Forward Rate Time ���� LookBack �ݿ�
				////////////////////
				if (LookBackDays < 1) t = ((double)i)/denominator;
				else
				{
					k = 0;
					for (n = 1; n < 120; n++)
					{
						/////////////////////
						// N������ ������ ����
						/////////////////////
						lookbackday -= 1;
						if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
						if (k == LookBackDays) break;
					}
					t = ((double)lookbackday)/denominator;
				}
				if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
				else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);

				LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

				PI_0 *= (1.0+ ForwardRate * 1.0/denominator);
				AverageRate += ForwardRate;

				if (ExlDate > 0)
				{
					DataForLogging[0] = (double)ExlDate;
					DataForLogging[4] = (double)lookbackday;
				}
				else
				{
					DataForLogging[0] = (double)i;
					DataForLogging[4] = (double)lookbackday;
				}

				DataForLogging[1] = ForwardRate;
				DataForLogging[2] = 1.0;
				DataForLogging[3] = PI_0;
				if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
				if (ExlDate>0) ExlDate +=1;
				NCumpound += 1;
			}
		}
	}
	else if (ObservShiftFlag == 1)
	{
		if (HolidayFlag == 0)
		{
			//////////////////
			// HolidayRate Forward Fill
			//////////////////
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					lookbackday = i + 0;

					////////////////////
					// Forward Rate Time ���� LookBack �ݿ�
					////////////////////
					if (LookBackDays < 1) t = ((double)i)/denominator;
					else
					{
						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -= 1;

							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}

					////////////////////
					// Observe Shift Dt ���� LookBack �ݿ�
					////////////////////
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;
					for (j = lookbackday + 1; j < ForwardEndIdx; j++)
					{

						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else CountHoliday += 1;
					}
					
					if (CountHoliday == 0)
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);
					}
					else
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos, CountHoliday);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos, CountHoliday);
					}

					if (lookbackday < 0) 
					{
						HistDayIdx = isinfindindex(lookbackday, RefHistoryDate, NRefHistory);
						if (HistDayIdx >= 0) ForwardRate = RefHistory[HistDayIdx];
						else ForwardRate = CurrentRate;
					}

					LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

					PI_0 *= (1.0 + ForwardRate * (1.0 + (double)CountHoliday)  /denominator);
					AverageRate += ForwardRate;

					if (ExlDate > 0)
					{
						DataForLogging[0] = (double)ExlDate;
						DataForLogging[4] = (double)lookbackday;
					}
					else
					{
						DataForLogging[0] = (double)i;
						DataForLogging[4] = (double)lookbackday;
					}
					DataForLogging[1] = ForwardRate;
					DataForLogging[2] = (double)(1 + CountHoliday);
					DataForLogging[3] = PI_0;
					if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
					NCumpound += 1;
				}
				if (ExlDate>0) ExlDate +=1;
			}
			
		}
		else if (HolidayFlag == 1)
		{
			//////////////////
			// HolidayRate Backward Fill
			//////////////////
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				isHolidayFlag = max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					for (j = i + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else
						{
							CountHoliday += 1;
						}
					}

					if (CountHoliday == 0)
					{
						lookbackday = i + 0;
					}
					else 
					{
						lookbackday = i + CountHoliday + 1;
					}

					////////////////////
					// Forward Rate Time ���� LookBack �ݿ�
					////////////////////
					if (LookBackDays < 1) t = ((double)lookbackday)/denominator;
					else
					{
						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -= 1;
							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}

					CountHoliday2 = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					for (j = lookbackday + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else
						{
							CountHoliday2 += 1;
						}
					}

					if (CountHoliday2 == 0)
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);
					}
					else
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos,CountHoliday2);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos,CountHoliday2);
					}
					LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

					////////////////////
					// Observe Shift Dt ���� LookBack �ݿ�
					////////////////////					
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;

					if (lookbackday != i)
					{
						for (j = lookbackday + 1; j < ForwardEndIdx; j++)
						{
							isHolidayFlag2 = max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
							if (isHolidayFlag2 == 0) break;
							else CountHoliday += 1;
						}
					}

					PI_0 *= (1.0+ ForwardRate * (1.0 + (double)CountHoliday) /denominator);
					AverageRate += ForwardRate;

					if (ExlDate > 0)
					{
						DataForLogging[0] = (double)ExlDate;
						DataForLogging[4] = (double)lookbackday;
					}
					else
					{
						DataForLogging[0] = (double)i;
						DataForLogging[4] = (double)lookbackday;
					}
					DataForLogging[1] = ForwardRate;
					DataForLogging[2] = (double)(1 + CountHoliday);
					DataForLogging[3] = PI_0;
					if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
					NCumpound += 1;
				}
				if (ExlDate>0) ExlDate +=1;
			}

		}
		else if (HolidayFlag == 2)
		{
			//////////////////
			// HolidayRate Interpolated Fill
			//////////////////
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				isHolidayFlag =  max(isin(i, Holiday, NHoliday, HoliStartIdx), isin(i, SaturSunDay, NSaturSunDay, SatSunIdx));

				if (isHolidayFlag == 0)
				{
					lookbackday = i + 0;

					////////////////////
					// Forward Rate Time1 ���� LookBack �ݿ�
					////////////////////
					if (LookBackDays < 1) t = ((double)i)/denominator;
					else
					{
						k = 0;
						for (n = 1; n < 120; n++)
						{
							/////////////////////
							// N������ ������ ����
							/////////////////////
							lookbackday -= 1;
							if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
							if (k == LookBackDays) break;
						}
						t = ((double)lookbackday)/denominator;
					}

					////////////////////
					// Observ Shift
					////////////////////
					CountHoliday = 0;
					HoliStartIdx2 = 0;
					SatSunIdx2 = 0;
					for (j = lookbackday + 1; j < ForwardEndIdx; j++)
					{
						isHolidayFlag2 =  max(isin(j , Holiday, NHoliday, HoliStartIdx2), isin(j , SaturSunDay, NSaturSunDay, SatSunIdx2));
						if (isHolidayFlag2 == 0) break;
						else CountHoliday += 1;
					}

					if (CountHoliday == 0)
					{
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);

						LockOutCheck(LockOutFlag, LockOutDay, i, LockOutDayRate, ForwardRate);

						PI_0 *= (1.0+ ForwardRate * 1.0 /denominator);
						AverageRate += ForwardRate;

						if (ExlDate > 0) DataForLogging[0] = (double)ExlDate;
						else DataForLogging[0] = (double)i;
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0;
						DataForLogging[3] = PI_0;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 4, DataForLogging);
					}
					else
					{
						TargetT[0] = 0.0;
						if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);

						LockOutCheck(LockOutFlag, LockOutDay, i , LockOutDayRate, ForwardRate);

						TargetRate[0] = ForwardRate;
						PI_0 *= (1.0+ ForwardRate * 1.0 /denominator);
						AverageRate += ForwardRate;
						NCumpound += 1;

						if (ExlDate > 0) 
						{
							DataForLogging[0] = (double)ExlDate;
							DataForLogging[4] = (double)lookbackday;
						}
						else 
						{
							DataForLogging[0] = (double)i;
							DataForLogging[4] = (double)lookbackday;
						}
						DataForLogging[1] = ForwardRate;
						DataForLogging[2] = 1.0;
						DataForLogging[3] = PI_0;
						if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);

						////////////////////
						// Forward Rate Time2 ���� LookBack �ݿ�
						////////////////////
						t = ((double)(lookbackday + CountHoliday + 1))/denominator;
						TargetT[1] = (double)(CountHoliday + 1);
						if (InterpolateFlag == 0) TargetRate[1] = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
						else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);

						LockOutCheck(LockOutFlag, LockOutDay, i , LockOutDayRate, ForwardRate);

						for (j = 0 ; j < CountHoliday; j++)
						{
							if (LockOutFlag == 0) ForwardRate = Linear_Interpolation_1D(TargetT, TargetRate, 2, ((double)(j+1)));
							PI_0 *= (1.0+ ForwardRate * 1.0 /denominator);
							AverageRate += ForwardRate;
							NCumpound += 1;
							if (ExlDate > 0) DataForLogging[0] = (double)(ExlDate+j+1);
							else DataForLogging[0]= (double)(i + j + 1);
							DataForLogging[1] = ForwardRate;
							DataForLogging[2] = 1.0;
							DataForLogging[3] = PI_0;
							if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 4, DataForLogging);
						}
					}
				}
				if (ExlDate>0) ExlDate +=1;
			}
		}
		else
		{
			for (i = ForwardStartIdx; i < ForwardEndIdx; i++)
			{
				lookbackday = i + 0;
				
				////////////////////
				// Forward Rate Time ���� LookBack �ݿ�
				////////////////////
				if (LookBackDays < 1) t = ((double)i)/denominator;
				else
				{
					k = 0;
					for (n = 1; n < 120; n++)
					{
						/////////////////////
						// N������ ������ ����
						/////////////////////
						lookbackday -= 1;
						if (max(isin(lookbackday, Holiday, NHoliday), isin(lookbackday, SaturSunDay, NSaturSunDay)) == 0) k += 1;
						if (k == LookBackDays) break;
					}
					t = ((double)lookbackday)/denominator;
				}
				if (InterpolateFlag == 0) ForwardRate = Calc_Forward_Rate_Daily(RefCrvTerm, RefCrvRate, NRefCrvTerm, t, &TimePos);
				else ForwardRate = Calc_Forward_Rate_Daily_Cubic(RefCrvTerm, RefCrvRate, C_Array, NRefCrvTerm, t, &TimePos);
				
				LockOutCheck(LockOutFlag, LockOutDay, i , LockOutDayRate, ForwardRate);

				PI_0 *= (1.0+ ForwardRate * 1.0/denominator);
				AverageRate += ForwardRate;

				if (ExlDate > 0)
				{
					DataForLogging[0] = (double)ExlDate;
					DataForLogging[4] = (double)lookbackday;
				}
				else DataForLogging[0] = (double)i;
				DataForLogging[1] = ForwardRate;
				DataForLogging[2] = 1.0;
				DataForLogging[3] = PI_0;
				if (DailyLoggingFlag == 1) LoggingDataArray(szModuleName, szFileName, "DAYRATEDYCNT", 5, DataForLogging);
				if (ExlDate>0) ExlDate +=1;
				NCumpound += 1;
			}
		}
	}

	if (AverageFlag == 1)
	{
		AverageRate = AverageRate/(double)NCumpound;
		AnnualizedOISRate = AverageRate;
	}
	else
	{
		AnnualizedOISRate = (PI_0 - 1.0) * 1.0/T;
	}
	return PI_0 - 1.0;
}

double Calc_Forward_SOFR_Swap(
	double *DisCrvTerm,			// IN:  Discount Rate Curve ����
	double *DisCrvRate,			// IN:  Discount Rate Curve Rate
	double *Dis_CArray,			// IN:  Discount Rate Cubic 2�� �Ķ����
	long NDisCrvTerm,			// IN;  Discount Rate Curve Term ���� 
	double *RefCrvTerm,			// IN:  Reference Rate Curve ����
	double *RefCrvRate,			// IN:  Reference Rate Curve Rate
	double *Ref_CArray,			// IN:  Reference Rate Cubic 2�� �Ķ����
	long NRefCrvTerm,			// IN:  Reference Rate Curve Term ����
	long Day_ForwardMat,		// IN:  Forward Maturity Day
	double SwapRateRefPeriod,	// IN:  Swap �����ֱ�
	long SwapNumPayment,		// IN:  Swap ����Ƚ��
	long HolidayCalcFlag,		// IN:  Holiday Rate ��� Flag 0: Forward Fill, 1: Backward Fill, 2: Linterp
	long NHoliday,				// IN:  Holiday ����
	long *Holiday,				// IN:  Holiday Array
	long LockOutDays,			// IN:  LockOut��¥��
	long LookBackDays,			// IN:  LookBack��¥��
	long ObservationShift,		// IN:  LookBackObservationShift����
	long InterpolateFlag,
	double denominator
	)
{
	long i;

	long k;
	char TempChar[] = "TempChar";

	long DayStartIdx, DayEndIdx;

	long ndates = SwapNumPayment;
	long* dates = (long*)malloc(sizeof(long) * ndates);

	double SwapMaturity = SwapRateRefPeriod * (double)SwapNumPayment;
	double T_ForwardMat = ((double)Day_ForwardMat)/365.0 ;
	double T_SwapMaturity = T_ForwardMat + SwapMaturity;
	long Day_SwapMaturity = (long)(T_SwapMaturity * 365.0);

	////////////////////////////////////////////////////////////////////////
	// Holiday ���� �� ��¥�� Reset�� 50�������� Swap���� ��¥������ �ֱ� //
	////////////////////////////////////////////////////////////////////////

	long nHoliAdjust;
	long *HoliAdjust;
	k = 0;
	for (i = 0 ; i < NHoliday ; i++)
	{
		if (Holiday[i] >= Day_ForwardMat - 50) break;
		k += 1;
	}

	HoliAdjust = Holiday + k;
	nHoliAdjust = 0;
	for (i = k ; i < NHoliday ; i++)
	{
		if (Holiday[i] >= Day_ForwardMat - 50 && Holiday[i] <= Day_SwapMaturity) nHoliAdjust += 1;
	}

	//////////////////////
	// Swap ������ ���� //
	//////////////////////

	double DayDiff = SwapRateRefPeriod * 365.0;
	dates[ndates -1] = (long)(T_SwapMaturity * 365.0 + 0.5);
	k = 1;
	for (i = ndates -2; i >= 0; i--)
	{
		dates[i] = (long)( (T_SwapMaturity - k * SwapRateRefPeriod) * 365.0 + 0.5);
		k += 1;
	}

	double* Disc = (double*)malloc(sizeof(double) * (ndates + 1));
	if (InterpolateFlag == 0) 
	{
		Disc[0] = exp(-Linear_Interpolation_1D(DisCrvTerm, DisCrvRate, NDisCrvTerm, T_ForwardMat) * T_ForwardMat);
		for (i = 1; i < ndates + 1; i++) Disc[i] = exp(-Linear_Interpolation_1D(DisCrvTerm, DisCrvRate, NDisCrvTerm, ((double)dates[i-1])/365.0) * ((double)dates[i-1])/365.0);
	}
	else
	{
		Disc[0] = exp(-CubicInterpolation(NDisCrvTerm,DisCrvTerm, DisCrvRate, Dis_CArray, T_ForwardMat) * T_ForwardMat);
		for (i = 1; i < ndates + 1; i++) Disc[i] = exp(-CubicInterpolation(NDisCrvTerm,DisCrvTerm, DisCrvRate, Dis_CArray, ((double)dates[i-1])/365.0) * ((double)dates[i-1])/365.0);
	}


	double FloatValue, FixValue, SOFR_Swap_Spread;
	double SOFR_Compound;
	double Annual_OIS = 0.0;	
	long tempday[10] = {0,};
	double temprate[10] = {0.,};
	double P_Pay;
	long Temp[1] = {0};
	DayStartIdx = Day_ForwardMat;
	FloatValue = 0.0;
	for (i = 0 ; i < ndates; i++)
	{
		DayEndIdx = dates[i];
		SOFR_Compound = SOFR_ForwardRate_Compound(NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		Ref_CArray,DayStartIdx,		DayEndIdx,	-1, -1,
												  LockOutDays,		LookBackDays,		ObservationShift,		HolidayCalcFlag,	nHoliAdjust,		
												  HoliAdjust,0, Temp,		0,			0,		tempday,		temprate,	
												  denominator,Annual_OIS,0,InterpolateFlag,0,
												  TempChar,				TempChar);

		P_Pay = Disc[i+1];
		FloatValue += SOFR_Compound * P_Pay;
		DayStartIdx = DayEndIdx;
	}

	double dt;
	FixValue = 0.0;
	for (i = 0 ; i < ndates; i++)
	{
		if (i == 0) dt = (double)(dates[0])/365.0 - T_ForwardMat;
		else dt = ((double)(dates[i] - dates[i-1]))/365.0;
		FixValue += dt * Disc[i+1];
	}
	SOFR_Swap_Spread = FloatValue / FixValue;

	if (dates) free(dates);
	if (Disc) free(Disc);
	if (Temp) free(Temp);
	return SOFR_Swap_Spread;
}

// Crv : Curve
// Cpn : Coupon
// Cnt : Count
// Disc : Discount
// Settle : Settlement
// Prin : Principal
// NA : Notional Amount
long IR_Leg_Value(
	long PriceDate,				// IN:  ����� (YYYYMMDD)
	double *DisCrvTerm,			// IN:  Discount Rate Curve ����
	double *DisCrvRate,			// IN:  Discount Rate Curve Rate
	long NDisCrvTerm,			// IN;  Discount Rate Curve Term ����
	long DisCrvDayCntType,		// IN:  Discount Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double *RefCrvTerm,			// IN:  Reference Rate Curve ����
	double *RefCrvRate,			// IN:  Reference Rate Curve Rate
	long NRefCrvTerm,			// IN:  Reference Rate Curve Term ����
	long RefCrvDayCntType,		// IN:  Reference Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double RefRatePeriod,		// IN:  Reference Rate �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� Reference Curve�� ǥ���ϴ� Rate�� ���⸦ ��Ÿ�� )
	double SwapRateFixedPeriod,	// IN:  Swap Rate Fixed Leg �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� RefRatePeriod�� �����ϰ� �Է�)
	long SwapRateFixedNumCpn,	// IN:  Swap Rate Fixed Leg ����Ƚ�� (SwapRateFixedPeriod*SwapRateFixedNumCpn = Swap Rate ��� Swap�� ����, 1�ϰ�� �Ϲ� Zero Curve ó��)
	long CpnPeriodType,			// IN:  ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case )
	long PaiedTime,				// IN:  ��/���� ���� ( 1 : ����, 2 : ����, 3 : ��/���� ȥ����)
	long InArrearFlag,			// IN:  In Arrear ���� ( 0 : In Advanced, 1 : In Arrear, 2 : In Advanced/Arrear ȥ���� )
	long CpnDayCountType,		// IN:  Coupon ���� DayCount Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ConvexityAdjustFlag,	// IN:  Convexity Adjustment Flag ( 0 : ��������, 1 : ������, 2: �������ǹ��� )
	long TimingAdjustFlag,		// IN:  Timing Adjust Flag ( 0 : ��������, 1 : ������, 2: �������ǹ��� )
	long NCapVolTerm,			// IN:  Cap Vol �Ⱓ���� ��
	double *CapVolTerm,			// IN:  Cap Vol �Ⱓ����
	double *CapVol,				// IN:  Cap Volatility
	double TimingCorr,			// IN:  Timing Adjustment Corr
	long NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	long NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ����
	double *SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long NPrinCashFlow,			// IN:  �ش� Leg ������� CashFlow ����
	double *PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾�
	long *PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD)
	double *PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor
	long NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ����
	long *ResetFixDate,			// IN:  ������ (YYYYMMDD)
	long *DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ���, 2 : ������, ������+RefRatePeriod�� ���� )
	long *ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut )
	long *ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut )
	long *NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���)
	long *NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����)
	long *CpnFromDate,			// IN:  ����� (YYYYMMDD)
	long *CpnToDate,			// IN:  �⸻�� (YYYYMMDD)
	long *CpnSettleDate,		// IN:  ������ (YYYYMMDD)
	double *CpnNA,				// IN:  Coupon ���ؿ���
	double *CpnSlope,			// IN:  Coupon �����ݸ� ���� ����
	double *CpnSpread,			// IN:  Coupon �����ݸ� ������
	long SOFRUseFlag,			// IN:  SOFR ��뿩��
	long DailyRateLoggingFlag,	// IN:  SOFR Rate Daily Logging Flag
	long* SOFRConv,				// IN: [0] LockOut, [1]LookBack [2] Observ Shift [3] HolidayFlag
	long NHoliday,				// IN: Holiday����
	long* Holiday,				// IN: HolidayDate		
	long NRefHistory,			// IN: HistoryRate ����
	long* RefHistoryDate,		// IN: Reference History Date �迭		
	double* RefHistory,			// IN: History Rate �迭
	double *CpnRefRate,			// IN/OUT:  Ȯ���ݸ�
	double *CpnCashFlow,		// IN/OUT:  ��������
	double *CpnDiscFactor,		// OUT: Discount Factor
	double *ResultPrice,		// OUT: [0] : Leg Price, [1] : �������
	long InterpolateFlag,		// IN: SOFR Interpolation Flag 0: Linterp 1: Cubic
	char *szModuleName,				
	char *szFileName
)
{
	long i, j, k;
	long ii;
	double INTERVAL_EPS = 0.25;
	long ResultCode = 1;
	long Start_CpnTerm = 0;
	long Start_PrinTerm = 0;
	double EstForwardRate = 0.0;

	long ConvexityAdjApplyFlag = 0;
	long TimingAdjApplyFlag = 0;
	double ForwardInterval_Year = 0.0;

	double Volatility_Interp= 0.0;
	long NCapletTerm;
	double *CapletTerm;
	double *CapletVol;

	double ResetDate_Year = 0.0;
	double Diff1_G = 0.0;
	double Diff2_G = 0.0;

	long Interval_ForwardStartDate = 0;
	long Interval_ForwardEndDate = 0;
	long Interval_ResetDate = 0;
	double Interval_ForwardRate = 0.0;
	double Interval_ConvexityAdj = 0.0;
	double Interval_TimingAdj = 0.0;

	ResultPrice[0] = 0.0;
	ResultPrice[1] = 0.0;

	////////////////////////////
	// SOFR ���� ����		  //
	// 2022.06.06 �Ӵ뼱 �߰� //
	////////////////////////////

	long PrevFlag = 1;
	double denominator = 365.0;

	long ForwardStartIdx;
	long ForwardEndIdx;
	long ForwardStartExlDate;
	long ForwardEndExlDate;

	long UseHistorySOFR = 0;

	double OIS_Compound = 0.0;
	double OIS_Annual = 0.0;

	long LockOutDays = SOFRConv[0];
	long LookBackDays = SOFRConv[1];
	long ObservShiftDays = SOFRConv[2];
	long HolidayFlag = SOFRConv[3];

	long* RefHistoryDate_Adjust = (long*)malloc(sizeof(long) * NRefHistory);
	////////////////////////////////////////////////////
	// SOFRFlag�� 1�� ���							  //
	// ��� Holiday�� �� ������� �ʰ�				  //
	// ���� �������θ� ���							  //
	////////////////////////////////////////////////////
	long* Holiday_Adjust = (long*)malloc(sizeof(long) * NHoliday);
	long** Holidays_ForFast = (long**)malloc(sizeof(long*) * NCpnCashFlow);
	long* NHolidays_ForFast = (long*)malloc(sizeof(long) * NCpnCashFlow);
	long nSunSat = 0;
	long** SundaySaturday = (long**)malloc(sizeof(long*) * NCpnCashFlow);
	long* NSundaySaturday = (long*)malloc(sizeof(long) * NCpnCashFlow);
	long NumHoliTemp = 0;

	long HoliStart = 0;
	long HoliEnd = 0;
	long HoliStartCDate = 0;
	long HoliEndCDate = 0;
	long HoliStartExlDate = 0;
	long HoliEndExlDate = 0;

	long TempIdx = 0;
	if (SOFRUseFlag ==1 || SOFRUseFlag == 2 || SOFRUseFlag == 3)
	{
		//////////////////////////////////////////////////////////////////
		// SOFR ����ϴ� ���											//
		// ������ Forward Start , Forward End�� ����ϱ� ���� �� �ű�� //
		//////////////////////////////////////////////////////////////////
		for (i = 0 ; i < NCpnCashFlow; i++)
		{
			if (DesignateResetFlag[i] == 0)
			{
				ForwardStartDate[i] = CpnFromDate[i];
				ForwardEndDate[i] = CpnToDate[i];
			}
			else if (DesignateResetFlag[i] == 2)
			{
				if ( (RefRatePeriod - SwapRateFixedPeriod)*(RefRatePeriod - SwapRateFixedPeriod) <= 0.00001)
				{
					ForwardStartDate[i] = ResetFixDate[i];
					ForwardEndDate[i] = ActDateAdjust(ResetFixDate[i] , (long)(RefRatePeriod * 365.0 + 0.05));
				}
				else
				{
					ForwardStartDate[i] = ResetFixDate[i];
					ForwardEndDate[i] = ActDateAdjust(ResetFixDate[i], (long)(SwapRateFixedPeriod * 365.0 + 0.05));
				}
			}
		}

		for (i = 0 ; i < NHoliday; i++)  Holiday_Adjust[i] = ActDayCount(PriceDate, Holiday[i]);

		for (i = 0 ; i < NRefHistory; i++)  RefHistoryDate_Adjust[i] = ActDayCount(PriceDate, RefHistoryDate[i]);

		if (CpnDayCountType == 3) denominator = 365.0;
		else denominator = 360.0;

		for (i = 0 ; i < NCpnCashFlow; i++)
		{
			HoliStartCDate = ActDateAdjust(ForwardStartDate[i], -(LookBackDays+1));
			HoliEndCDate = ActDateAdjust(ForwardEndDate[i] ,1);
			HoliStartExlDate = CdrD2ExcD(HoliStartCDate);
			HoliEndExlDate = CdrD2ExcD(HoliEndCDate);
			nSunSat = 0;
			for (j = HoliStartExlDate; j < HoliEndExlDate; j++)
			{
				if (isweekend(j) == 1) nSunSat += 1;
			}
			NSundaySaturday[i] = nSunSat;
			SundaySaturday[i] = (long*)malloc(sizeof(long) * max(1,NSundaySaturday[i]));

			k = 0;
			for (j = HoliStartExlDate; j < HoliEndExlDate; j++)
			{
				if (isweekend(j) == 1) 
				{
					SundaySaturday[i][k] = ActDayCount(PriceDate, ExcD2CdrD(j));
					k = k + 1;
				}
			}

			HoliStart = ActDayCount(PriceDate, HoliStartCDate);
			HoliEnd = ActDayCount(PriceDate, HoliEndCDate);
			for (j = 0 ; j < NHoliday; j++)
			{
				if (Holiday_Adjust[j] >= HoliStart && Holiday_Adjust[j] <= HoliEnd) 
				{
					TempIdx = j;
					break;
				}
			}
			Holidays_ForFast[i] = Holiday_Adjust + j;
			NumHoliTemp = 0;
			for (j = TempIdx; j < NHoliday; j++)
			{
				if (Holidays_ForFast[i][j - TempIdx]>= HoliStart && Holidays_ForFast[i][j - TempIdx] <= HoliEnd)
				{
					NumHoliTemp += 1; 
				}
				else
				{
					break;
				}
			}
			NHolidays_ForFast[i] = NumHoliTemp;
		}
	}

	////////////////////////////////////////
	// Interp ���� ����					  //
	// 0: Linear Interp, 1: Cubic Interp  //
	////////////////////////////////////////
	long RefInterpFlag = 0;
	long DiscInterpFlag = 0;
	if (NRefCrvTerm < 4 || InterpolateFlag == 0) RefInterpFlag = 0;
	else RefInterpFlag = 1;

	if (NDisCrvTerm < 4 || InterpolateFlag == 0) DiscInterpFlag = 0;
	else DiscInterpFlag = 1;

	double* RefCubicCArray ;
	double* DiscCubicCArray ;
	long CaliResult = 0;
	if (RefInterpFlag == 0) // Linear Interp�� ��� ������� ���� �ӽ� Array �Ҵ�
	{
		RefCubicCArray = (double*)malloc(sizeof(double) * 1);
	}
	else
	{
		RefCubicCArray = (double*)malloc(sizeof(double) * NRefCrvTerm);
		CaliResult = Calibration_CubicSpline_Params(NRefCrvTerm, RefCrvTerm, RefCrvRate, RefCubicCArray);
		if (CaliResult < 0) RefInterpFlag = 0;
	}

	if (DiscInterpFlag == 0) // Linear Interp�� ��� ������� ���� �ӽ� Array �Ҵ�
	{
		DiscCubicCArray = (double*)malloc(sizeof(double) * 1);
	}
	else
	{
		DiscCubicCArray = (double*)malloc(sizeof(double) * NDisCrvTerm);
		CaliResult = Calibration_CubicSpline_Params(NDisCrvTerm, DisCrvTerm, DisCrvRate, DiscCubicCArray);
		if (CaliResult < 0) DiscInterpFlag = 0;
	}



	// �⺻������ Swap�ݸ��� �ƴҰ�� �ΰ� ������ ������ ��������, �ٽ��ѹ� �ʱ�ȭ
	if(SwapRateFixedNumCpn==1)
	{
		SwapRateFixedPeriod = RefRatePeriod;
		TimingCorr = 1.0;
	}

	// Coupon ���� ����� ���۱��� Count
	Start_CpnTerm = NCpnCashFlow;
	for(i=0;i<NCpnCashFlow;i++)
	{
		if(PriceDate<CpnSettleDate[i])
		{
			Start_CpnTerm = i;
			break;
		}
	}

	// ���� ���� ����� ���۱��� Count
	Start_PrinTerm = NPrinCashFlow;
	for(i=0;i<NPrinCashFlow;i++)
	{
		if(PriceDate<PrinSettleDate[i])
		{
			Start_PrinTerm = i;
			break;
		}
	}

	if( (SwapRateFixedNumCpn==1 && ConvexityAdjustFlag==1 ) || TimingAdjustFlag==1)
	{
		NCapletTerm = (long)( (CapVolTerm[NCapVolTerm-1]+1) / RefRatePeriod) + 1;
		CapletTerm = (double *)malloc(NCapletTerm*sizeof(double));
		CapletVol = (double *)malloc(NCapletTerm*sizeof(double));

		Calc_CapletForwardVol(	PriceDate,		NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntType,
								NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntType,	RefRatePeriod,
								NCapVolTerm,	CapVolTerm,		CapVol,			ResetFixDate[NCpnCashFlow-1],		2,
								&NCapletTerm,	CapletTerm,		CapletVol		);
	}

	for(i=Start_CpnTerm;i<NCpnCashFlow;i++)
	{
		// ���αݸ� ���
		if (DiscInterpFlag == 0) CpnDiscFactor[i] = Calc_DiscountFactor(PriceDate, DisCrvTerm, DisCrvRate, NDisCrvTerm, DisCrvDayCntType, CpnSettleDate[i]);
		else CpnDiscFactor[i] = Calc_DiscountFactor_Cubic(PriceDate, DisCrvTerm, DisCrvRate, DiscCubicCArray, NDisCrvTerm, DisCrvDayCntType, CpnSettleDate[i]);

		if(CpnPeriodType==2 || CpnPeriodType==3) // ������ ���
		{
			if (SOFRUseFlag == 0)
			{
				// ������ ���� Ȯ������ ���� ��쿡 ���Ͽ� �����ݸ� ���
				if( ( (NFixDates[i] == 1 && CpnRefRate[i] == 0) || NFixDates[i] != 1 ) && NFixedDates[i] < NFixDates[i] )
				{
					EstForwardRate = 0.0;
					// �����ݸ��� ����� ������� ���� ���
					for(ii=0;ii<NFixDates[i]-NFixedDates[i];ii++)
					{
						Interval_ForwardRate = 0.0;
						Interval_ConvexityAdj = 0.0;
						Interval_TimingAdj = 0.0;

						// Forward Rate����
						if(SwapRateFixedNumCpn==1) // �������޼��� 1�ϰ�� �ܼ� Forward Rate ����
						{
							// �⺻�� ����
							Interval_ForwardStartDate = ActDateAdjust(CpnFromDate[i],-ii);
							Interval_ForwardEndDate = ActDateAdjust(CpnToDate[i],-ii);
							Interval_ResetDate = ActDateAdjust(ResetFixDate[i],-ii);
							if(DesignateResetFlag[i]==0)
							{
								if(InArrearFlag==0) // In Advanced�� ��� Coupon From, Coupon To Date�� Forward ���� �����.
								{
									if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,Interval_ForwardEndDate);
									else Interval_ForwardRate = Calc_ForwardRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray, NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,Interval_ForwardEndDate);
								}
								else // In Arrear�� ��� ���ο��� Rate �ֱ⸸ŭ Reset�Ϸκ��� Forward ���� ������ ���� ���
								{
									if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)));
									else Interval_ForwardRate = Calc_ForwardRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray, NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)));
								}

							}
							else if(DesignateResetFlag[i]==1)// Forward���������� ���� �Է¹޾��� ���� ������������ ��� 
							{
								Interval_ForwardStartDate = ActDateAdjust(ForwardStartDate[i],-ii);
								Interval_ForwardEndDate = ActDateAdjust(ForwardEndDate[i],-ii);
								if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,Interval_ForwardEndDate);
								else Interval_ForwardRate = Calc_ForwardRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray, NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,Interval_ForwardEndDate);
							}
							else // ������ ������, ������+RefRate Period�� ����, �������϶��� �׻� �� ���� �����
							{
								if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)));
								else Interval_ForwardRate = Calc_ForwardRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray, NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)));
							}
						}
						else // Forward Swap Rate ����
						{
							if(DesignateResetFlag[i]==0 || DesignateResetFlag[i]==2)
							{
								Interval_ResetDate = ActDateAdjust(ResetFixDate[i],-ii);
								// Forward Swap Rate������ ���ο��� ��ü Swap�� Payoff�� ���� ���
								if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardSwapRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,SwapRateFixedPeriod,SwapRateFixedNumCpn);
								else Interval_ForwardRate = Calc_ForwardSwapRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,SwapRateFixedPeriod,SwapRateFixedNumCpn);
							}
							else
							{
								Interval_ForwardStartDate = ActDateAdjust(ForwardStartDate[i],-ii);
								// Forward Swap Rate������ ���ο��� ��ü Swap�� Payoff�� ���� ���
								if (RefInterpFlag == 0) Interval_ForwardRate = Calc_ForwardSwapRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,SwapRateFixedPeriod,SwapRateFixedNumCpn);
								else Interval_ForwardRate = Calc_ForwardSwapRate_Cubic(PriceDate,RefCrvTerm,RefCrvRate,RefCubicCArray, NRefCrvTerm,RefCrvDayCntType,Interval_ForwardStartDate,SwapRateFixedPeriod,SwapRateFixedNumCpn);
							}
						}

						// Convexity Adjust
						if(ConvexityAdjustFlag==1 && DesignateResetFlag[i]!=2)
						{
							// Convexity Adjust ���� ���� üũ
							ConvexityAdjApplyFlag = 0;
							ForwardInterval_Year = 1.0; // �⺻��
							if( SwapRateFixedNumCpn!=1 ) // Forward Swap Rate�� ��� Convexity Adjust ����
							{	
								ConvexityAdjApplyFlag = 1;
							}
							else // Forward �ݸ��� ���
							{
								if( (InArrearFlag==0 && PaiedTime==1) || InArrearFlag==1) // In Advanced and ���� �Ǵ� ������ ��� ����
								{
									ConvexityAdjApplyFlag = 1;
								}

								ForwardInterval_Year = DayCountFraction(CpnFromDate[i], CpnToDate[i], RefCrvDayCntType);
								if(ForwardInterval_Year/RefRatePeriod > ( 1+ INTERVAL_EPS ) ) // �����Ⱓ�� ���ޱⰣ��Ÿ �� ��� ������ ( 6M LIBOR�̰� 3M���������ֱ� )
								{
									ConvexityAdjApplyFlag = 1;
								}
							}

							// Convexity Adjust�� ����Ǿ� �� ���
							if(ConvexityAdjApplyFlag==1)
							{
								ResetDate_Year = DayCountFraction(PriceDate, Interval_ResetDate, RefCrvDayCntType);
								if(SwapRateFixedNumCpn==1)
								{
									Volatility_Interp = Linear_Interpolation_1D(CapletTerm,	CapletVol, NCapletTerm, ResetDate_Year ); 
								}
								else
								{
									Volatility_Interp = Linear_interpolation_2D(	SwapRateFixedPeriod*SwapRateFixedNumCpn,	ResetDate_Year,		NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
																					SwaptionVolOptMat,							SwaptionVol			);
								}
							
								Diff1_G = 0.0;
								Diff2_G = 0.0;
								for(j=0;j<SwapRateFixedNumCpn;j++)
								{
									Diff1_G -= SwapRateFixedPeriod/pow(1+Interval_ForwardRate*SwapRateFixedPeriod,j+2);
									Diff2_G += (SwapRateFixedPeriod*SwapRateFixedPeriod)/pow(1+Interval_ForwardRate*SwapRateFixedPeriod,j+3);
								}
								Diff1_G *= Interval_ForwardRate*SwapRateFixedPeriod;
								Diff2_G *= Interval_ForwardRate*SwapRateFixedPeriod;

								Diff1_G -= 1/pow(1+Interval_ForwardRate*SwapRateFixedPeriod,SwapRateFixedNumCpn+1);
								Diff2_G += 1/pow(1+Interval_ForwardRate*SwapRateFixedPeriod,SwapRateFixedNumCpn+2);

								Interval_ConvexityAdj -= 0.5 * Interval_ForwardRate*Interval_ForwardRate * Volatility_Interp*Volatility_Interp * ResetDate_Year * Diff2_G / Diff1_G;
							}
						}

						// Timing Adjust
						if( TimingAdjustFlag == 1 && DesignateResetFlag[i]!=2 )
						{
							TimingAdjApplyFlag = 0;
							ForwardInterval_Year = 1.0; // �⺻��
							if(SwapRateFixedNumCpn!=1 && (InArrearFlag==0 && PaiedTime==2) ) // Swap�ݸ��̰�, In Advanced�̰� �����̸� ������
							{
								TimingAdjApplyFlag = 1;
							}
							else if( SwapRateFixedNumCpn==1 ) // Swap�ݸ��� �ƴҶ�
							{
								ForwardInterval_Year = DayCountFraction(CpnFromDate[i], CpnToDate[i], RefCrvDayCntType);
								if(RefRatePeriod/ForwardInterval_Year>(1+INTERVAL_EPS)) // ���ޱⰣ�� �����Ⱓ���� �� ��� ( 3M LIBOR, 6M�������� )
								{
									TimingAdjApplyFlag = 1;
								}
							}

							// Timing Adjust�� ����Ǿ� �� ���
							if(TimingAdjApplyFlag==1)
							{
								ResetDate_Year = DayCountFraction(PriceDate, Interval_ResetDate, RefCrvDayCntType);
								Volatility_Interp = Linear_Interpolation_1D(CapletTerm,	CapletVol, NCapletTerm, ResetDate_Year ); 
								if(SwapRateFixedNumCpn != 1) // Forward Swap Rate
								{
									Interval_TimingAdj += (	Interval_ForwardRate * TimingCorr * Volatility_Interp
														* Linear_interpolation_2D(	SwapRateFixedPeriod*SwapRateFixedNumCpn,	ResetDate_Year,		NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
																					SwaptionVolOptMat,							SwaptionVol			)
														* Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)))
														* ResetDate_Year * RefRatePeriod
													  )
													  / ( 1 + Calc_ForwardRate(PriceDate,RefCrvTerm,RefCrvRate,NRefCrvTerm,RefCrvDayCntType,Interval_ResetDate,ActDateAdjust(Interval_ResetDate,(long)(RefRatePeriod*365.0)))
															  * RefRatePeriod );
								}
								else if(SwapRateFixedNumCpn == 1 && ConvexityAdjApplyFlag != 1) // Forward Rate
								{
									Interval_TimingAdj += (	Interval_ForwardRate * Interval_ForwardRate * Volatility_Interp * Volatility_Interp * ResetDate_Year * RefRatePeriod )
													  / ( 1 + Interval_ForwardRate * RefRatePeriod );
								}
							}
						}
						// Adjust �� ���
						EstForwardRate += (Interval_ForwardRate+Interval_ConvexityAdj+Interval_TimingAdj)/NFixDates[i];
					}
					CpnRefRate[i] = EstForwardRate + CpnRefRate[i]*NFixedDates[i]/NFixDates[i];
				}
			}
			else if (SOFRUseFlag == 1)
			{
				//////////////////////////////////
				// �����ڻ��� SOFR Rate ����   ///
				//////////////////////////////////				

				PrevFlag = 1;
				if (PriceDate < CpnSettleDate[i]) PrevFlag = 0;

				if (PrevFlag == 0)
				{
					ForwardStartIdx = ActDayCount(PriceDate, ForwardStartDate[i]);
					ForwardEndIdx = ActDayCount(PriceDate, ForwardEndDate[i]);

					ForwardStartExlDate = CdrD2ExcD(ForwardStartDate[i]);
					ForwardEndExlDate = CdrD2ExcD(ForwardEndDate[i]);

					if (ForwardStartIdx < 0) UseHistorySOFR = 1;
					else UseHistorySOFR = 0;

					OIS_Compound = SOFR_ForwardRate_Compound(NRefCrvTerm,				RefCrvTerm,			RefCrvRate,					RefCubicCArray,ForwardStartIdx,		ForwardEndIdx,		ForwardStartExlDate, ForwardEndExlDate,
															LockOutDays,				LookBackDays,		ObservShiftDays,			HolidayFlag,			NHolidays_ForFast[i],		
															Holidays_ForFast[i],		NSundaySaturday[i], SundaySaturday[i],UseHistorySOFR,		NRefHistory,				RefHistoryDate_Adjust,			RefHistory,	
															denominator,				OIS_Annual,			DailyRateLoggingFlag,		InterpolateFlag,	0,
															szModuleName,				szFileName);
							
					CpnRefRate[i] = OIS_Annual;
					CpnCashFlow[i] = OIS_Compound * CpnNA[i] + CpnSpread[i]* CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
				}
			}
			else if (SOFRUseFlag == 2 && (DesignateResetFlag[i]==2 || DesignateResetFlag[i]==1))
			{
				///////////////////////////////////////
				// �����ڻ��� SOFR Swap Rate ����   ///
				///////////////////////////////////////		

				PrevFlag = 1;
				if (PriceDate < CpnSettleDate[i]) PrevFlag = 0;

				if (PrevFlag == 0)
				{
					ForwardStartIdx = ActDayCount(PriceDate, ForwardStartDate[i]);

					if (ForwardStartIdx >= 0)
					{
						Interval_ForwardRate = Calc_Forward_SOFR_Swap(DisCrvTerm,			DisCrvRate,			DiscCubicCArray,			NDisCrvTerm,			RefCrvTerm,	
																	  RefCrvRate,			RefCubicCArray,		NRefCrvTerm,				ForwardStartIdx,		SwapRateFixedPeriod,	
																	  SwapRateFixedNumCpn,	HolidayFlag,		NHoliday,					Holiday_Adjust,				LockOutDays,
																	  LookBackDays,			ObservShiftDays,	InterpolateFlag,			denominator);
					}
					else
					{
						if (isinfindindex(ForwardStartIdx, RefHistoryDate, NRefHistory) >= 0)
						{
							Interval_ForwardRate = RefHistory[isinfindindex(ForwardStartIdx, RefHistoryDate, NRefHistory)];
						}
						else
						{
							Interval_ForwardRate = 0.0;
						}
					}

					CpnRefRate[i] = Interval_ForwardRate;
					CpnCashFlow[i] = (Interval_ForwardRate+ CpnSpread[i])* CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
				}
			}
			else if (SOFRUseFlag == 3)
			{
				////////////////////////////////////////
				// �����ڻ��� SOFR Rate Average����   //
				////////////////////////////////////////				

				PrevFlag = 1;
				if (PriceDate < CpnSettleDate[i]) PrevFlag = 0;

				if (PrevFlag == 0)
				{
					ForwardStartIdx = ActDayCount(PriceDate, ForwardStartDate[i]);
					ForwardEndIdx = ActDayCount(PriceDate, ForwardEndDate[i]);

					ForwardStartExlDate = CdrD2ExcD(ForwardStartDate[i]);
					ForwardEndExlDate = CdrD2ExcD(ForwardEndDate[i]);

					if (ForwardStartIdx < 0) UseHistorySOFR = 1;
					else UseHistorySOFR = 0;

					OIS_Compound = SOFR_ForwardRate_Compound(NRefCrvTerm,				RefCrvTerm,			RefCrvRate,					RefCubicCArray,ForwardStartIdx,		ForwardEndIdx,		ForwardStartExlDate, ForwardEndExlDate,
															LockOutDays,				LookBackDays,		ObservShiftDays,			HolidayFlag,			NHolidays_ForFast[i],		
															Holidays_ForFast[i],		NSundaySaturday[i], SundaySaturday[i],UseHistorySOFR,		NRefHistory,				RefHistoryDate_Adjust,			RefHistory,	
															denominator,				OIS_Annual,			DailyRateLoggingFlag,		InterpolateFlag,	SOFRUseFlag,
															szModuleName,				szFileName);
							
					CpnRefRate[i] = OIS_Annual; // OIS_Annual = r_avg
				 //	CpnCashFlow[i] = OIS_Compound * CpnNA[i] + CpnSpread[i]* CpnNA[i] * DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
				    CpnCashFlow[i] = CpnRefRate[i]*CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType) + CpnSpread[i]* CpnNA[i] * DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
				}
			}
		}
		else // �����ϰ�� �����ݸ��� ���� (Spread�� �Է�)
		{
			CpnRefRate[i] = CpnSpread[i];
		}

		if(CpnCashFlow[i] == 0)
		{
			if(CpnPeriodType == 1) // ����
				CpnCashFlow[i] = CpnSpread[i]*CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
			else if(CpnPeriodType==2) // ����
			{
				if (SOFRUseFlag == 0) CpnCashFlow[i] = (CpnRefRate[i]+CpnSpread[i])*CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
			}
			else // ����(Slope�� 1�� �ƴ� Case)
				CpnCashFlow[i] = (CpnSlope[i]*CpnRefRate[i]+CpnSpread[i])*CpnNA[i]*DayCountFraction(CpnFromDate[i], CpnToDate[i], CpnDayCountType);
		}

		ResultPrice[0] += CpnCashFlow[i]*CpnDiscFactor[i];
	}

	if(InArrearFlag==0 && PaiedTime==2) // ������ ���� ������� ���
	{
		if(PriceDate>=CpnFromDate[Start_CpnTerm] && PriceDate<=CpnToDate[Start_CpnTerm])
			ResultPrice[1] = CpnRefRate[Start_CpnTerm]*CpnNA[Start_CpnTerm]*DayCountFraction(CpnFromDate[Start_CpnTerm], PriceDate, CpnDayCountType);
	}

	// ���� Cash Flow �ջ�
	for(i=Start_PrinTerm;i<NPrinCashFlow;i++)
	{
		PrinDiscFactor[i] = Calc_DiscountFactor(PriceDate, DisCrvTerm, DisCrvRate, NDisCrvTerm, DisCrvDayCntType, PrinSettleDate[i]);
		ResultPrice[0] += PrinCashFlow[i]*PrinDiscFactor[i];
	}

	if( (SwapRateFixedNumCpn==1 && ( ConvexityAdjustFlag==1 || TimingAdjustFlag==1 )) || (TimingAdjustFlag==1 && SwapRateFixedNumCpn!=1) )
	{
		if(CapletTerm) free(CapletTerm);
		if(CapletVol) free(CapletVol);
	}

	if (Holidays_ForFast) free(Holidays_ForFast);
	if (NHolidays_ForFast) free(NHolidays_ForFast);
	if (RefCubicCArray) free(RefCubicCArray);
	if (DiscCubicCArray) free(DiscCubicCArray);
	if (SOFRUseFlag ==1 || SOFRUseFlag == 2 || SOFRUseFlag == 3)
	{
		for (i = 0 ; i < NCpnCashFlow; i++) 
		{
			if (SundaySaturday[i]) free(SundaySaturday[i]);
		}
	}
	if (SundaySaturday) free(SundaySaturday);
	if (NSundaySaturday) free(NSundaySaturday);
	if (Holiday_Adjust) free(Holiday_Adjust);
	if (RefHistoryDate_Adjust) free(RefHistoryDate_Adjust);

	return ResultCode;
}

/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
//                ���� Leg�Լ��� �����Ͽ� Floater ���                                     //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////

void InputCheck_FRN(
	long PriceDate,				// IN:  ����� (YYYYMMDD)
	double *DisCrvTerm,			// IN:  Discount Rate Curve ����
	double *DisCrvRate,			// IN:  Discount Rate Curve Rate
	long NDisCrvTerm,			// IN;  Discount Rate Curve Term ����
	long DisCrvDayCntType,		// IN:  Discount Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double *RefCrvTerm,			// IN:  Reference Rate Curve ����
	double *RefCrvRate,			// IN:  Reference Rate Curve Rate
	long NRefCrvTerm,			// IN:  Reference Rate Curve Term ����
	long RefCrvDayCntType,		// IN:  Reference Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double RefRatePeriod,		// IN:  Reference Rate �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� Reference Curve�� ǥ���ϴ� Rate�� ���⸦ ��Ÿ�� )
	double SwapRateFixedPeriod,	// IN:  Swap Rate Fixed Leg �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� SwapRateFltPeriod�� �����ϰ� �Է�)
	long SwapRateFixedNumCpn,	// IN:  Swap Rate Fixed Leg ����Ƚ�� (SwapRateFixedPeriod*SwapRateFixedNumCpn = Swap Rate ��� Swap�� ����, 1�ϰ�� �Ϲ� Zero Curve ó��)
	long CpnPeriodType,			// IN:  ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case )
	long PaiedTime,				// IN:  ��/���� ���� ( 1 : ����, 2 : ����)
	long InArrearFlag,			// IN:  In Arrear ���� ( 0 : In Advanced, 1 : In Arrear )
	long CpnDayCountType,		// IN:  Coupon ���� DayCount Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ConvexityAdjustFlag,	// IN:  Convexity Adjustment Flag ( 0 : ��������, 1 : ������, 2: �����ؾ� �Ǵ� ���������� ���� )
	long TimingAdjustFlag,		// IN:  Timing Adjust Flag ( 0 : ��������, 1 : ������, 2: �������������� �������� )
	long NCapVolTerm,			// IN:  Cap Vol �Ⱓ���� ��
	double *CapVolTerm,			// IN:  Cap Vol �Ⱓ����
	double *CapVol,				// IN:  Cap Volatility
	double TimingCorr,			// IN:  Timing Adjustment Corr
	long NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	long NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ����
	double *SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long NPrinCashFlow,			// IN:  �ش� Leg ������� CashFlow ����
	double *PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾�
	long *PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD)
	double *PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor
	long NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ����
	long *ResetFixDate,			// IN:  ������ (YYYYMMDD)
	long *DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ��� )
	long *ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut )
	long *ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut )
	long *NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���)
	long *NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����)
	long *CpnFromDate,			// IN:  ����� (YYYYMMDD)
	long *CpnToDate,			// IN:  �⸻�� (YYYYMMDD)
	long *CpnSettleDate,		// IN:  ������ (YYYYMMDD)
	double *CpnNA,				// IN:  Coupon ���ؿ���
	double *CpnSlope,			// IN:  Coupon �����ݸ� ���� ����
	double *CpnSpread,			// IN:  Coupon �����ݸ� ������
	double *CpnRefRate,			// IN/OUT:  Ȯ���ݸ�
	double *CpnCashFlow,		// IN/OUT:  ��������
	double *CpnDiscFactor,		// OUT: Discount Factor
	long SOFRUseFlag,
	long DailyRateLoggingFlag,	
	long* SOFRConv,
	long NHoliday,				
	long* Holiday,			
	long NRefHistory,
	long* RefHistoryDate,			
	double* RefHistory,
	long TextFlag,				// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	long GreekFlag,				// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
	char *szFileName,			// IN:  text logging file name
	char *szModuleName			// IN:  module name
)
{
	LoggingData(szModuleName, szFileName, "PriceDate", PriceDate);
	LoggingDataArray(szModuleName, szFileName, "DisCrvTerm", NDisCrvTerm, DisCrvTerm);
	LoggingDataArray(szModuleName, szFileName, "DisCrvRate", NDisCrvTerm, DisCrvRate);
	LoggingData(szModuleName, szFileName, "NDisCrvTerm", NDisCrvTerm);
	LoggingData(szModuleName, szFileName, "DisCrvDayCntType", DisCrvDayCntType);
	LoggingDataArray(szModuleName, szFileName, "RefCrvTerm", NRefCrvTerm, RefCrvTerm);
	LoggingDataArray(szModuleName, szFileName, "RefCrvRate", NRefCrvTerm, RefCrvRate);
	LoggingData(szModuleName, szFileName, "NRefCrvTerm", NRefCrvTerm);
	LoggingData(szModuleName, szFileName, "RefCrvDayCntType", RefCrvDayCntType);
	LoggingData(szModuleName, szFileName, "RefRatePeriod", RefRatePeriod);
	LoggingData(szModuleName, szFileName, "SwapRateFixedPeriod", SwapRateFixedPeriod);
	LoggingData(szModuleName, szFileName, "SwapRateFixedNumCpn", SwapRateFixedNumCpn);
	LoggingData(szModuleName, szFileName, "CpnPeriodType", CpnPeriodType);
	LoggingData(szModuleName, szFileName, "PaiedTime", PaiedTime);
	LoggingData(szModuleName, szFileName, "InArrearFlag", InArrearFlag);
	LoggingData(szModuleName, szFileName, "CpnDayCountType", CpnDayCountType);
	LoggingData(szModuleName, szFileName, "ConvexityAdjustFlag", ConvexityAdjustFlag);
	LoggingData(szModuleName, szFileName, "TimingAdjustFlag", TimingAdjustFlag);
	LoggingData(szModuleName, szFileName, "NCapVolTerm", NCapVolTerm);
	LoggingDataArray(szModuleName, szFileName, "CapVolTerm", NCapVolTerm, CapVolTerm);
	LoggingDataArray(szModuleName, szFileName, "CapVol", NCapVolTerm, CapVol);
	LoggingData(szModuleName, szFileName, "TimingCorr", TimingCorr);
	LoggingData(szModuleName, szFileName, "NSwaptionVolSwapMat", NSwaptionVolSwapMat);
	LoggingData(szModuleName, szFileName, "NSwaptionVolOptMat", NSwaptionVolOptMat);
	LoggingDataArray(szModuleName, szFileName, "SwaptionVolSwapMat", NSwaptionVolSwapMat, SwaptionVolSwapMat);
	LoggingDataArray(szModuleName, szFileName, "SwaptionVolOptMat", NSwaptionVolOptMat, SwaptionVolOptMat);
	LoggingDataArray(szModuleName, szFileName, "SwaptionVol", NSwaptionVolSwapMat*NSwaptionVolOptMat, SwaptionVol);
	LoggingData(szModuleName, szFileName, "NPrinCashFlow", NPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "PrinCashFlow", NPrinCashFlow, PrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "PrinSettleDate", NPrinCashFlow, PrinSettleDate);
	LoggingDataArray(szModuleName, szFileName, "PrinDiscFactor", NPrinCashFlow, PrinDiscFactor);
	LoggingData(szModuleName, szFileName, "NCpnCashFlow", NCpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "ResetFixDate", NCpnCashFlow, ResetFixDate);
	LoggingDataArray(szModuleName, szFileName, "DesignateResetFlag", NCpnCashFlow, DesignateResetFlag);
	LoggingDataArray(szModuleName, szFileName, "ForwardStartDate", NCpnCashFlow, ForwardStartDate);
	LoggingDataArray(szModuleName, szFileName, "ForwardEndDate", NCpnCashFlow, ForwardEndDate);
	LoggingDataArray(szModuleName, szFileName, "NFixDates", NCpnCashFlow, NFixDates);
	LoggingDataArray(szModuleName, szFileName, "NFixedDates", NCpnCashFlow, NFixedDates);
	LoggingDataArray(szModuleName, szFileName, "CpnFromDate", NCpnCashFlow, CpnFromDate);
	LoggingDataArray(szModuleName, szFileName, "CpnToDate", NCpnCashFlow, CpnToDate);
	LoggingDataArray(szModuleName, szFileName, "CpnSettleDate", NCpnCashFlow, CpnSettleDate);
	LoggingDataArray(szModuleName, szFileName, "CpnNA", NCpnCashFlow, CpnNA);
	LoggingDataArray(szModuleName, szFileName, "CpnSlop", NCpnCashFlow, CpnSlope);
	LoggingDataArray(szModuleName, szFileName, "CpnSpread", NCpnCashFlow, CpnSpread);
	LoggingDataArray(szModuleName, szFileName, "CpnRefRate", NCpnCashFlow, CpnRefRate);
	LoggingDataArray(szModuleName, szFileName, "CpnCashFlow", NCpnCashFlow, CpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "CpnDiscFactor", NCpnCashFlow, CpnDiscFactor);
	LoggingData(szModuleName, szFileName, "SOFRUseFlag", SOFRUseFlag);
	LoggingData(szModuleName, szFileName, "DailyRateLoggingFlag", DailyRateLoggingFlag);
	LoggingDataArray(szModuleName, szFileName, "SOFRConv", 4, SOFRConv);
	LoggingData(szModuleName, szFileName, "NHoliday", NHoliday);
	LoggingDataArray(szModuleName, szFileName, "Holiday", NHoliday, Holiday);
	LoggingData(szModuleName, szFileName, "NRefHistory", NRefHistory);
	LoggingDataArray(szModuleName, szFileName, "RefHistoryDate", NRefHistory, RefHistoryDate);
	LoggingDataArray(szModuleName, szFileName, "RefHistory", NRefHistory, RefHistory);
	LoggingData(szModuleName, szFileName, "TextFlag", TextFlag);
	LoggingData(szModuleName, szFileName, "GreekFlag", GreekFlag);
}

long Exception_FRN(
	long PriceDate,				// IN:  ����� (YYYYMMDD)
	double *DisCrvTerm,			// IN:  Discount Rate Curve ����
	double *DisCrvRate,			// IN:  Discount Rate Curve Rate
	long NDisCrvTerm,			// IN;  Discount Rate Curve Term ����
	long DisCrvDayCntType,		// IN:  Discount Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double *RefCrvTerm,			// IN:  Reference Rate Curve ����
	double *RefCrvRate,			// IN:  Reference Rate Curve Rate
	long NRefCrvTerm,			// IN:  Reference Rate Curve Term ����
	long RefCrvDayCntType,		// IN:  Reference Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double RefRatePeriod,		// IN:  Reference Rate �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� Reference Curve�� ǥ���ϴ� Rate�� ���⸦ ��Ÿ�� )
	double SwapRateFixedPeriod,	// IN:  Swap Rate Fixed Leg �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� SwapRateFltPeriod�� �����ϰ� �Է�)
	long SwapRateFixedNumCpn,	// IN:  Swap Rate Fixed Leg ����Ƚ�� (SwapRateFixedPeriod*SwapRateFixedNumCpn = Swap Rate ��� Swap�� ����, 1�ϰ�� �Ϲ� Zero Curve ó��)
	long CpnPeriodType,			// IN:  ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case )
	long PaiedTime,				// IN:  ��/���� ���� ( 1 : ����, 2 : ����)
	long InArrearFlag,			// IN:  In Arrear ���� ( 0 : In Advanced, 1 : In Arrear )
	long CpnDayCountType,		// IN:  Coupon ���� DayCount Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ConvexityAdjustFlag,	// IN:  Convexity Adjustment Flag ( 0 : ��������, 1 : ������, 2: �����ؾ� �Ǵ� ���������� ���� )
	long TimingAdjustFlag,		// IN:  Timing Adjust Flag ( 0 : ��������, 1 : ������, 2: �������������� �������� )
	long NCapVolTerm,			// IN:  Cap Vol �Ⱓ���� ��
	double *CapVolTerm,			// IN:  Cap Vol �Ⱓ����
	double *CapVol,				// IN:  Cap Volatility
	double TimingCorr,			// IN:  Timing Adjustment Corr
	long NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	long NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ����
	double *SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long NPrinCashFlow,			// IN:  �ش� Leg ������� CashFlow ����
	double *PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾�
	long *PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD)
	double *PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor
	long NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ����
	long *ResetFixDate,			// IN:  ������ (YYYYMMDD)
	long *DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ��� )
	long *ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut )
	long *ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut )
	long *NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���)
	long *NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����)
	long *CpnFromDate,			// IN:  ����� (YYYYMMDD)
	long *CpnToDate,			// IN:  �⸻�� (YYYYMMDD)
	long *CpnSettleDate,		// IN:  ������ (YYYYMMDD)
	double *CpnNA,				// IN:  Coupon ���ؿ���
	double *CpnSlope,			// IN:  Coupon �����ݸ� ���� ����
	double *CpnSpread,			// IN:  Coupon �����ݸ� ������
	double *CpnRefRate,			// IN/OUT:  Ȯ���ݸ�
	double *CpnCashFlow,		// IN/OUT:  ��������
	double *CpnDiscFactor,		// OUT: Discount Factor
	long SOFRUseFlag,
	long DailyRateLoggingFlag,	
	long* SOFRConv,
	long NHoliday,				
	long* Holiday,			
	long NRefHistory,
	long* RefHistoryDate,			
	double* RefHistory,
	long TextFlag,				// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	long GreekFlag				// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
)
{
	long i;

	if (SOFRUseFlag < 0 || SOFRUseFlag > 3) return SOFRUSEERROR;
	if (DailyRateLoggingFlag < 0 || DailyRateLoggingFlag > 1) return SOFRLOGGINGERROR;
	
	long LockOutRef = SOFRConv[0];
	long LookBackRef = SOFRConv[1];
	long ObservShiftRef = SOFRConv[2];
	long HolidayFlagRef = SOFRConv[3];

	if (SOFRUseFlag == 1 || SOFRUseFlag == 2)
	{
		if (SOFRConv[0] < 0 || SOFRConv[0] > 40 || SOFRConv[4] < 0 || SOFRConv[4] > 40) return LOCKOUTERROR; 
		if (SOFRConv[1] < 0 || SOFRConv[1] > 40 || SOFRConv[5] < 0 || SOFRConv[5] > 40) return LOOKBACKERROR;
		if (SOFRConv[2] < 0 || SOFRConv[2] > 1 || SOFRConv[6] < 0 || SOFRConv[6] > 1) return OBSERVSHIFTERROR;
		if (SOFRConv[3] < 0 || SOFRConv[3] > 3 || SOFRConv[7] < 0 || SOFRConv[7] > 3) return HOLICALCFLAGERROR;

		for (i = 1 ; i < NHoliday; i++)
		{
			if (Holiday[i] < 0) return HOLIDAY_ERROR;
			if (Holiday[i] < Holiday[i-1]) return HOLIDAY_SORTINGERROR;
		}

		for (i = 1 ; i < NRefHistory; i++)
		{
			if (RefHistoryDate[i] < 0 ) return HISTORY_DATE_ERROR;
			if (RefHistoryDate[i] < RefHistoryDate[i-1]) return HISTORY_SORTING_ERROR;
		}
	}

	// Price Date ����
	if(PriceDate<19000101 || PriceDate>99991231) return PRICE_DATE_ERROR;

	// Discount Curve Term Error
	if(NDisCrvTerm<0) return RCV_LEG_DISCOUNT_RATE_COUNT_ERROR;

	// Reference Curve Term Error
	if(NRefCrvTerm<0) return RCV_LEG_DISCOUNT_RATE_COUNT_ERROR;

	// ������� �����帧 ���� ����
	if(NPrinCashFlow<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR;

	// ���� �����帧 ���� ����
	if(NCpnCashFlow<0) return RCV_LEG_COUPON_CASH_FLOW_COUNT_ERROR;

	// Discount Curve Term Error, Discount Curve Rate Error
	if(DisCrvTerm[0]<0) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
	if(DisCrvRate[0]<-1 || DisCrvRate[0]>1) return RCV_LEG_DISCOUNT_RATE_ERROR;
	for(i=1;i<NDisCrvTerm;i++)
	{
		if(DisCrvTerm[i]<0) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(DisCrvTerm[i]<=DisCrvTerm[i-1]) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(DisCrvRate[i]<-1 || DisCrvRate[i]>1) return RCV_LEG_DISCOUNT_RATE_ERROR;
	}

	// Discount Curve Day Count Type ����
	if(DisCrvDayCntType<1 || DisCrvDayCntType>12) return RCV_LEG_DISCOUNT_DAYCOUNT_TYPE_ERROR;

	// Reference Curve Term Error, Discount Curve Rate Error
	if(RefCrvTerm[0]<0) return RCV_LEG_REF_RATE_TENOR_ERROR;
	if(RefCrvRate[0]<-1 || DisCrvRate[0]>1) return RCV_LEG_REF_RATE_ERROR;
	for(i=1;i<NRefCrvTerm;i++)
	{
		if(RefCrvTerm[i]<0) return RCV_LEG_REF_RATE_TENOR_ERROR;
		if(RefCrvTerm[i]<=RefCrvTerm[i-1]) return RCV_LEG_REF_RATE_TENOR_ERROR;
		if(RefCrvRate[i]<-1 || RefCrvRate[i]>1) return RCV_LEG_REF_RATE_ERROR;
	}

	// Reference Curve Day Count Type ����
	if(RefCrvDayCntType<1 || RefCrvDayCntType>12) return RCV_LEG_REF_DAYCOUNT_TYPE_ERROR;

	// Ref Curve, Rate �����ֱ� ���� ����
	if(RefRatePeriod<=0 || RefRatePeriod>999) return RCV_LEG_REF_CURVE_PERIOD_ERROR;

	// Swap Rate �����ݸ� �����ֱ� ����
	if(SwapRateFixedPeriod<=0 || SwapRateFixedPeriod>999) return RCV_LEG_SWAP_RATE_FIXED_PERIOD_ERROR;

	// Swap Rate �����ݸ� ���� Ƚ�� ����
	if(SwapRateFixedNumCpn<1 || SwapRateFixedNumCpn>9999) return RCV_LEG_SWAP_RATE_FIXED_NUM_COUPON_ERROR;

	// ����/�������� ����
	if(CpnPeriodType!=1 && CpnPeriodType!= 2 && CpnPeriodType!= 3) return RCV_LEG_COUPON_PERIOD_TYPE_ERROR;

	// Coupon ��/���� Flag ����
	if(PaiedTime!=1 && PaiedTime!=2 && PaiedTime!=3) return RCV_LEG_COUPON_PAIED_TIME_ERROR;

	// In Arrear Flag ����
	if(InArrearFlag!=0 && InArrearFlag!=1 && InArrearFlag!=2) return RCV_LEG_IN_ARREAR_FLAG_ERROR;

	// Coupon Day Count Type ����
	if(CpnDayCountType<1 || CpnDayCountType>12) return RCV_LEG_COUPON_DAYCOUNT_TYPE_ERROR;


	// Convexity Adjust Flag ����
	if(ConvexityAdjustFlag!=0 && ConvexityAdjustFlag!=1 && ConvexityAdjustFlag !=2) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;

	// Timing Adjust Flag ����
	if(TimingAdjustFlag!=0 && TimingAdjustFlag!=1 && TimingAdjustFlag != 2) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;

	// Adjust ��� �����ε� üũ���� �ʾ��� ��쿡 ���� ����üũ
	if(CpnPeriodType!=1) // �����ÿ��� üũ
	{
		if(SwapRateFixedNumCpn == 1)
		{
			if( (PaiedTime==1 && InArrearFlag==0) || (PaiedTime==2 && InArrearFlag==1) )
			{
				if(ConvexityAdjustFlag==0&& SOFRUseFlag == 0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;
			}
		}
		else
		{
			if(ConvexityAdjustFlag==0 && SOFRUseFlag == 0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR; // Swap�ݸ��ӿ��� Convexity������ ���� �ʴ°�� ����
		}

		if(SwapRateFixedNumCpn != 1 && InArrearFlag==0 && PaiedTime==2 && TimingAdjustFlag==0 && SOFRUseFlag == 0) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;

		// Cap �������� �ʿ��� ��� ����üũ
		if( (SwapRateFixedNumCpn==1 && (TimingAdjustFlag == 1 || ConvexityAdjustFlag==1) ) || ( SwapRateFixedNumCpn != 1 && TimingAdjustFlag==1) )
		{
			// Cap Vol ���� ����
			if(NCapVolTerm<1) return RCV_LEG_CAP_COUNT_ERROR;

			for(i=0;i<NCapVolTerm;i++)
			{
				// Cap ������ �Ⱓ���� ����
				if(CapVolTerm[i] < 0) return RCV_LEG_CAP_MAT_ERROR;
				if(i!=0)
				{
					if(CapVolTerm[i]<=CapVolTerm[i-1]) return RCV_LEG_CAP_MAT_ERROR;
				}

				// Cap ������ ����
				if(CapVol[i]<0.0 || CapVol[i]>10.0) return RCV_LEG_CAP_VOL_ERROR;

			}
		}

		// Swaption �������� �ʿ��� ��� ����üũ
		if( SwapRateFixedNumCpn != 1 && ( ConvexityAdjustFlag==1 || TimingAdjustFlag==1) )
		{
			// Swaption Vol ���� ���� 
			if(NSwaptionVolSwapMat<1) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
			if(NSwaptionVolOptMat<1) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;

			// Timing Adjust �� ����ϴ� Correlation ����
			if(TimingCorr<-1 || TimingCorr>1) return RCV_LEG_TIMING_CORRELATION_ERROR;

			// Swaption Vol�� Swap���⿡��
			for(i=0;i<NSwaptionVolSwapMat;i++)
			{
				if(SwaptionVolSwapMat[i]<0) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(SwaptionVolSwapMat[i-1]>=SwaptionVolSwapMat[i]) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
				}
			}

			// Swaption Vol�� Option ���� ����
			for(i=0;i<NSwaptionVolOptMat;i++)
			{
				if(SwaptionVolOptMat[i]<0) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(SwaptionVolOptMat[i-1]>=SwaptionVolOptMat[i]) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
				}
			}

			// Swaption Vol ����
			for(i=0;i<NSwaptionVolSwapMat*NSwaptionVolOptMat;i++)
			{
				if(SwaptionVol[i]<=0 || SwaptionVol[i]>10.0) return RCV_LEG_SWAPTION_VOL_ERROR;
			}
		}
	}
	
	for(i=0;i<NPrinCashFlow;i++)
	{
		// ���� ���� �ݾ� ����
		//if(PrinCashFlow[i]<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_ERROR;

		// ���� ������ ����
		if(PrinSettleDate[i]<19000101 || PrinSettleDate[i] > 99991231) return RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		if(i!=0)
		{
			if(PrinSettleDate[i]<PrinSettleDate[i-1]) return RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		}

		// ���� Discount Factor �Է��ʱ�ȭ ����
		if(PrinDiscFactor[i]!=0) return RCV_LEG_PRINCIPAL_DISCOUNT_ERROR;
	}

	for(i=0;i<NCpnCashFlow;i++)
	{
		if(CpnPeriodType!=1) // �����϶��� üũ 
		{
			// ���� Fix�� ����
			if(ResetFixDate[i]<19000101 || ResetFixDate[i]>99991231) return RCV_LEG_RESET_FIX_DATE_ERROR;
			if(i!=0 && DesignateResetFlag[i] != 2)
			{
				if(ResetFixDate[i]<ResetFixDate[i-1]) return RCV_LEG_RESET_FIX_DATE_ERROR;
				//if(ResetFixDate[i]==ResetFixDate[i-1] && DesignateResetFlag[i]==0)  return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
			}

			// ������ �Է� Flag
			if(DesignateResetFlag[i] != 0 && DesignateResetFlag[i] != 1 && DesignateResetFlag[i] != 2) return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
			if(DesignateResetFlag[i] == 2)
			{
				if(InArrearFlag != 2) return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
			}


			// Forward Rate ��� ������ ����
			if(DesignateResetFlag[i]==1)
			{
				if(ForwardStartDate[i]<19000101 || ForwardStartDate[i]>99991231) return RCV_LEG_FORWARD_START_DATE_ERROR;
				if(ForwardEndDate[i]<19000101 || ForwardEndDate[i]>99991231) return RCV_LEG_FORWARD_START_DATE_ERROR;
				if(ForwardStartDate[i]>=ForwardEndDate[i]) return RCV_LEG_FORWARD_START_DATE_ERROR;
				if(ResetFixDate[i]>ForwardStartDate[i]) return RCV_LEG_FORWARD_START_DATE_ERROR;
			}

			// Average Reset Fix �ϼ� ����
			if(NFixDates[i]<1) return RCV_LEG_NUM_FIXING_DATE_ERROR;

			// ������ Average Reset Fix �ϼ� ����
			if (SOFRUseFlag == 0)
			{
				if(NFixedDates[i]<0 || NFixedDates[i]>NFixDates[i]) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				if(NFixDates[i] != NFixedDates[i])
				{
					if(ActDateAdjust(ResetFixDate[i],-(NFixDates[i]-NFixedDates[i])+1)<PriceDate) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				}
				else
				{
					if(ResetFixDate[i]>PriceDate) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				}
			}
		}

		// ����� ����
		if(CpnFromDate[i]<19000101 || CpnFromDate[i]>99991231) return RCV_LEG_COUPON_FORM_DATE_ERROR;
		if(i!=0)
		{
			if(CpnFromDate[i]<=CpnFromDate[i-1]) return RCV_LEG_COUPON_FORM_DATE_ERROR;
		}
		
		// �⸻�� ����
		if(CpnToDate[i]<19000101 || CpnToDate[i]>99991231) return RCV_LEG_COUPON_TO_DATE_ERROR;
		if(i!=0)
		{
			if(CpnToDate[i]<=CpnToDate[i-1]) return RCV_LEG_COUPON_TO_DATE_ERROR;
		}

		if(CpnFromDate[i]>=CpnToDate[i]) return RCV_LEG_COUPON_TO_DATE_ERROR;

		if(DesignateResetFlag[i]==0)
		{
			if(InArrearFlag==0)
			{
				if(ResetFixDate[i]>=CpnToDate[i]) return RCV_LEG_RESET_FIX_DATE_ERROR;
			}
			else if(InArrearFlag==1)
			{
				if(ResetFixDate[i]<=CpnFromDate[i]) return RCV_LEG_RESET_FIX_DATE_ERROR;
			}
		}

		// �������ΰ� üũ�Ǿ����� ���� ��� ����
		if(SwapRateFixedNumCpn==1 && CpnPeriodType!=1)
		{
			// Curve�� �������ޱ����� ���������Ⱓ����  1.25�� �̻� �� ��� Convexity ���� ���� ����
			if(RefRatePeriod/DayCountFraction(CpnFromDate[i],CpnToDate[i],RefCrvDayCntType) > 1.25)
				if(ConvexityAdjustFlag==0 && SOFRUseFlag == 0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;

			// ���������Ⱓ�� Curve�� �������ޱ������� 1.25�� �̻� �� ��� Timing ���� ���� ����
			if(DayCountFraction(CpnFromDate[i],CpnToDate[i],RefCrvDayCntType)/RefRatePeriod > 1.25)
				if(TimingAdjustFlag==0) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;
		}

		// ������ ����
		if(CpnSettleDate[i]<19000101 || CpnSettleDate[i]>99991231) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;

		if(i!=0 && PaiedTime != 3)
		{
			if(CpnSettleDate[i]<CpnSettleDate[i-1]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		if(PaiedTime==1) // ����� �⸻�Ϻ��� �տ��־�� �ϰ�,
		{
			if(CpnSettleDate[i]>=CpnToDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		else if(PaiedTime==2)// ����� ����Ϻ��� �ڿ��־�� �Ѵ�.
		{
			if(CpnSettleDate[i]<=CpnFromDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		// ��� ���� ������ ������ �� �ǹ̰� ������ ������ �� ������, �����ϰԳ��� ����üũ�� �ϰ�,
		// Timing adjust�� ���� ��뿩�� ������ ���� �Է°��̴�.

		if(CpnPeriodType != 1)
		{
			if(ResetFixDate[i]>CpnSettleDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		// Coupon ���ؿ��� ����
		if(CpnNA[i]<0) return RCV_LEG_COUPON_NOTIONAL_AMOUNT_ERROR;

		// Coupon Slope ����
		if(CpnPeriodType == 1)
		{
			if(CpnSlope[i] != 0) return RCV_LEG_COUPON_SLOPE_ERROR;
		}
		else if(CpnPeriodType == 2)
		{
			if(CpnSlope[i] != 1) return RCV_LEG_COUPON_SLOPE_ERROR;
		}

		// Coupon Spread ����
		if(CpnSpread[i]<-1 || CpnSpread[i]>1) return RCV_LEG_COUPON_SPREAD_ERROR;

		if(CpnPeriodType != 1) // �����϶��� üũ
		{
			// Ȯ���ݸ� ����
			if(CpnRefRate[i]<-1 || CpnRefRate[i]>1 ) return RCV_LEG_COUPON_COUPON_RATE_ERROR;
			if( (ResetFixDate[i]<PriceDate && PriceDate<CpnSettleDate[i]) && CpnRefRate[i]==0) return RCV_LEG_COUPON_COUPON_RATE_ERROR; // ���� Fix���� ���������� Ȯ���ݸ��� �Էµ��� �ʾҴٸ� ����
		}

		// �������� ����
		//if(CpnCashFlow[i]<0) return RCV_LEG_COUPON_CASH_FLOW_ERROR;

		// Discount Factor �ʱ�ȭ ����
		if(CpnDiscFactor[i] != 0) return RCV_LEG_COUPON_DISCOUNT_FACTOR_ERROR;
	}

	// TextDump ��¿���
	if(TextFlag != 0 && TextFlag != 1) return TEXT_FLAG_ERROR;

	// Greek ��� ���� Flag
	if(GreekFlag != 0 && GreekFlag != 1) return GREEK_FLAG_ERROR;

	return CORRECT;
}

// Leg��� �Լ��� �̿��Ͽ� Floating Rate Note ��� 
DLLEXPORT (long) KISP_CalcFRN(
	long PriceDate,				// IN:  ����� (YYYYMMDD)
	double *DisCrvTerm,			// IN:  Discount Rate Curve ����
	double *DisCrvRate,			// IN:  Discount Rate Curve Rate
	long NDisCrvTerm,			// IN;  Discount Rate Curve Term ����
	long DisCrvDayCntType,		// IN:  Discount Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double *RefCrvTerm,			// IN:  Reference Rate Curve ����
	double *RefCrvRate,			// IN:  Reference Rate Curve Rate
	long NRefCrvTerm,			// IN:  Reference Rate Curve Term ����
	long RefCrvDayCntType,		// IN:  Reference Rate Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double RefRatePeriod,		// IN:  Reference Rate �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� Reference Curve�� ǥ���ϴ� Rate�� ���⸦ ��Ÿ�� )

	double SwapRateFixedPeriod,	// IN:  Swap Rate Fixed Leg �����ֱ� (������) ( SwapRateFixedNumCpn=1�϶� SwapRateFltPeriod�� �����ϰ� �Է�)
	long SwapRateFixedNumCpn,	// IN:  Swap Rate Fixed Leg ����Ƚ�� (SwapRateFixedPeriod*SwapRateFixedNumCpn = Swap Rate ��� Swap�� ����, 1�ϰ�� �Ϲ� Zero Curve ó��)
	long CpnPeriodType,			// IN:  ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case )
	long PaiedTime,				// IN:  ��/���� ���� ( 1 : ����, 2 : ����)
	long InArrearFlag,			// IN:  In Arrear ���� ( 0 : In Advanced, 1 : In Arrear )
	long CpnDayCountType,		// IN:  Coupon ���� DayCount Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ConvexityAdjustFlag,	// IN:  Convexity Adjustment Flag ( 0 : ��������, 1 : ������, 2: �����ؾ� �Ǵ� ���������� ���� )
	long TimingAdjustFlag,		// IN:  Timing Adjust Flag ( 0 : ��������, 1 : ������, 2: �������������� �������� )
	long NCapVolTerm,			// IN:  Cap Vol �Ⱓ���� ��
	double *CapVolTerm,			// IN:  Cap Vol �Ⱓ����
	
	double *CapVol,				// IN:  Cap Volatility
	double TimingCorr,			// IN:  Timing Adjustment Corr
	long NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	long NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ����
	double *SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long NPrinCashFlow,			// IN:  �ش� Leg ������� CashFlow ����
	double *PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾�
	long *PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD)
	
	double *PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor
	long NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ����
	long *ResetFixDate,			// IN:  ������ (YYYYMMDD)
	long *DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ��� )
	long *ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut )
	long *ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut )
	long *NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���)
	long *NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����)
	long *CpnFromDate,			// IN:  ����� (YYYYMMDD)
	long *CpnToDate,			// IN:  �⸻�� (YYYYMMDD)
	
	long *CpnSettleDate,		// IN:  ������ (YYYYMMDD)
	double *CpnNA,				// IN:  Coupon ���ؿ���
	double *CpnSlope,			// IN:  Coupon �����ݸ� ���� ����
	double *CpnSpread,			// IN:  Coupon �����ݸ� ������
	double *CpnRefRate,			// IN/OUT:  Ȯ���ݸ�
	double *CpnCashFlow,		// IN/OUT:  ��������
	double *CpnDiscFactor,		// OUT: Discount Factor
	long SOFRUseFlag,			// SOFR ��뿩��
	long* SOFRConv,	
	long NHoliday,	

	long* Holiday,			
	long NRefHistory,
	long* RefHistoryDate,			
	double* RefHistory,
	long TextFlag,				// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	long GreekFlag,				// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
	double *PV01,				// OUT: DIscount Curve, Ref Curve PVBP
	double *KeyRateDuration,	// OUT: Key Rate Duration
	double *KeyRateConvexity,	// OUT: Key Rate Convextiy
	double *ResultPrice			// OUT: ����� ���
)
{
	char szModuleName[] = "FRN";
	char szFileName[100];
	get_filename(szFileName, szModuleName);

	long DailyRateLoggingFlag = 0;
	long InterpolationFlag = 0;

	if (SOFRUseFlag == 10) 
	{
		DailyRateLoggingFlag = 0;
		SOFRUseFlag = 0;
		InterpolationFlag = 0;
	}
	else if (SOFRUseFlag == 11)
	{
		DailyRateLoggingFlag = 1;
		SOFRUseFlag = 1;
		InterpolationFlag = 0;
	}
	else if (SOFRUseFlag == 20)
	{
		DailyRateLoggingFlag = 0;
		SOFRUseFlag = 0;
		InterpolationFlag = 1;
	}
	else if (SOFRUseFlag == 21)
	{
		DailyRateLoggingFlag = 0;
		SOFRUseFlag = 1;
		InterpolationFlag = 1;
	}
	else if (SOFRUseFlag == 22)
	{
		DailyRateLoggingFlag = 0;
		SOFRUseFlag = 2;
		InterpolationFlag = 1;
	}
	else if (SOFRUseFlag == 31)
	{
		DailyRateLoggingFlag = 1;
		SOFRUseFlag = 1;
		InterpolationFlag = 1;
	}


	if(TextFlag == 1)
	{
		InputCheck_FRN(	PriceDate,				DisCrvTerm,				DisCrvRate,				NDisCrvTerm,			DisCrvDayCntType,
						RefCrvTerm,				RefCrvRate,				NRefCrvTerm,			RefCrvDayCntType,		RefRatePeriod,
						SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,				InArrearFlag,
						CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,			CapVolTerm,
						CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,		SwaptionVolSwapMat,
						SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,			PrinSettleDate,
						PrinDiscFactor,			NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,		ForwardStartDate,
						ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,			CpnToDate,
						CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,				CpnRefRate,
						CpnCashFlow,			CpnDiscFactor,			SOFRUseFlag,			DailyRateLoggingFlag,	SOFRConv,
						NHoliday,				Holiday,				NRefHistory,			RefHistoryDate,			RefHistory,
						TextFlag,				GreekFlag,				szFileName,				szModuleName			);
	}

	long ResultCode = -1;

	ResultCode = Exception_FRN(	PriceDate,				DisCrvTerm,				DisCrvRate,				NDisCrvTerm,			DisCrvDayCntType,
								RefCrvTerm,				RefCrvRate,				NRefCrvTerm,			RefCrvDayCntType,		RefRatePeriod,
								SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,				InArrearFlag,
								CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,			CapVolTerm,
								CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,		SwaptionVolSwapMat,
								SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,			PrinSettleDate,
								PrinDiscFactor,			NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,		ForwardStartDate,
								ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,			CpnToDate,
								CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,				CpnRefRate,
								CpnCashFlow,			CpnDiscFactor,			SOFRUseFlag,			DailyRateLoggingFlag,	SOFRConv,
								NHoliday,				Holiday,				NRefHistory,			RefHistoryDate,			RefHistory,
								TextFlag,				GreekFlag				);

	if(ResultCode<0)
	{
		if(TextFlag==1)
			LoggingData(szModuleName, szFileName, "ErrorCode", ResultCode);
		return ResultCode;
	}

	long i, j;
	double RATE_EPS = 0.0001;
	double *Price_AllRateUpValue;
	double *Price_AllRateDownValue;
	double *DisCrvRate_Up;
	double *DisCrvRate_Dn;
	double *RefCrvRate_Up;
	double *RefCrvRate_Dn;

	double *PrinDiscFactor_Temp;
	double *CpnRefRate_Temp;
	double *CpnCashFlow_Temp;
	double *CpnDiscFactor_Temp;

	double *CpnRefRate_Org;
	double *CpnCashFlow_Org;

	// NCpnCashFlow�� 0�� �ԷµǾ����� ���������� ���� +1���� �� �����
	CpnRefRate_Org = (double *)malloc((NCpnCashFlow+1)*sizeof(double));
	CpnCashFlow_Org = (double *)malloc((NCpnCashFlow+1)*sizeof(double));

	for(i=0;i<NCpnCashFlow;i++)
	{
		CpnRefRate_Org[i] =  CpnRefRate[i];
		CpnCashFlow_Org[i] = CpnCashFlow[i];
	}

	ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate,				NDisCrvTerm,		DisCrvDayCntType,
								RefCrvTerm,				RefCrvRate,				NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
								SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
								CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
								CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
								SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
								PrinDiscFactor,			NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
								ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
								CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
								DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
								RefHistoryDate,			RefHistory,				CpnRefRate,				CpnCashFlow,		CpnDiscFactor,			
								ResultPrice,			InterpolationFlag,		szFileName,				szModuleName);

	// ���⼭���� Logging ������
	DailyRateLoggingFlag = 0;

	if(GreekFlag==1 && ResultCode>=0)
	{
		// NPrinCashFlow or NCpnCashFlow�� 0�� �ԷµǾ����� ���������� ���� +1���� �� �����
		PrinDiscFactor_Temp = (double *)malloc((NPrinCashFlow+1)*sizeof(double));
		CpnRefRate_Temp = (double *)malloc((NCpnCashFlow+1)*sizeof(double));
		CpnCashFlow_Temp = (double *)malloc((NCpnCashFlow+1)*sizeof(double));
		CpnDiscFactor_Temp = (double *)malloc((NCpnCashFlow+1)*sizeof(double));
		for(i=0;i<NPrinCashFlow;i++)
		{
			PrinDiscFactor_Temp[i] =  0.0;
		}

		for(i=0;i<NCpnCashFlow;i++)
		{
			CpnRefRate_Temp[i] =  CpnRefRate_Org[i];
			CpnCashFlow_Temp[i] = CpnCashFlow_Org[i];
			CpnDiscFactor_Temp[i] = 0.0;
		}

		Price_AllRateUpValue = (double *)malloc(2*sizeof(double));
		Price_AllRateDownValue = (double *)malloc(2*sizeof(double));
		for(i=0;i<2;i++)
		{
			Price_AllRateUpValue[i] = 0.0;
			Price_AllRateDownValue[i] = 0.0;
		}

		DisCrvRate_Up = (double *)malloc(NDisCrvTerm*sizeof(double));
		DisCrvRate_Dn = (double *)malloc(NDisCrvTerm*sizeof(double));
		RefCrvRate_Up = (double *)malloc(NRefCrvTerm*sizeof(double));
		RefCrvRate_Dn = (double *)malloc(NRefCrvTerm*sizeof(double));
		for(i=0;i<NDisCrvTerm;i++)
		{
			DisCrvRate_Up[i] = DisCrvRate[i]+0.0001;
			DisCrvRate_Dn[i] = DisCrvRate[i]-0.0001;
		}

		for(i=0;i<NRefCrvTerm;i++)
		{
			RefCrvRate_Up[i] = RefCrvRate[i]+0.0001;
			RefCrvRate_Dn[i] = RefCrvRate[i]-0.0001;
		}

		ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate_Up,			NDisCrvTerm,		DisCrvDayCntType,
									RefCrvTerm,				RefCrvRate_Up,			NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
									SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
									CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
									CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
									SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
									PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
									ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
									CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
									DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
									RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
									Price_AllRateUpValue,	InterpolationFlag,		szFileName,				szModuleName			);

		for(i=0;i<NPrinCashFlow;i++)
		{
			PrinDiscFactor_Temp[i] =  0.0;
		}

		for(i=0;i<NCpnCashFlow;i++)
		{
			CpnRefRate_Temp[i] =  CpnRefRate_Org[i];
			CpnCashFlow_Temp[i] = CpnCashFlow_Org[i];
			CpnDiscFactor_Temp[i] = 0.0;
		}

		ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate_Dn,			NDisCrvTerm,		DisCrvDayCntType,
									RefCrvTerm,				RefCrvRate_Dn,			NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
									SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
									CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
									CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
									SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
									PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
									ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
									CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
									DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
									RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
									Price_AllRateDownValue,	InterpolationFlag,		szFileName,				szModuleName	);

		ResultPrice[2] = -(Price_AllRateUpValue[0] - Price_AllRateDownValue[0])/(2*0.0001*ResultPrice[0]); // Effective Duration
		ResultPrice[3] = (Price_AllRateUpValue[0] + Price_AllRateDownValue[0] - 2 * ResultPrice[0]) / (2 * 0.0001*0.0001 * ResultPrice[0]); // Effective Convexity

		// Dis Curve PV01, KeyRate Duration
		for(i=0;i<NDisCrvTerm;i++)
		{
			// �� �ʱ�ȭ
			for(j=0;j<NPrinCashFlow;j++)
			{
				PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<NCpnCashFlow;j++)
			{
				CpnRefRate_Temp[j] =  CpnRefRate_Org[j];
				CpnCashFlow_Temp[j] = CpnCashFlow_Org[j];
				CpnDiscFactor_Temp[j] = 0.0;
			}
			
			for(j=0;j<2;j++)
			{
				Price_AllRateUpValue[j] = 0.0;
				Price_AllRateDownValue[j] = 0.0;
			}

			for(j=0;j<NDisCrvTerm;j++)
			{
				if(i==j)
				{
					DisCrvRate_Up[j] = DisCrvRate[j]+0.0001;
					DisCrvRate_Dn[j] = DisCrvRate[j]-0.0001;
				}
				else
				{
					DisCrvRate_Up[j] = DisCrvRate[j];
					DisCrvRate_Dn[j] = DisCrvRate[j];
				}
			}

			ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate_Up,			NDisCrvTerm,		DisCrvDayCntType,
										RefCrvTerm,				RefCrvRate,				NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
										SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
										CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
										CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
										SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
										PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
										ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
										CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
										DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
										RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
										Price_AllRateUpValue,	InterpolationFlag,		szFileName,				szModuleName			);

			for(j=0;j<NPrinCashFlow;j++)
			{
				PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<NCpnCashFlow;j++)
			{
				CpnRefRate_Temp[j] =  CpnRefRate_Org[j];
				CpnCashFlow_Temp[j] = CpnCashFlow_Org[j];
				CpnDiscFactor_Temp[j] = 0.0;
			}

			ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate_Dn,			NDisCrvTerm,		DisCrvDayCntType,
										RefCrvTerm,				RefCrvRate,				NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
										SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
										CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
										CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
										SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
										PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
										ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
										CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
										DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
										RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
										Price_AllRateDownValue,	InterpolationFlag,		szFileName,				szModuleName			);


			// PV01
			PV01[i] = Price_AllRateUpValue[0] - ResultPrice[0];

			// Dis KeyRate Effective Duration
			KeyRateDuration[i] =  -(Price_AllRateUpValue[0] - Price_AllRateDownValue[0])/(2*0.0001*ResultPrice[0]);

			// Dis KeyRate Effective Convexity
			KeyRateConvexity[i] = (Price_AllRateUpValue[0] + Price_AllRateDownValue[0] - 2 * ResultPrice[0]) / (2 * 0.0001*0.0001 * ResultPrice[0]); 
		}

		//Ref Curve PV01, KeyRate Duration
		for(i=0;i<NRefCrvTerm;i++)
		{
			// �� �ʱ�ȭ
			for(j=0;j<NPrinCashFlow;j++)
			{
				PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<NCpnCashFlow;j++)
			{
				CpnRefRate_Temp[j] =  CpnRefRate_Org[j];
				CpnCashFlow_Temp[j] = CpnCashFlow_Org[j];
				CpnDiscFactor_Temp[j] = 0.0;
			}
			
			for(j=0;j<2;j++)
			{
				Price_AllRateUpValue[j] = 0.0;
				Price_AllRateDownValue[j] = 0.0;
			}

			for(j=0;j<NRefCrvTerm;j++)
			{
				if(i==j)
				{
					RefCrvRate_Up[j] = RefCrvRate[j]+0.0001;
					RefCrvRate_Dn[j] = RefCrvRate[j]-0.0001;
				}
				else
				{
					RefCrvRate_Up[j] = RefCrvRate[j];
					RefCrvRate_Dn[j] = RefCrvRate[j];
				}
			}

			ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate,				NDisCrvTerm,		DisCrvDayCntType,
										RefCrvTerm,				RefCrvRate_Up,			NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
										SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
										CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
										CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
										SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
										PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
										ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
										CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
										DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
										RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
										Price_AllRateUpValue,	InterpolationFlag,		szFileName,				szModuleName			);

			for(j=0;j<NPrinCashFlow;j++)
			{
				PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<NCpnCashFlow;j++)
			{
				CpnRefRate_Temp[j] =  CpnRefRate_Org[j];
				CpnCashFlow_Temp[j] = CpnCashFlow_Org[j];
				CpnDiscFactor_Temp[j] = 0.0;
			}

			ResultCode = IR_Leg_Value(	PriceDate,				DisCrvTerm,				DisCrvRate,				NDisCrvTerm,		DisCrvDayCntType,
										RefCrvTerm,				RefCrvRate_Dn,			NRefCrvTerm,			RefCrvDayCntType,	RefRatePeriod,
										SwapRateFixedPeriod,	SwapRateFixedNumCpn,	CpnPeriodType,			PaiedTime,			InArrearFlag,
										CpnDayCountType,		ConvexityAdjustFlag,	TimingAdjustFlag,		NCapVolTerm,		CapVolTerm,
										CapVol,					TimingCorr,				NSwaptionVolSwapMat,	NSwaptionVolOptMat,	SwaptionVolSwapMat,
										SwaptionVolOptMat,		SwaptionVol,			NPrinCashFlow,			PrinCashFlow,		PrinSettleDate,
										PrinDiscFactor_Temp,	NCpnCashFlow,			ResetFixDate,			DesignateResetFlag,	ForwardStartDate,
										ForwardEndDate,			NFixDates,				NFixedDates,			CpnFromDate,		CpnToDate,
										CpnSettleDate,			CpnNA,					CpnSlope,				CpnSpread,			SOFRUseFlag,
										DailyRateLoggingFlag,	SOFRConv,				NHoliday,				Holiday,			NRefHistory,
										RefHistoryDate,			RefHistory,				CpnRefRate_Temp,		CpnCashFlow_Temp,	CpnDiscFactor_Temp,		
										Price_AllRateDownValue,	InterpolationFlag,		szFileName,				szModuleName			);

			// Ref PV01
			PV01[NDisCrvTerm+i] = Price_AllRateUpValue[0] - ResultPrice[0];

			// Ref KeyRate Effective Duration
			KeyRateDuration[NDisCrvTerm+i] =  -(Price_AllRateUpValue[0] - Price_AllRateDownValue[0])/(2*0.0001*ResultPrice[0]);

			// Ref KeyRate Effective Convexity
			KeyRateConvexity[NDisCrvTerm+i] = (Price_AllRateUpValue[0] + Price_AllRateDownValue[0] - 2 * ResultPrice[0]) / (2 * 0.0001*0.0001 * ResultPrice[0]); 
		}
		
		if(PrinDiscFactor_Temp) free(PrinDiscFactor_Temp);
		if(CpnRefRate_Temp) free(CpnRefRate_Temp);
		if(CpnCashFlow_Temp) free(CpnCashFlow_Temp);
		if(CpnDiscFactor_Temp) free(CpnDiscFactor_Temp);

		if(Price_AllRateUpValue) free(Price_AllRateUpValue);
		if(Price_AllRateDownValue) free(Price_AllRateDownValue);

		if(DisCrvRate_Up) free(DisCrvRate_Up);
		if(DisCrvRate_Dn) free(DisCrvRate_Dn);
		if(RefCrvRate_Up) free(RefCrvRate_Up);
		if(RefCrvRate_Dn) free(RefCrvRate_Dn);
	}

	if(TextFlag==1)
	{
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_PrinCashFlow", NPrinCashFlow, PrinCashFlow);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_PrinDiscFactor", NPrinCashFlow, PrinDiscFactor);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_CpnRefRate", NCpnCashFlow, CpnRefRate);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_CpnCouponFlow", NCpnCashFlow, CpnCashFlow);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_CpnDiscFactor", NCpnCashFlow, CpnDiscFactor);
		if(GreekFlag==1)
		{
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_PV01", NDisCrvTerm+NRefCrvTerm, PV01); // Basis Point Value
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_KeyRateDuartion", NDisCrvTerm+NRefCrvTerm, KeyRateDuration); // KeyRate Duration
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_KeyRateConvexity", NDisCrvTerm+NRefCrvTerm, KeyRateConvexity); // KeyRate Convexity
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_ResultPrice", 4, ResultPrice);
		}
		else
		{
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_ResultPrice", 2, ResultPrice);
		}
	}

	if(CpnRefRate_Org) free(CpnRefRate_Org);
	if(CpnCashFlow_Org) free(CpnCashFlow_Org);

	return ResultCode;
}


/////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                         //
//                ���� Leg�� ���� Leg�Լ��� �����Ͽ� IR Swap ���					       //
//                                                                                         //
/////////////////////////////////////////////////////////////////////////////////////////////

void InputCheck_IRSwap(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	long NCurveIndex,				// IN:  �Է� Curve ����
	long *NCurve,					// IN:  Curve �� (0, 1, 2, 3)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,			// IN:  Curve ����
	double *CurveRateInfo,			// IN:  Curve Rate ( 0.01(1%)������ �Է�) 
	long *CrvDayCntType,			// IN:  Curve Day Count Type  ( ũ�� : NCurveIndex )
	long NCrcyIndex,				// IN:  �Է� ��ȭ ����
	double *FXRateInfo,				// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,				// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,			// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )
	double *Leg_RefRatePeriod,		// IN:  Leg �� Ref Rate �����ֱ�(��) ( [0] : Rcv Ref Rate �����ֱ�, [1] : Pay Ref Rate �����ֱ� )
	double *Leg_SwapRateFixedPeriod,// IN:  Leg �� Swap Rate Fixed Leg �����ֱ�(��) ( [0] : Rcv Ref Curve �����ֱ�, [1] : Pay Ref Curve �����ֱ� )
	long *Leg_SwapRateFixedNumCpn,	// IN:  Leg �� Swap Rate Fixed Leg ����Ƚ��  ( [0] : Rcv Ref Curve ���� ���� Ƚ��, [1] : Pay Ref Curve ���� ���� Ƚ�� )
	long *Leg_CpnPeriodType,		// IN:  ����/���� ���� ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case ) ( [0] : Rcv ����/��������, [1] : Pay ����/���� ���� )
	long *Leg_PaiedTime,			// IN:  Leg �� ��/���� ���� ( 1 : ����, 2 : ����)
	long *Leg_InArrearFlag,			// IN:  Leg �� In Arrear ���� ( 0 : In Advanced, 1 : In Arrear )
	long *Leg_CpnDayCntType,		// IN:  Leg �� ���� Day Count Convention ( ũ�� : 2 )
	long *Leg_AdjustFlag,			// IN:  Leg �� Adjustment ���� ( [0] : Rcv Convexity Adjust, [1] : Rcv Timing Adjust, [2] : Pay Convexity Adjust, [3] : Pay Timing Adjust )
	long *Leg_NCapVol,				// IN:  Leg �� Cap Vol ��
	double *Leg_CapVolTerm,			// IN:  Ref Curve Rate Cap Vol Term (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	double *Leg_CapVol,				// IN:  Ref Curve Rate Cap Vol (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	double *Leg_TimingCorr,			// IN:  Timing Adjustment Corr ( [0] : Rcv Forward Corr, [1] : Pay Forward Corr )
	long *Leg_NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv)
	long *Leg_NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv )
	double *Leg_SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *Leg_SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *Leg_SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long *Leg_NPrinCashFlow,		// IN:  Leg�� ������� ( [0] : Rcv ������� ���� ��, [1] : Pay ������� ���� �� )
	double *Leg_PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾� ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD) ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	double *Leg_PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ���� ( [0] : Rcv Coupon �����帧 ����, [1] : Pay Coupon �����帧 ���� )
	long *Leg_ResetFixDate,			// IN:  ������ (YYYYMMDD)  ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ��� ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnFromDate,			// IN:  ����� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnToDate,			// IN:  �⸻�� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnSettleDate,		// IN:  ������ (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnNA,				// IN:  Coupon ���ؿ��� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSlope,			// IN:  Coupon �����ݸ� ���� ���� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSpread,			// IN:  Coupon �����ݸ� ������ ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnRefRate,			// IN/OUT:  Ȯ���ݸ� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnCashFlow,		// IN/OUT:  �������� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnDiscFactor,		// OUT: Discount Factor ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long* SOFRFlags,				// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag
	long* SOFRConv,					// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,				// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����
	long* Holiday,					// IN: Holiday Rcv,Pay
	long* RefRateHistoryCount,		// IN: [0]RcvRefRateHistoryCount, [1]PayRefRateHistoryCount
	long* RefRateHistoryDate,		// IN: RcvRefRateHistoryDate + PayRefRateHistoryDate
	double* RefRateHistory,			// IN: RcvRefRateHistory + PayRefRateHistory
	long TextFlag,					// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	long GreekFlag,					// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
	char *szFileName,				// IN:  text logging file name
	char *szModuleName				// IN:  module name
)
{
	long i;
	long Sum_NCurve = 0;
	for(i=0;i<NCurveIndex;i++) Sum_NCurve += NCurve[i];

	LoggingData(szModuleName, szFileName, "PriceDate", PriceDate);
	LoggingData(szModuleName, szFileName, "NCurveIndex", NCurveIndex);
	LoggingDataArray(szModuleName, szFileName, "CurveTermInfo", Sum_NCurve, CurveTermInfo);
	LoggingDataArray(szModuleName, szFileName, "CurveRateInfo", Sum_NCurve, CurveRateInfo);
	LoggingDataArray(szModuleName, szFileName, "NCurve", NCurveIndex, NCurve);
	LoggingDataArray(szModuleName, szFileName, "CrvDayCntType", NCurveIndex, CrvDayCntType);
	LoggingData(szModuleName, szFileName, "NCrcyIndex", NCrcyIndex);
	LoggingDataArray(szModuleName, szFileName, "FXRateInfo", NCrcyIndex, FXRateInfo);
	LoggingDataArray(szModuleName, szFileName, "Leg_CrvIndex", 4, Leg_CrvIndex);
	LoggingDataArray(szModuleName, szFileName, "Leg_CrcyIndex", 3, Leg_CrcyIndex);
	LoggingDataArray(szModuleName, szFileName, "Leg_RefRatePeriod", 2, Leg_RefRatePeriod);
	LoggingDataArray(szModuleName, szFileName, "Leg_SwapRateFixedPeriod", 2, Leg_SwapRateFixedPeriod);
	LoggingDataArray(szModuleName, szFileName, "Leg_SwapRateFixedNumCpn", 2, Leg_SwapRateFixedNumCpn);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnPeriodType", 2, Leg_CpnPeriodType);
	LoggingDataArray(szModuleName, szFileName, "Leg_PaiedTime", 2, Leg_PaiedTime);
	LoggingDataArray(szModuleName, szFileName, "Leg_InArrearFlag", 2, Leg_InArrearFlag);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnDayCntType", 2, Leg_CpnDayCntType);
	LoggingDataArray(szModuleName, szFileName, "Leg_AdjustFlag", 4, Leg_AdjustFlag);
	LoggingDataArray(szModuleName, szFileName, "Leg_NCapVol", 2, Leg_NCapVol);
	LoggingDataArray(szModuleName, szFileName, "Leg_CapVolTerm", Leg_NCapVol[0]+Leg_NCapVol[1], Leg_CapVolTerm);
	LoggingDataArray(szModuleName, szFileName, "Leg_CapVol", Leg_NCapVol[0]+Leg_NCapVol[1], Leg_CapVol);
	LoggingDataArray(szModuleName, szFileName, "Leg_TimingCorr", 2, Leg_TimingCorr);
	LoggingDataArray(szModuleName, szFileName, "Leg_NSwaptionVolSwapMat", 2, Leg_NSwaptionVolSwapMat);
	LoggingDataArray(szModuleName, szFileName, "Leg_NSwaptionVolOptMat", 2, Leg_NSwaptionVolOptMat);
	LoggingDataArray(szModuleName, szFileName, "Leg_SwaptionVolSwapMat", Leg_NSwaptionVolSwapMat[0]+Leg_NSwaptionVolSwapMat[1], Leg_SwaptionVolSwapMat);
	LoggingDataArray(szModuleName, szFileName, "Leg_SwaptionVolOptMat", Leg_NSwaptionVolOptMat[0]+Leg_NSwaptionVolOptMat[1], Leg_SwaptionVolOptMat);
	LoggingDataArray(szModuleName, szFileName, "Leg_SwaptionVol", Leg_NSwaptionVolSwapMat[0]*Leg_NSwaptionVolOptMat[0] + Leg_NSwaptionVolSwapMat[1]*Leg_NSwaptionVolOptMat[1], Leg_SwaptionVol);
	LoggingDataArray(szModuleName, szFileName, "Leg_NPrinCashFlow", 2, Leg_NPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Leg_PrinCashFlow", Leg_NPrinCashFlow[0]+Leg_NPrinCashFlow[1], Leg_PrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Leg_PrinSettleDate", Leg_NPrinCashFlow[0]+Leg_NPrinCashFlow[1], Leg_PrinSettleDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_PrinDiscFactor", Leg_NPrinCashFlow[0]+Leg_NPrinCashFlow[1], Leg_PrinDiscFactor);
	LoggingDataArray(szModuleName, szFileName, "Leg_NCpnCashFlow", 2, Leg_NCpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Leg_ResetFixDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_ResetFixDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_DesignateResetFlag", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_DesignateResetFlag);
	LoggingDataArray(szModuleName, szFileName, "Leg_ForwardStartDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_ForwardStartDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_ForwardEndDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_ForwardEndDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_NFixDates", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_NFixDates);
	LoggingDataArray(szModuleName, szFileName, "Leg_NFixedDates", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_NFixedDates);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnFromDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnFromDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnToDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnToDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnSettleDate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnSettleDate);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnNA", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnNA);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnSlope", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnSlope);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnSpread", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnSpread);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnRefRate", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnRefRate);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnCashFlow", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Leg_CpnDiscFactor", Leg_NCpnCashFlow[0]+Leg_NCpnCashFlow[1], Leg_CpnDiscFactor);
	LoggingDataArray(szModuleName, szFileName, "SOFRFlags", 4, SOFRFlags);
	LoggingDataArray(szModuleName, szFileName, "SOFRConv", 8, SOFRConv);
	LoggingDataArray(szModuleName, szFileName, "HolidayCount", 2, HolidayCount);
	LoggingDataArray(szModuleName, szFileName, "Holiday", HolidayCount[0] + HolidayCount[1], Holiday);
	LoggingDataArray(szModuleName, szFileName, "RefRateHistoryCount", 2, RefRateHistoryCount);
	LoggingDataArray(szModuleName, szFileName, "RefRateHistoryDate", RefRateHistoryCount[0] + RefRateHistoryCount[1], RefRateHistoryDate);
	LoggingDataArray(szModuleName, szFileName, "RefRateHistory", RefRateHistoryCount[0] + RefRateHistoryCount[1], RefRateHistory);
	LoggingData(szModuleName, szFileName, "TextFlag", TextFlag);
	LoggingData(szModuleName, szFileName, "GreekFlag", GreekFlag);
}

long Exception_IRSwap(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	long NCurveIndex,				// IN:  �Է� Curve ����
	long *NCurve,					// IN:  Curve �� (0, 1, 2, 3)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,			// IN:  Curve ����
	double *CurveRateInfo,			// IN:  Curve Rate ( 0.01(1%)������ �Է�) 
	long *CrvDayCntType,			// IN:  Curve Day Count Type  ( ũ�� : NCurveIndex )
	long NCrcyIndex,				// IN:  �Է� ��ȭ ����
	double *FXRateInfo,				// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,				// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,			// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )
	double *Leg_RefRatePeriod,		// IN:  Leg �� Ref Rate �����ֱ�(��) ( [0] : Rcv Ref Rate �����ֱ�, [1] : Pay Ref Rate �����ֱ� )
	double *Leg_SwapRateFixedPeriod,// IN:  Leg �� Swap Rate Fixed Leg �����ֱ�(��) ( [0] : Rcv Ref Curve �����ֱ�, [1] : Pay Ref Curve �����ֱ� )
	long *Leg_SwapRateFixedNumCpn,	// IN:  Leg �� Swap Rate Fixed Leg ����Ƚ��  ( [0] : Rcv Ref Curve ���� ���� Ƚ��, [1] : Pay Ref Curve ���� ���� Ƚ�� )
	long *Leg_CpnPeriodType,		// IN:  ����/���� ���� ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case ) ( [0] : Rcv ����/��������, [1] : Pay ����/���� ���� )
	long *Leg_PaiedTime,			// IN:  Leg �� ��/���� ���� ( 1 : ����, 2 : ����, 3 : ��/���� ȥ��)
	long *Leg_InArrearFlag,			// IN:  Leg �� In Arrear ���� ( 0 : In Advanced, 1 : In Arrear , 2 : In Advanced/In Arrear ȥ��)
	long *Leg_CpnDayCntType,		// IN:  Leg �� ���� Day Count Convention ( ũ�� : 2 )
	long *Leg_AdjustFlag,			// IN:  Leg �� Adjustment ���� ( [0] : Rcv Convexity Adjust, [1] : Rcv Timing Adjust, [2] : Pay Convexity Adjust, [3] : Pay Timing Adjust )
	long *Leg_NCapVol,				// IN:  Leg �� Cap Vol ��
	double *Leg_CapVolTerm,			// IN:  Ref Curve Rate Cap Vol Term (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	double *Leg_CapVol,				// IN:  Ref Curve Rate Cap Vol (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	double *Leg_TimingCorr,			// IN:  Timing Adjustment Corr ( [0] : Rcv Forward Corr, [1] : Pay Forward Corr )
	long *Leg_NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv)
	long *Leg_NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv )
	double *Leg_SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	double *Leg_SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *Leg_SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long *Leg_NPrinCashFlow,		// IN:  Leg�� ������� ( [0] : Rcv ������� ���� ��, [1] : Pay ������� ���� �� )
	double *Leg_PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾� ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD) ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	double *Leg_PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ���� ( [0] : Rcv Coupon �����帧 ����, [1] : Pay Coupon �����帧 ���� )
	long *Leg_ResetFixDate,			// IN:  ������ (YYYYMMDD)  ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ���, 2 : ������, ������+RefRate Period���� ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnFromDate,			// IN:  ����� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnToDate,			// IN:  �⸻�� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnSettleDate,		// IN:  ������ (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnNA,				// IN:  Coupon ���ؿ��� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSlope,			// IN:  Coupon �����ݸ� ���� ���� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSpread,			// IN:  Coupon �����ݸ� ������ ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnRefRate,			// IN/OUT:  Ȯ���ݸ� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnCashFlow,		// IN/OUT:  �������� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnDiscFactor,		// OUT: Discount Factor ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long* SOFRFlags,				// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag
	long* SOFRConv,					// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,				// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����	
	long* Holiday,					// IN: Holiday Rcv,Pay
	long* RefRateHistoryCount,		// IN: [0]RcvRefRateHistoryCount, [1]PayRefRateHistoryCount
	long* RefRateHistoryDate,		// IN: RcvRefRateHistoryDate + PayRefRateHistoryDate
	double* RefRateHistory,			// IN: RcvRefRateHistory + PayRefRateHistory
	long TextFlag,					// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	long GreekFlag					// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
)
{
	long i, j;
	long Sum_Term;
	long SOFRUseFlag = SOFRFlags[0];
	long LockOutRef = SOFRConv[0];
	long LookBackRef = SOFRConv[1];
	long ObservShiftRef = SOFRConv[2];
	long HolidayFlagRef = SOFRConv[3];

	if (SOFRFlags[0] < 0 || SOFRFlags[0] > 3) return SOFRUSEERROR;
	if (SOFRFlags[1] < 0 || SOFRFlags[1] > 1) return SOFRLOGGINGERROR; 
	if (SOFRFlags[2] < 0 || SOFRFlags[2] > 1) return SOFRLOGGINGERROR;
	if (SOFRFlags[3] < 0 || SOFRFlags[3] > 1) return SOFRINTERPOLERROR;

	if (SOFRFlags[0] == 1 || SOFRFlags[0] == 2)
	{
		if (SOFRConv[0] < 0 || SOFRConv[0] > 40 || SOFRConv[4] < 0 || SOFRConv[4] > 40) return LOCKOUTERROR; 
		if (SOFRConv[1] < 0 || SOFRConv[1] > 40 || SOFRConv[5] < 0 || SOFRConv[5] > 40) return LOOKBACKERROR;
		if (SOFRConv[2] < 0 || SOFRConv[2] > 1 || SOFRConv[6] < 0 || SOFRConv[6] > 1) return OBSERVSHIFTERROR;
		if (SOFRConv[3] < 0 || SOFRConv[3] > 3 || SOFRConv[7] < 0 || SOFRConv[7] > 3) return HOLICALCFLAGERROR;

		for (i = 1 ; i < HolidayCount[0]; i++)
		{
			if (Holiday[i] < 0) return HOLIDAY_ERROR;
			if (Holiday[i] < Holiday[i-1]) return HOLIDAY_SORTINGERROR;
		}
		for (i = HolidayCount[0]+1; i < HolidayCount[0] + HolidayCount[1]; i++)
		{
			if (Holiday[i] < 0) return HOLIDAY_ERROR;
			if (Holiday[i] < Holiday[i-1]) return HOLIDAY_SORTINGERROR;
		}

		for (i = 1 ; i < RefRateHistoryCount[0]; i++)
		{
			if (RefRateHistoryDate[i] < 0 ) return HISTORY_DATE_ERROR;
			if (RefRateHistoryDate[i] < RefRateHistoryDate[i-1]) return HISTORY_SORTING_ERROR;
		}

		for (i = RefRateHistoryCount[0] + 1; i < RefRateHistoryCount[0] + RefRateHistoryCount[1]; i++)
		{
			if (RefRateHistoryDate[i] < 0 ) return HISTORY_DATE_ERROR;
			if (RefRateHistoryDate[i] < RefRateHistoryDate[i-1]) return HISTORY_SORTING_ERROR;
		}

	}
	// Price Date ����
	if(PriceDate<19000101 || PriceDate>99991231) return PRICE_DATE_ERROR;

	// �Է� Curve ���� ����
	if(NCurveIndex<1) return NUM_CURVE_INDEX_ERROR;

	Sum_Term = 0;
	for(i=0;i<NCurveIndex;i++)
	{
		// �Է� Curve Term ���� ����
		if(NCurve[i]<1) return NUM_CURVE_ERROR;

		// �Է� Curve Term, Rate ����
		if(CurveTermInfo[Sum_Term]<0) return CURVE_TERM_ERROR;
		if(CurveRateInfo[Sum_Term]<-1 || CurveRateInfo[Sum_Term]>1) return CURVE_RATE_ERROR;
		for(j=1;j<NCurve[i];j++)
		{
			if(CurveTermInfo[Sum_Term+j]<0) return CURVE_TERM_ERROR;
			if(CurveTermInfo[Sum_Term+j]<=CurveTermInfo[Sum_Term+j-1]) return CURVE_TERM_ERROR;
			if(CurveRateInfo[Sum_Term+j]<-1 || CurveRateInfo[Sum_Term+j]>1) return CURVE_RATE_ERROR;
		}
	
		if(CrvDayCntType[i]<1 || CrvDayCntType[i]>12) return CURVE_DAYCOUNT_TYPE_ERROR;

		Sum_Term += NCurve[i];		
	}

	// �Է� ȯ�� ���� ����
	if(NCrcyIndex<1) return NUM_CRCY_ERROR;
	
	for(i=0;i<NCrcyIndex;i++)
	{
		// ȯ�� ����
		if(FXRateInfo[i]<=0) return CRCY_RATE_ERROR;
	}

	// Leg�� Curve Index ����
	if(Leg_CrvIndex[0]<0 || Leg_CrvIndex[0]>=NCurveIndex) return RCV_DISCOUNT_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[1]<0 || Leg_CrvIndex[1]>=NCurveIndex) return RCV_REF_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[2]<0 || Leg_CrvIndex[2]>=NCurveIndex) return PAY_DISCOUNT_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[3]<0 || Leg_CrvIndex[3]>=NCurveIndex) return PAY_REF_CURVE_INDEX_ERROR;

	// Leg�� Crcy Index ����
	if(Leg_CrcyIndex[0]<0 || Leg_CrcyIndex[0]>=NCrcyIndex) return RCV_CRCY_ERROR;
	if(Leg_CrcyIndex[1]<0 || Leg_CrcyIndex[1]>=NCrcyIndex) return PAY_CRCY_ERROR;
	if(Leg_CrcyIndex[2]<0 || Leg_CrcyIndex[2]>=NCrcyIndex) return PRICE_CRCY_ERROR;


	// Rcv Rate ���� ����üũ
	if(Leg_CpnPeriodType[0] != 1) // ���� ����Ҷ��� üũ
	{
		// Rcv Ref Rate �����ֱ� ���� ����
		if(Leg_RefRatePeriod[0]<=0 || Leg_RefRatePeriod[0]>999) return RCV_LEG_REF_CURVE_PERIOD_ERROR;

		// Swap Rate �����ݸ� �����ֱ� ����
		if(Leg_SwapRateFixedPeriod[0]<=0 || Leg_SwapRateFixedPeriod[0]>999) return RCV_LEG_SWAP_RATE_FIXED_PERIOD_ERROR;
		
		// Swap Rate �����ݸ� ���� Ƚ�� ����
		if(Leg_SwapRateFixedNumCpn[0]<1 || Leg_SwapRateFixedNumCpn[0]>9999) return RCV_LEG_SWAP_RATE_FIXED_NUM_COUPON_ERROR;
	}

	// Pay Rate ���� ����üũ 
	if(Leg_CpnPeriodType[1] != 1) // ���� ����Ҷ��� üũ
	{
		// Rcv Ref Rate �����ֱ� ���� ����
		if(Leg_RefRatePeriod[1]<=0 || Leg_RefRatePeriod[1]>999) return PAY_LEG_REF_CURVE_PERIOD_ERROR;
		
		// Swap Rate �����ݸ� �����ֱ� ����
		if(Leg_SwapRateFixedPeriod[1]<=0 || Leg_SwapRateFixedPeriod[1]>999) return PAY_LEG_SWAP_RATE_FIXED_PERIOD_ERROR;

		// Swap Rate �����ݸ� ���� Ƚ�� ����
		if(Leg_SwapRateFixedNumCpn[1]<1 || Leg_SwapRateFixedNumCpn[1]>9999) return PAY_LEG_SWAP_RATE_FIXED_NUM_COUPON_ERROR;
	}

	// ����/�������� ����
	if(Leg_CpnPeriodType[0]!=1 && Leg_CpnPeriodType[0]!= 2 && Leg_CpnPeriodType[0]!= 3) return RCV_LEG_COUPON_PERIOD_TYPE_ERROR;
	if(Leg_CpnPeriodType[1]!=1 && Leg_CpnPeriodType[1]!= 2 && Leg_CpnPeriodType[1]!= 3) return PAY_LEG_COUPON_PERIOD_TYPE_ERROR;
	
	// Coupon ��/���� Flag ����
	if(Leg_PaiedTime[0]!=1 && Leg_PaiedTime[0]!=2 && Leg_PaiedTime[0]!=3) return RCV_LEG_COUPON_PAIED_TIME_ERROR;
	if(Leg_PaiedTime[1]!=1 && Leg_PaiedTime[1]!=2 && Leg_PaiedTime[1]!=3) return PAY_LEG_COUPON_PAIED_TIME_ERROR;

	// In Arrear Flag ����
	if(Leg_InArrearFlag[0]!=0 && Leg_InArrearFlag[0]!=1 && Leg_InArrearFlag[0]!=2) return RCV_LEG_IN_ARREAR_FLAG_ERROR;
	if(Leg_InArrearFlag[1]!=0 && Leg_InArrearFlag[1]!=1 && Leg_InArrearFlag[1]!=2) return PAY_LEG_IN_ARREAR_FLAG_ERROR;

	// Coupon Day Count Type ����
	if(Leg_CpnDayCntType[0]<1 || Leg_CpnDayCntType[0]>12) return RCV_LEG_COUPON_DAYCOUNT_TYPE_ERROR;
	if(Leg_CpnDayCntType[1]<1 || Leg_CpnDayCntType[1]>12) return PAY_LEG_COUPON_DAYCOUNT_TYPE_ERROR;


	// Rcv Convexity Adjust Flag ����
	if(Leg_AdjustFlag[0]!=0 && Leg_AdjustFlag[0]!=1 && Leg_AdjustFlag[0] !=2 && SOFRFlags[0] == 0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;

	// Rcv Timing Adjust Flag ����
	if(Leg_AdjustFlag[1]!=0 && Leg_AdjustFlag[1]!=1 && Leg_AdjustFlag[1] != 2 && SOFRFlags[0] == 0) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;

	// Adjust ��� ���������� üũ���� �ʾ��� ��쿡 ���� üũ
	if(Leg_CpnPeriodType[0]!=1) // �����϶��� üũ
	{
		if(Leg_SwapRateFixedNumCpn[0] == 1)
		{
			if( (Leg_PaiedTime[0]==1 && Leg_InArrearFlag[0]==0) || (Leg_PaiedTime[0]==2 && Leg_InArrearFlag[0]==1) )
			{
				if(Leg_AdjustFlag[0]==0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;
			}
		}
		else
		{
			if(Leg_AdjustFlag[0]==0 && SOFRUseFlag == 0 ) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR; // Swap�ݸ��ӿ��� Convexity������ ���� �ʴ°�� ����
		}

		if(Leg_SwapRateFixedNumCpn[0] != 1 && Leg_InArrearFlag[0]==0 && Leg_PaiedTime[0]==2 && Leg_AdjustFlag[1]==0 && SOFRUseFlag == 0) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;
	}

	// Pay Convexity Adjust Flag ����
	if(Leg_AdjustFlag[2]!=0 && Leg_AdjustFlag[2]!=1 && Leg_AdjustFlag[2] !=2 && SOFRFlags[0] == 0) return PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR;

	// Pay Timing Adjust Flag ����
	if(Leg_AdjustFlag[3]!=0 && Leg_AdjustFlag[3]!=1 && Leg_AdjustFlag[3] != 2 && SOFRFlags[0] == 0) return PAY_LEG_TIMING_ADJUST_FLAG_ERROR;

	// Adjust ��� ���������� üũ���� �ʾ��� ��쿡 ���� üũ
	if(Leg_CpnPeriodType[1]!=1) // �����϶��� üũ
	{
		if(Leg_SwapRateFixedNumCpn[1] == 1)
		{
			if( (Leg_PaiedTime[1]==1 && Leg_InArrearFlag[1]==0) || (Leg_PaiedTime[1]==2 && Leg_InArrearFlag[1]==1) )
			{
				if(Leg_AdjustFlag[2]==0 && SOFRFlags[0] == 0) return PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR;
			}
		}
		else
		{
			if(Leg_AdjustFlag[2]==0 && SOFRFlags[0] == 0) return PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR; // Swap�ݸ��ӿ��� Convexity������ ���� �ʴ°�� ����
		}

		if(Leg_SwapRateFixedNumCpn[1] != 1 && Leg_InArrearFlag[1]==0 && Leg_PaiedTime[1]==2 && Leg_AdjustFlag[3]==0 ) return PAY_LEG_TIMING_ADJUST_FLAG_ERROR;

	}

	// Rcv Leg 
	if(Leg_NCapVol[0]<0) return RCV_LEG_CAP_COUNT_ERROR;
	if(Leg_NSwaptionVolSwapMat[0]<0) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
	if(Leg_NSwaptionVolOptMat[0]<0) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
	if(Leg_CpnPeriodType[0]!=1) // �����϶��� üũ
	{
		// Cap �������� �ʿ��� ��� ����üũ
		if( (Leg_SwapRateFixedNumCpn[0]==1 && (Leg_AdjustFlag[0] == 1 || Leg_AdjustFlag[1]==1) ) || ( Leg_SwapRateFixedNumCpn[0] != 1 && Leg_AdjustFlag[1]==1) )
		{
			// Cap Vol ���� ����
			if(Leg_NCapVol[0]<1) return RCV_LEG_CAP_COUNT_ERROR;

			for(i=0;i<Leg_NCapVol[0];i++)
			{
				// Cap ������ �Ⱓ���� ����
				if(Leg_CapVolTerm[i] < 0) return RCV_LEG_CAP_MAT_ERROR;
				if(i!=0)
				{
					if(Leg_CapVolTerm[i]<=Leg_CapVolTerm[i-1]) return RCV_LEG_CAP_MAT_ERROR;
				}

				// Cap ������ ����
				if(Leg_CapVol[i]<0.0 || Leg_CapVol[i]>10.0) return RCV_LEG_CAP_VOL_ERROR;
			}
		}

		// Swaption �������� �ʿ��Ѱ�� ����üũ
		if( Leg_SwapRateFixedNumCpn[0] != 1 && ( Leg_AdjustFlag[0]==1 || Leg_AdjustFlag[1]==1) )
		{
			// Swaption Vol ���� ���� 
			if(Leg_NSwaptionVolSwapMat[0]<1) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
			if(Leg_NSwaptionVolOptMat[0]<1) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;

			// Timing Adjust �� ����ϴ� Correlation ����
			if(Leg_TimingCorr[0]<-1 || Leg_TimingCorr[0]>1) return RCV_LEG_TIMING_CORRELATION_ERROR;

			// Swaption Vol�� Swap���⿡��
			for(i=0;i<Leg_NSwaptionVolSwapMat[0];i++)
			{
				if(Leg_SwaptionVolSwapMat[i]<0) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(Leg_SwaptionVolSwapMat[i-1]>=Leg_SwaptionVolSwapMat[i]) return RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
				}
			}

			// Swaption Vol�� Option ���� ����
			for(i=0;i<Leg_NSwaptionVolOptMat[0];i++)
			{
				if(Leg_SwaptionVolOptMat[i]<0) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(Leg_SwaptionVolOptMat[i-1]>=Leg_SwaptionVolOptMat[i]) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
				}
			}

			// Swaption Vol ����
			for(i=0;i<Leg_NSwaptionVolSwapMat[0]*Leg_NSwaptionVolOptMat[0];i++)
			{
				if(Leg_SwaptionVol[i]<=0 || Leg_SwaptionVol[i]>10.0) return RCV_LEG_SWAPTION_VOL_ERROR;
			}
		}
	}

	// Pay Leg
	if(Leg_NCapVol[1]<0) return PAY_LEG_CAP_COUNT_ERROR;
	if(Leg_NSwaptionVolSwapMat[1]<0) return PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
	if(Leg_NSwaptionVolOptMat[1]<0) return PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
	if(Leg_CpnPeriodType[1]!=1) // �����϶��� üũ
	{
		// Cap �������� �ʿ��� ��� ����üũ
		if( (Leg_SwapRateFixedNumCpn[1]==1 && (Leg_AdjustFlag[2]==1 || Leg_AdjustFlag[3]==1) ) || ( Leg_SwapRateFixedNumCpn[1]!=1 && Leg_AdjustFlag[3]==1) )
		{
			// Cap Vol ���� ����
			if(Leg_NCapVol[1]<1) return PAY_LEG_CAP_COUNT_ERROR;

			for(i=0;i<Leg_NCapVol[1];i++)
			{
				// Cap ������ �Ⱓ���� ����
				if(Leg_CapVolTerm[Leg_NCapVol[0]+i] < 0) return PAY_LEG_CAP_MAT_ERROR;
				if(i!=0)
				{
					if(Leg_CapVolTerm[Leg_NCapVol[0]+i]<=Leg_CapVolTerm[Leg_NCapVol[0]+i-1]) return PAY_LEG_CAP_MAT_ERROR;
				}

				// Cap ������ ����
				if(Leg_CapVol[Leg_NCapVol[0]+i]<0.0 || Leg_CapVol[Leg_NCapVol[0]+i]>10.0) return PAY_LEG_CAP_VOL_ERROR;
			}
		}

		// Swaption �������� �ʿ��Ѱ�� ����üũ
		if( Leg_SwapRateFixedNumCpn[1] != 1 && ( Leg_AdjustFlag[2]==1 || Leg_AdjustFlag[3]==1) )
		{
			// Swaption Vol ���� ���� 
			if(Leg_NSwaptionVolSwapMat[1]<1) return PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
			if(Leg_NSwaptionVolOptMat[1]<1) return PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;

			// Timing Adjust �� ����ϴ� Correlation ����
			if(Leg_TimingCorr[1]<-1 || Leg_TimingCorr[1]>1) return PAY_LEG_TIMING_CORRELATION_ERROR;

			// Swaption Vol�� Swap���⿡��
			for(i=0;i<Leg_NSwaptionVolSwapMat[1];i++)
			{
				if(Leg_SwaptionVolSwapMat[Leg_NSwaptionVolSwapMat[0]+i]<0) return PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(	Leg_SwaptionVolSwapMat[Leg_NSwaptionVolSwapMat[0]+i-1]
						>=Leg_SwaptionVolSwapMat[Leg_NSwaptionVolSwapMat[0]+i] )
					{
						return PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR;
					}
				}
			}

			// Swaption Vol�� Option ���� ����
			for(i=0;i<Leg_NSwaptionVolOptMat[1];i++)
			{
				if(Leg_SwaptionVolOptMat[Leg_NSwaptionVolOptMat[0]+i]<0) return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
				if(i!=0)
				{
					if(	Leg_SwaptionVolOptMat[Leg_NSwaptionVolOptMat[0]+i-1]
						>=Leg_SwaptionVolOptMat[Leg_NSwaptionVolOptMat[0]+i]	)
					{
						return RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR;
					}
				}
			}

			// Swaption Vol ����
			for(i=0;i<Leg_NSwaptionVolSwapMat[1]*Leg_NSwaptionVolOptMat[1];i++)
			{
				if(	Leg_SwaptionVol[Leg_NSwaptionVolSwapMat[0]*Leg_NSwaptionVolOptMat[0]+i] <= 0
					|| Leg_SwaptionVol[Leg_NSwaptionVolSwapMat[0]*Leg_NSwaptionVolOptMat[0]+i] > 10.0)
				{
					return RCV_LEG_SWAPTION_VOL_ERROR;
				}
			}
		}
	}

	// Rcv
	if(Leg_NPrinCashFlow[0]<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR;
	for(i=0;i<Leg_NPrinCashFlow[0];i++)
	{
		// ���� ���� �ݾ� ���� // �ʱ���ݱ�ȯ(����)���
		//if(Leg_PrinCashFlow[i]<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_ERROR;

		// ���� ������ ����
		if(Leg_PrinSettleDate[i]<19000101 || Leg_PrinSettleDate[i] > 99991231) return RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_PrinSettleDate[i]<Leg_PrinSettleDate[i-1]) return RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		}

		// ���� Discount Factor �Է��ʱ�ȭ ����
		if(Leg_PrinDiscFactor[i]!=0.0) return RCV_LEG_PRINCIPAL_DISCOUNT_ERROR;
	}

	// Pay
	if(Leg_NPrinCashFlow[1]<0) return PAY_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR;
	for(i=0;i<Leg_NPrinCashFlow[1];i++)
	{
		// ���� ���� �ݾ� ���� // �ʱ���ݱ�ȯ(����)���
		//if(Leg_PrinCashFlow[Leg_NPrinCashFlow[0]+i]<0) return PAY_LEG_PRINCIPAL_CASH_FLOW_ERROR;

		// ���� ������ ����
		if(Leg_PrinSettleDate[Leg_NPrinCashFlow[0]+i]<19000101 || Leg_PrinSettleDate[Leg_NPrinCashFlow[0]+i] > 99991231) return PAY_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_PrinSettleDate[Leg_NPrinCashFlow[0]+i]<Leg_PrinSettleDate[Leg_NPrinCashFlow[0]+i-1]) return PAY_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;
		}

		// ���� Discount Factor �Է��ʱ�ȭ ����
		if(Leg_PrinDiscFactor[Leg_NPrinCashFlow[0]+i]!=0.0) return PAY_LEG_PRINCIPAL_DISCOUNT_ERROR;
	}

	// Rcv
	if(Leg_NCpnCashFlow[0]<0) return RCV_LEG_COUPON_CASH_FLOW_COUNT_ERROR;
	for(i=0;i<Leg_NCpnCashFlow[0];i++)
	{
		if(Leg_CpnPeriodType[0]!=1) // �����϶��� üũ
		{
			if (SOFRUseFlag == 0 && Leg_DesignateResetFlag[i] == 2)
			{
				// ���� Fix�� ����
				if(Leg_ResetFixDate[i]<19000101 || Leg_ResetFixDate[i]>99991231) return RCV_LEG_RESET_FIX_DATE_ERROR;
				if(i!=0 && Leg_DesignateResetFlag[i] != 2)
				{
					if(Leg_ResetFixDate[i]<Leg_ResetFixDate[i-1]) return RCV_LEG_RESET_FIX_DATE_ERROR;
					//if(Leg_ResetFixDate[i]==Leg_ResetFixDate[i-1] && Leg_DesignateResetFlag[i]==0) return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
				}

				// ������ �Է� Flag
				if(Leg_DesignateResetFlag[i] != 0 && Leg_DesignateResetFlag[i] != 1 && Leg_DesignateResetFlag[i] != 2) return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
				if(Leg_DesignateResetFlag[i] == 2)
				{
					if(Leg_InArrearFlag[0]!=2) return RCV_LEG_RESET_DESIGNATE_FLAG_ERROR;
				}

				// Forward Rate ��� ������ ����
				if(Leg_DesignateResetFlag[i]==1)
				{
					if(Leg_ForwardStartDate[i]<19000101 || Leg_ForwardStartDate[i]>99991231) return RCV_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ForwardEndDate[i]<19000101 || Leg_ForwardEndDate[i]>99991231) return RCV_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ForwardStartDate[i]>=Leg_ForwardEndDate[i]) return RCV_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ResetFixDate[i]>Leg_ForwardStartDate[i]) return RCV_LEG_FORWARD_START_DATE_ERROR;
				}

				// Average Reset Fix �ϼ� ����
				if(Leg_NFixDates[i]<1) return RCV_LEG_NUM_FIXING_DATE_ERROR;

				// ������ Average Reset Fix �ϼ� ����

				if(Leg_NFixedDates[i]<0 || Leg_NFixedDates[i]>Leg_NFixDates[i]) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				if(Leg_NFixDates[i] != Leg_NFixedDates[i])
				{
					if(ActDateAdjust(Leg_ResetFixDate[i],-(Leg_NFixDates[i]-Leg_NFixedDates[i]))<PriceDate) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				}
				else
				{
					if(Leg_ResetFixDate[i]>PriceDate) return RCV_LEG_NUM_FIXED_DATE_ERROR;
				}
			}
		}

		// ����� ����
		if(Leg_CpnFromDate[i]<19000101 || Leg_CpnFromDate[i]>99991231) return RCV_LEG_COUPON_FORM_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_CpnFromDate[i]<=Leg_CpnFromDate[i-1]) return RCV_LEG_COUPON_FORM_DATE_ERROR;
		}

		// �⸻�� ����
		if(Leg_CpnToDate[i]<19000101 || Leg_CpnToDate[i]>99991231) return RCV_LEG_COUPON_TO_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_CpnToDate[i]<=Leg_CpnToDate[i-1]) return RCV_LEG_COUPON_TO_DATE_ERROR;
		}
		if(Leg_CpnFromDate[i]>=Leg_CpnToDate[i]) return RCV_LEG_COUPON_TO_DATE_ERROR;

		if(Leg_DesignateResetFlag[i]==0 && Leg_CpnPeriodType[0]!=1) // �����϶��� üũ
		{
			if(Leg_InArrearFlag[0]==0)
			{
				if(Leg_ResetFixDate[i]>=Leg_CpnToDate[i]) return RCV_LEG_RESET_FIX_DATE_ERROR;
			}
			else if(Leg_InArrearFlag[0]==1)
			{
				if(Leg_ResetFixDate[i]<=Leg_CpnFromDate[i]) return RCV_LEG_RESET_FIX_DATE_ERROR;
			}
				
		}

		// �������ΰ� üũ�Ǿ����� ���� ��� ����
		if(Leg_SwapRateFixedNumCpn[0]==1 && Leg_CpnPeriodType[0]!=1) // �����϶��� üũ
		{
			// Curve�� �������ޱ����� ���������Ⱓ����  1.25�� �̻� �� ��� Convexity ���� ���� ����
			if(Leg_RefRatePeriod[0]/DayCountFraction(Leg_CpnFromDate[i],Leg_CpnToDate[i],CrvDayCntType[Leg_CrvIndex[1]]) > 1.25)
			{
				if(Leg_AdjustFlag[0]==0 && SOFRFlags[0] == 0) return RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR;
			}

			// ���������Ⱓ�� Curve�� �������ޱ������� 1.25�� �̻� �� ��� Timing ���� ���� ����
			if(DayCountFraction(Leg_CpnFromDate[i],Leg_CpnToDate[i],CrvDayCntType[Leg_CrvIndex[1]])/Leg_RefRatePeriod[0] > 1.25)
			{
				if(Leg_AdjustFlag[1]==0 && SOFRFlags[0] == 0) return RCV_LEG_TIMING_ADJUST_FLAG_ERROR;
			}
		}

		// ������ ����
		if(Leg_CpnSettleDate[i]<19000101 || Leg_CpnSettleDate[i]>99991231) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;

		if(i!=0 && Leg_PaiedTime[0] != 3)
		{
			if(Leg_CpnSettleDate[i]<Leg_CpnSettleDate[i-1]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		if(Leg_PaiedTime[0]==1) // ����� �⸻�Ϻ��� �տ��־�� �ϰ�,
		{
			if(Leg_CpnSettleDate[i]>=Leg_CpnToDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		else if(Leg_PaiedTime[0]==2) // ����� ����Ϻ��� �ڿ��־�� �Ѵ�.
		{
			if(Leg_CpnSettleDate[i]<=Leg_CpnFromDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		// ��� ���� ������ ������ �� �ǹ̰� ������ ������ �� ������, �����ϰԳ��� ����üũ�� �ϰ�,
		// Timing adjust�� ���� ��뿩�� ������ ���� �Է°��̴�.

		if(Leg_CpnPeriodType[0] != 1)
		{
			if(Leg_ResetFixDate[i]>Leg_CpnSettleDate[i]) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		// Coupon ���ؿ��� ����
		if(Leg_CpnNA[i]<0) return RCV_LEG_COUPON_NOTIONAL_AMOUNT_ERROR;

		// Coupon Slope ����
		if(Leg_CpnPeriodType[0] == 1)
		{
			if(Leg_CpnSlope[i] != 0) return RCV_LEG_COUPON_SLOPE_ERROR;
		}
		else if(Leg_CpnPeriodType[0] == 2)
		{
			if(Leg_CpnSlope[i] != 1) return RCV_LEG_COUPON_SLOPE_ERROR;
		}

		// Coupon Spread ����
		if(Leg_CpnSpread[i]<-1 || Leg_CpnSpread[i]>1) return RCV_LEG_COUPON_SPREAD_ERROR;

		if(Leg_CpnPeriodType[0] != 1)
		{
			// Ȯ���ݸ� ����
			if(Leg_CpnRefRate[i]<-1 || Leg_CpnRefRate[i]>1) return RCV_LEG_COUPON_COUPON_RATE_ERROR;
			//if( (Leg_ResetFixDate[i]<=PriceDate && PriceDate<Leg_CpnSettleDate[i]) && Leg_CpnRefRate[i]==0) return RCV_LEG_COUPON_COUPON_RATE_ERROR; // ���� Fix���� ���������� Ȯ���ݸ��� �Էµ��� �ʾҴٸ� ����
		}

		// �������� ����
		//if(Leg_CpnCashFlow[i]<0) return RCV_LEG_COUPON_CASH_FLOW_ERROR;

		// Discount Factor �ʱ�ȭ ����
		if(Leg_CpnDiscFactor[i] != 0.0) return RCV_LEG_COUPON_DISCOUNT_FACTOR_ERROR;
	}


	// Pay
	if(Leg_NCpnCashFlow[1]<0) return PAY_LEG_COUPON_CASH_FLOW_COUNT_ERROR;
	for(i=0;i<Leg_NCpnCashFlow[1];i++)
	{
		if(Leg_CpnPeriodType[1]!=1) // �����϶��� üũ
		{
			if (SOFRUseFlag == 0 && Leg_DesignateResetFlag[i] == 2)
			{
				// ���� Fix�� ����
				if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_RESET_FIX_DATE_ERROR;
				if(i!=0 && Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] != 2)
				{
					if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i] < Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i-1]) return PAY_LEG_RESET_FIX_DATE_ERROR;
					//if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i] == Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i-1] && Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] == 0) return PAY_LEG_RESET_DESIGNATE_FLAG_ERROR;
				}

				// ������ �Է� Flag
				if(Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] != 0 && Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] != 1 && Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] != 2) return PAY_LEG_RESET_DESIGNATE_FLAG_ERROR;
				if(Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i] == 2)
				{
					if(Leg_InArrearFlag[1] != 2) return PAY_LEG_RESET_DESIGNATE_FLAG_ERROR;
				}

				// Forward Rate ��� ������ ����
				if(Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i]==1)
				{
					if(Leg_ForwardStartDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_ForwardStartDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ForwardEndDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_ForwardEndDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ForwardStartDate[Leg_NCpnCashFlow[0]+i]>=Leg_ForwardEndDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_FORWARD_START_DATE_ERROR;
					if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]>Leg_ForwardStartDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_FORWARD_START_DATE_ERROR;
				}

				// Average Reset Fix �ϼ� ����
				if(Leg_NFixDates[Leg_NCpnCashFlow[0]+i]<1) return PAY_LEG_NUM_FIXING_DATE_ERROR;


				// ������ Average Reset Fix �ϼ� ����
				if(Leg_NFixedDates[Leg_NCpnCashFlow[0]+i]<0 || Leg_NFixedDates[Leg_NCpnCashFlow[0]+i]>Leg_NFixDates[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_NUM_FIXED_DATE_ERROR;
				if(Leg_NFixDates[Leg_NCpnCashFlow[0]+i] != Leg_NFixedDates[Leg_NCpnCashFlow[0]+i])
				{
					if(ActDateAdjust(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i],-(Leg_NFixDates[Leg_NCpnCashFlow[0]+i]-Leg_NFixedDates[Leg_NCpnCashFlow[0]+i]))<PriceDate) return PAY_LEG_NUM_FIXED_DATE_ERROR;
				}
				else
				{
					if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]>PriceDate) return PAY_LEG_NUM_FIXED_DATE_ERROR;
				}
			}
		}

		// ����� ����
		if(Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_COUPON_FORM_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i] <= Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i-1]) return PAY_LEG_COUPON_FORM_DATE_ERROR;
		}

		// �⸻�� ����
		if(Leg_CpnToDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_CpnToDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_COUPON_TO_DATE_ERROR;
		if(i!=0)
		{
			if(Leg_CpnToDate[Leg_NCpnCashFlow[0]+i] <= Leg_CpnToDate[Leg_NCpnCashFlow[0]+i-1]) return PAY_LEG_COUPON_TO_DATE_ERROR;
		}

		if(Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i]>=Leg_CpnToDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_COUPON_TO_DATE_ERROR;

		if(Leg_DesignateResetFlag[Leg_NCpnCashFlow[0]+i]==0 && Leg_CpnPeriodType[1]!=1) // �����϶��� üũ
		{
			if(Leg_InArrearFlag[1]==0)
			{
				if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]>=Leg_CpnToDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_RESET_FIX_DATE_ERROR;
			}
			else if(Leg_InArrearFlag[1]==1)
			{
				if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]<=Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_RESET_FIX_DATE_ERROR;
			}
				
		}

		// �������ΰ� üũ�Ǿ����� ���� ��� ����
		if(Leg_SwapRateFixedNumCpn[1]==1 && Leg_CpnPeriodType[1]!=1) // �����϶��� üũ
		{
			// Curve�� �������ޱ����� ���������Ⱓ����  1.25�� �̻� �� ��� Convexity ���� ���� ����
			if(Leg_RefRatePeriod[1]/DayCountFraction(Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i],Leg_CpnToDate[Leg_NCpnCashFlow[0]+i],CrvDayCntType[Leg_CrvIndex[3]]) > 1.25)
			{
				if(Leg_AdjustFlag[2]==0 && SOFRFlags[0] == 0) return PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR;
			}

			// ���������Ⱓ�� Curve�� �������ޱ������� 1.25�� �̻� �� ��� Timing ���� ���� ����
			if(DayCountFraction(Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i],Leg_CpnToDate[Leg_NCpnCashFlow[0]+i],CrvDayCntType[Leg_CrvIndex[3]])/Leg_RefRatePeriod[1] > 1.25)
			{
				if(Leg_AdjustFlag[3]==0 && SOFRFlags[0] == 0) return PAY_LEG_TIMING_ADJUST_FLAG_ERROR;
			}
		}

		// ������ ����
		if(Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]<19000101 || Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]>99991231) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;

		if(i!=0 && Leg_PaiedTime[1] != 3)
		{
			if(Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i] < Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i-1]) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		if(Leg_PaiedTime[1]==1) // ����� �⸻�Ϻ��� �տ��־�� �ϰ�,
		{
			if(Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]>=Leg_CpnToDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		else if(Leg_PaiedTime[1]==2) // ����� ����Ϻ��� �ڿ��־�� �Ѵ�.
		{
			if(Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]<=Leg_CpnFromDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}
		// ��� ���� ������ ������ �� �ǹ̰� ������ ������ �� ������, �����ϰԳ��� ����üũ�� �ϰ�,
		// Timing adjust�� ���� ��뿩�� ������ ���� �Է°��̴�.

		if(Leg_CpnPeriodType[1] != 1)
		{
			if(Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]>Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;
		}

		// Coupon ���ؿ��� ����
		if(Leg_CpnNA[Leg_NCpnCashFlow[0]+i]<0) return PAY_LEG_COUPON_NOTIONAL_AMOUNT_ERROR;

		// Coupon Slope ����
		if(Leg_CpnPeriodType[1] == 1)
		{
			if(Leg_CpnSlope[Leg_NCpnCashFlow[0]+i] != 0) return PAY_LEG_COUPON_SLOPE_ERROR;
		}
		else if(Leg_CpnPeriodType[1] == 2)
		{
			if(Leg_CpnSlope[Leg_NCpnCashFlow[0]+i] != 1) return PAY_LEG_COUPON_SLOPE_ERROR;
		}

		// Coupon Spread ����
		if(Leg_CpnSpread[Leg_NCpnCashFlow[0]+i]<-1 || Leg_CpnSpread[Leg_NCpnCashFlow[0]+i]>1) return PAY_LEG_COUPON_SPREAD_ERROR;

		if(Leg_CpnPeriodType[1] != 1)
		{
			// Ȯ���ݸ� ����
			if(Leg_CpnRefRate[Leg_NCpnCashFlow[0]+i]<-1 || Leg_CpnRefRate[Leg_NCpnCashFlow[0]+i]>1) return PAY_LEG_COUPON_COUPON_RATE_ERROR;
			//if( (Leg_ResetFixDate[Leg_NCpnCashFlow[0]+i]<=PriceDate && PriceDate<Leg_CpnSettleDate[Leg_NCpnCashFlow[0]+i]) && Leg_CpnRefRate[Leg_NCpnCashFlow[0]+i]==0) return PAY_LEG_COUPON_COUPON_RATE_ERROR; // ���� Fix���� ���������� Ȯ���ݸ��� �Էµ��� �ʾҴٸ� ����
		}

		// �������� ����
		//if(Leg_CpnCashFlow[Leg_NCpnCashFlow[0]+i]<0) return PAY_LEG_COUPON_CASH_FLOW_ERROR;

		// Discount Factor �ʱ�ȭ ����
		if(Leg_CpnDiscFactor[Leg_NCpnCashFlow[0]+i] != 0.0) return PAY_LEG_COUPON_DISCOUNT_FACTOR_ERROR;
	}


	// TextDump ��¿���
	if(TextFlag != 0 && TextFlag != 1) return TEXT_FLAG_ERROR;

	// Greek ��� ���� Flag
	if(GreekFlag != 0 && GreekFlag != 1) return GREEK_FLAG_ERROR;

	return CORRECT;
}

DLLEXPORT (long) ERRORCONTENTS(
	long ErrorCode,
	char* error
	)
{
	if (ErrorCode == SOFRUSEERROR) return SaveErrorName(error, "SOFR USE FLAG ERROR");
	if (ErrorCode ==  SOFRLOGGINGERROR) return SaveErrorName(error, "SOFR LOGGING ERROR");
	if (ErrorCode ==  SOFRINTERPOLERROR) return SaveErrorName(error, "SOFR INTERPOL ERROR");
	if (ErrorCode ==  LOCKOUTERROR) return SaveErrorName(error, "LOCK OUT ERROR");
	if (ErrorCode ==  LOOKBACKERROR) return SaveErrorName(error, "LOOK BACK ERROR");
	if (ErrorCode ==  OBSERVSHIFTERROR) return SaveErrorName(error, "OBSERV SHIFT ERROR");
	if (ErrorCode ==  HOLICALCFLAGERROR) return SaveErrorName(error, "HOLI CALC FLAG ERROR");
	if (ErrorCode ==  HOLIDAY_ERROR) return SaveErrorName(error, "HOLIDAY ERROR");
	if (ErrorCode ==  HOLIDAY_SORTINGERROR) return SaveErrorName(error, "HOLIDAY SORTING ERROR");
	if (ErrorCode ==  HISTORY_DATE_ERROR) return SaveErrorName(error, "HISTORY DATE ERROR");
	if (ErrorCode ==  HISTORY_SORTING_ERROR) return SaveErrorName(error, "HISTORY SORTING ERROR");
	if (ErrorCode ==  PRICE_DATE_ERROR) return SaveErrorName(error, "PRICE DATE ERROR");
	if (ErrorCode ==  NUM_CURVE_INDEX_ERROR) return SaveErrorName(error, "NUM CURVE INDEX ERROR");
	if (ErrorCode ==  NUM_CURVE_ERROR) return SaveErrorName(error, "NUM CURVE ERROR");
	if (ErrorCode ==  CURVE_TERM_ERROR) return SaveErrorName(error, "CURVE TERM ERROR");
	if (ErrorCode ==  CURVE_RATE_ERROR) return SaveErrorName(error, "CURVE RATE ERROR");
	if (ErrorCode ==  CURVE_DAYCOUNT_TYPE_ERROR) return SaveErrorName(error, "CURVE DAYCOUNT TYPE ERROR");
	if (ErrorCode ==  NUM_CRCY_ERROR) return SaveErrorName(error, "NUM CRCY ERROR");

	if (ErrorCode ==  CRCY_RATE_ERROR) return SaveErrorName(error, "CRCY RATE ERROR");
	if (ErrorCode ==  RCV_DISCOUNT_CURVE_INDEX_ERROR) return SaveErrorName(error, "RCV DISCOUNT CURVE INDEX ERROR");
	if (ErrorCode ==  RCV_REF_CURVE_INDEX_ERROR) return SaveErrorName(error, "RCV REF CURVE INDEX ERROR");
	if (ErrorCode ==  PAY_DISCOUNT_CURVE_INDEX_ERROR) return SaveErrorName(error, "PAY DISCOUNT CURVE INDEX ERROR");
	if (ErrorCode ==  PAY_REF_CURVE_INDEX_ERROR) return SaveErrorName(error, "PAY REF CURVE INDEX_ERROR");
	if (ErrorCode ==  RCV_CRCY_ERROR) return SaveErrorName(error, "RCV CRCY ERROR");
	if (ErrorCode ==  PAY_CRCY_ERROR) return SaveErrorName(error, "PAY CRCY ERROR");
	if (ErrorCode ==  PRICE_CRCY_ERROR) return SaveErrorName(error, "PRICE CRCY ERROR");
	if (ErrorCode ==  RCV_LEG_REF_CURVE_PERIOD_ERROR) return SaveErrorName(error, "RCV LEG REF CURVE PERIOD ERROR");
	if (ErrorCode ==  RCV_LEG_SWAP_RATE_FIXED_PERIOD_ERROR) return SaveErrorName(error, "RCV LEG SWAP RATE FIXED PERIOD ERROR");
	if (ErrorCode ==  RCV_LEG_SWAP_RATE_FIXED_NUM_COUPON_ERROR) return SaveErrorName(error, "RCV LEG SWAP RATE FIXED NUM COUPON ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_PERIOD_TYPE_ERROR) return SaveErrorName(error, "RCV LEG COUPON PERIOD TYPE ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_PERIOD_TYPE_ERROR) return SaveErrorName(error, "PAY LEG COUPON PERIOD TYPE ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_PAIED_TIME_ERROR) return SaveErrorName(error, "RCV LEG COUPON PAIED TIME ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_PAIED_TIME_ERROR) return SaveErrorName(error, "PAY LEG COUPON PAIED TIME ERROR");
	if (ErrorCode ==  RCV_LEG_IN_ARREAR_FLAG_ERROR) return SaveErrorName(error, "RCV LEG IN ARREAR FLAG ERROR");
	if (ErrorCode ==  PAY_LEG_IN_ARREAR_FLAG_ERROR) return SaveErrorName(error, "PAY LEG IN ARREAR FLAG ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_DAYCOUNT_TYPE_ERROR) return SaveErrorName(error, "RCV LEG COUPON DAYCOUNT TYPE ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_DAYCOUNT_TYPE_ERROR) return SaveErrorName(error, "PAY LEG COUPON DAYCOUNT TYPE ERROR");

	if (ErrorCode ==  RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR) return SaveErrorName(error, "RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  RCV_LEG_TIMING_ADJUST_FLAG_ERROR) return SaveErrorName(error, "RCV_LEG_TIMING_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR) return SaveErrorName(error, "PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  PAY_LEG_TIMING_ADJUST_FLAG_ERROR) return SaveErrorName(error, "PAY_LEG_TIMING_ADJUST_FLAG_ERROR");

	if (ErrorCode ==  RCV_LEG_CAP_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_CAP_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_CAP_MAT_ERROR) return SaveErrorName(error, "RCV_LEG_CAP_MAT_ERROR");
	if (ErrorCode ==  RCV_LEG_CAP_VOL_ERROR) return SaveErrorName(error, "RCV_LEG_CAP_VOL_ERROR");
	if (ErrorCode ==  RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_SWAPTION_VOL_ERROR) return SaveErrorName(error, "RCV_LEG_SWAPTION_VOL_ERROR");
	if (ErrorCode ==  PAY_LEG_CAP_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_CAP_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_CAP_MAT_ERROR) return SaveErrorName(error, "PAY_LEG_CAP_MAT_ERROR");
	if (ErrorCode ==  PAY_LEG_CAP_VOL_ERROR) return SaveErrorName(error, "PAY_LEG_CAP_VOL_ERROR");
	if (ErrorCode ==  PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_SWAPTION_OPTION_MAT_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_SWAPTION_SWAP_MAT_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_SWAPTION_VOL_ERROR) return SaveErrorName(error, "PAY_LEG_SWAPTION_VOL_ERROR");

	if (ErrorCode ==  RCV_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_PRINCIPAL_DISCOUNT_ERROR) return SaveErrorName(error, "RCV_LEG_PRINCIPAL_DISCOUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR) return SaveErrorName(error, "PAY_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR");
	if (ErrorCode ==  PAY_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_PRINCIPAL_DISCOUNT_ERROR) return SaveErrorName(error, "PAY_LEG_PRINCIPAL_DISCOUNT_ERROR");

	if (ErrorCode ==  RCV_LEG_COUPON_CASH_FLOW_COUNT_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_CASH_FLOW_COUNT_ERROR");
	if (ErrorCode ==  RCV_LEG_RESET_FIX_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_RESET_FIX_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_RESET_DESIGNATE_FLAG_ERROR) return SaveErrorName(error, "RCV_LEG_RESET_DESIGNATE_FLAG_ERROR");
	if (ErrorCode ==  RCV_LEG_FORWARD_START_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_FORWARD_START_DATE_ERROR");

	if (ErrorCode ==  RCV_LEG_NUM_FIXING_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_NUM_FIXING_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_NUM_FIXED_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_NUM_FIXED_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_FORM_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_FORM_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_TO_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_TO_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_RESET_FIX_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_RESET_FIX_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR) return SaveErrorName(error, "RCV_LEG_CONVEXITY_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  RCV_LEG_TIMING_ADJUST_FLAG_ERROR) return SaveErrorName(error, "RCV_LEG_TIMING_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_SLOPE_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_SLOPE_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_SPREAD_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_SPREAD_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_COUPON_RATE_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_COUPON_RATE_ERROR");
	if (ErrorCode ==  RCV_LEG_COUPON_DISCOUNT_FACTOR_ERROR) return SaveErrorName(error, "RCV_LEG_COUPON_DISCOUNT_FACTOR_ERROR");

	if (ErrorCode ==  PAY_LEG_NUM_FIXING_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_NUM_FIXING_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_NUM_FIXED_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_NUM_FIXED_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_FORM_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_COUPON_FORM_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_TO_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_COUPON_TO_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_RESET_FIX_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_RESET_FIX_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR) return SaveErrorName(error, "PAY_LEG_CONVEXITY_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  PAY_LEG_TIMING_ADJUST_FLAG_ERROR) return SaveErrorName(error, "PAY_LEG_TIMING_ADJUST_FLAG_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR) return SaveErrorName(error, "PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_SLOPE_ERROR) return SaveErrorName(error, "PAY_LEG_COUPON_SLOPE_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_SPREAD_ERROR) return SaveErrorName(error, "PAY LEG COUPON SPREAD_ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_COUPON_RATE_ERROR) return SaveErrorName(error, "PAY LEG COUPON COUPON RATE ERROR");
	if (ErrorCode ==  PAY_LEG_COUPON_DISCOUNT_FACTOR_ERROR) return SaveErrorName(error, "PAYLEG COUPON DISCOUNT FACTOR ERROR");

	if (ErrorCode ==  TEXT_FLAG_ERROR) return SaveErrorName(error, "TEXT_FLAG_ERROR");
	if (ErrorCode ==  GREEK_FLAG_ERROR) return SaveErrorName(error, "GREEK FLAG ERROR");
	if (ErrorCode == 1) return SaveErrorName(error, "No Error");
	return SaveErrorName(error, "UNKNOWN ERROR AND NEEDED TO UPDATE ERRORCONTENTS FUNCTION");
}

DLLEXPORT (long) KISP_CalcIRSwap (
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	long NCurveIndex,				// IN:  �Է� Curve ����
	long *NCurve,					// IN:  Curve �� (�Է� ������� Index������)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,			// IN:  Curve ����
	double *CurveRateInfo,			// IN:  Curve Rate ( 0.01(1%)������ �Է�) 

	long *CrvDayCntType,			// IN:  Curve Day Count Type  ( ũ�� : NCurveIndex )
	long NCrcyIndex,				// IN:  �Է� ��ȭ ����
	double *FXRateInfo,				// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,				// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,			// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )
	
	double *Leg_RefRatePeriod,		// IN:  Leg �� Ref Rate �����ֱ�(��) ( [0] : Rcv Ref Rate �����ֱ�, [1] : Pay Ref Rate �����ֱ� )
	double *Leg_SwapRateFixedPeriod,// IN:  Leg �� Swap Rate Fixed Leg �����ֱ�(��) ( [0] : Rcv Ref Curve �����ֱ�, [1] : Pay Ref Curve �����ֱ� )
	long *Leg_SwapRateFixedNumCpn,	// IN:  Leg �� Swap Rate Fixed Leg ����Ƚ��  ( [0] : Rcv Ref Curve ���� ���� Ƚ��, [1] : Pay Ref Curve ���� ���� Ƚ�� )
	long *Leg_CpnPeriodType,		// IN:  ����/���� ���� ����/���� ���� Flag ( 1 : ����, 2 : ����, 3 : ����,���� ȥ��(Slope�� 0, 1�̾ƴ� Case ) ( [0] : Rcv ����/��������, [1] : Pay ����/���� ���� )
	long *Leg_PaiedTime,			// IN:  Leg �� ��/���� ���� ( 1 : ����, 2 : ����)
	
	long *Leg_InArrearFlag,			// IN:  Leg �� In Arrear ���� ( 0 : In Advanced, 1 : In Arrear )
	long *Leg_CpnDayCntType,		// IN:  Leg �� ���� Day Count Convention ( ũ�� : 2 )
	long *Leg_AdjustFlag,			// IN:  Leg �� Adjustment ���� ( [0] : Rcv Convexity Adjust, [1] : Rcv Timing Adjust, [2] : Pay Convexity Adjust, [3] : Pay Timing Adjust )
	long *Leg_NCapVol,				// IN:  Leg �� Cap Vol ��
	double *Leg_CapVolTerm,			// IN:  Ref Curve Rate Cap Vol Term (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	
	double *Leg_CapVol,				// IN:  Ref Curve Rate Cap Vol (ũ�� : Leg_NCapVol[0] + Leg_NCapVol[1])
	double *Leg_TimingCorr,			// IN:  Timing Adjustment Corr ( [0] : Rcv Forward Corr, [1] : Pay Forward Corr )
	long *Leg_NSwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv)
	long *Leg_NSwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term ���� ( [0] : Rcv Ref Crv, [1] : Pay Ref Crv )
	double *Leg_SwaptionVolSwapMat,	// IN:  Ref Curve Swaption Swap Mat Term (��)
	
	double *Leg_SwaptionVolOptMat,	// IN:  Ref Curve Swaption Option Term (��)
	double *Leg_SwaptionVol,		// IN:  Ref Curve Swaption Volatility
	long *Leg_NPrinCashFlow,		// IN:  Leg�� ������� ( [0] : Rcv ������� ���� ��, [1] : Pay ������� ���� �� )
	double *Leg_PrinCashFlow,		// IN:  �ش� Leg ���� ���� ���޾� ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_PrinSettleDate,		// IN:  �ش� Leg ���� ���� ������ (YYYYMMDD) ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	
	double *Leg_PrinDiscFactor,		// OUT: �ش� Leg ������� Discount Factor ( ũ�� : Leg_NPrinCashFlow[0] + Leg_NPrinCashFlow[1] )
	long *Leg_NCpnCashFlow,			// IN:  �ش� Leg Coupon CashFlow ���� ( [0] : Rcv Coupon �����帧 ����, [1] : Pay Coupon �����帧 ���� )
	long *Leg_ResetFixDate,			// IN:  ������ (YYYYMMDD)  ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_DesignateResetFlag,	// IN:  ������ �Է� Flag (SwapRate������ �ƴ� ��쿡�� ���) ( 0 : �����, �⸻�Ϸ� ����( In Arrear�϶� �����Ϸκ��� ��¥ ���� ), 1 : �ݸ����� ������, ������ ������� ��� ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_ForwardStartDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnFormDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	
	long *Leg_ForwardEndDate,		// IN:  Forward��� ������ (YYYYMMDD) ( DesignateResetFlag[i] = 1�϶��� ���, �̿��� ��� CpnEndDate�� �����ϰ� �Է� Defalut ) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixDates,			// IN:  Average Reset �� �ϼ� (�����Ϸκ��� NFixDates�ϵ����� ��ձݸ��� ���) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_NFixedDates,			// IN:  ������� �����ϴ� ������ Ȯ���� Average Reset �ϼ� (RefRate�� ��յ� �� ����) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnFromDate,			// IN:  ����� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long *Leg_CpnToDate,			// IN:  �⸻�� (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	
	long *Leg_CpnSettleDate,		// IN:  ������ (YYYYMMDD) ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnNA,				// IN:  Coupon ���ؿ��� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSlope,			// IN:  Coupon �����ݸ� ���� ���� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnSpread,			// IN:  Coupon �����ݸ� ������ ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnRefRate,			// IN/OUT:  Ȯ���ݸ� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	
	double *Leg_CpnCashFlow,		// IN/OUT:  �������� ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	double *Leg_CpnDiscFactor,		// OUT: Discount Factor ( ũ�� : Leg_NCpnCashFlow[0] + Leg_NCpnCashFlow[1] )
	long* SOFRFlags,				// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag [3] RateInterpolation Flag
	long* SOFRConv,					// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,				// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����
	
	long* Holiday,					// IN: Holiday Rcv,Pay
	long* RefRateHistoryCount,		// IN: [0]RcvRefRateHistoryCount, [1]PayRefRateHistoryCount
	long* RefRateHistoryDate,		// IN: RcvRefRateHistoryDate + PayRefRateHistoryDate
	double* RefRateHistory,			// IN: RcvRefRateHistory + PayRefRateHistory
	long TextFlag,					// IN:  Textdump ��¿��� ( 0 : �����, 1 : ��� )
	
	long GreekFlag,					// IN:  Greeks ��꿩�� ( 0 : ������, 1 : ����� )
	double *PV01,					// OUT: �� Ŀ�꺰 PV01
	double *KeyRateDuration,		// OUT: �� Leg, Curve�� KeyRate Duration
	double *KeyRateConvexity,		// OUT: �� Leg, Curve�� KeyRate Convexity
	double *ResultPrice				// OUT: ����� ���
)
{
	char szModuleName[] = "KISP_IRSwap";
	char szFileName[100];
	get_filename(szFileName, szModuleName);
	
	if(TextFlag == 1)
	{
		InputCheck_IRSwap(	PriceDate,				NCurveIndex,				NCurve,						CurveTermInfo,			CurveRateInfo,
							CrvDayCntType,			NCrcyIndex,					FXRateInfo,					Leg_CrvIndex,			Leg_CrcyIndex,	
							Leg_RefRatePeriod,		Leg_SwapRateFixedPeriod,	Leg_SwapRateFixedNumCpn,	Leg_CpnPeriodType,		Leg_PaiedTime,	
							Leg_InArrearFlag,		Leg_CpnDayCntType,			Leg_AdjustFlag,				Leg_NCapVol,			Leg_CapVolTerm,	
							Leg_CapVol,				Leg_TimingCorr,				Leg_NSwaptionVolSwapMat,	Leg_NSwaptionVolOptMat,	Leg_SwaptionVolSwapMat,
							Leg_SwaptionVolOptMat,	Leg_SwaptionVol,			Leg_NPrinCashFlow,			Leg_PrinCashFlow,		Leg_PrinSettleDate,	
							Leg_PrinDiscFactor,		Leg_NCpnCashFlow,			Leg_ResetFixDate,			Leg_DesignateResetFlag,	Leg_ForwardStartDate,	
							Leg_ForwardEndDate,		Leg_NFixDates,				Leg_NFixedDates,			Leg_CpnFromDate,		Leg_CpnToDate,		
							Leg_CpnSettleDate,		Leg_CpnNA,					Leg_CpnSlope,				Leg_CpnSpread,			Leg_CpnRefRate,		
							Leg_CpnCashFlow,		Leg_CpnDiscFactor,			SOFRFlags,					SOFRConv,				HolidayCount,
							Holiday,				RefRateHistoryCount,		RefRateHistoryDate,			RefRateHistory,			TextFlag,				
							GreekFlag,				szFileName,					szModuleName);
	}

	long ResultCode = -1;

	ResultCode = Exception_IRSwap(	PriceDate,				NCurveIndex,				NCurve,						CurveTermInfo,			CurveRateInfo,					
									CrvDayCntType,			NCrcyIndex,					FXRateInfo,					Leg_CrvIndex,			Leg_CrcyIndex,	
									Leg_RefRatePeriod,		Leg_SwapRateFixedPeriod,	Leg_SwapRateFixedNumCpn,	Leg_CpnPeriodType,		Leg_PaiedTime,	
									Leg_InArrearFlag,		Leg_CpnDayCntType,			Leg_AdjustFlag,				Leg_NCapVol,			Leg_CapVolTerm,	
									Leg_CapVol,				Leg_TimingCorr,				Leg_NSwaptionVolSwapMat,	Leg_NSwaptionVolOptMat,	Leg_SwaptionVolSwapMat,
									Leg_SwaptionVolOptMat,	Leg_SwaptionVol,			Leg_NPrinCashFlow,			Leg_PrinCashFlow,		Leg_PrinSettleDate,	
									Leg_PrinDiscFactor,		Leg_NCpnCashFlow,			Leg_ResetFixDate,			Leg_DesignateResetFlag,	Leg_ForwardStartDate,	
									Leg_ForwardEndDate,		Leg_NFixDates,				Leg_NFixedDates,			Leg_CpnFromDate,		Leg_CpnToDate,		
									Leg_CpnSettleDate,		Leg_CpnNA,					Leg_CpnSlope,				Leg_CpnSpread,			Leg_CpnRefRate,		
									Leg_CpnCashFlow,		Leg_CpnDiscFactor,			SOFRFlags,					SOFRConv,				HolidayCount,
									Holiday,				RefRateHistoryCount,		RefRateHistoryDate,			RefRateHistory,			TextFlag,					GreekFlag				);

	if(ResultCode<0)
	{
		if(TextFlag==1)
			LoggingData(szModuleName, szFileName, "ErrorCode", ResultCode);
		return ResultCode;
	}

	long i, j, k;
	long ii, jj;
	long SumIndex = 0;
	long NCurveSum = 0;

	//// ���������� /////////////////////////////////////////////////////////////////////////////////////////

	// ��������
	long Rcv_DisCrvIndex = Leg_CrvIndex[0];
	long Rcv_RefCrvIndex = Leg_CrvIndex[1];
	long Pay_DisCrvIndex = Leg_CrvIndex[2];
	long Pay_RefCrvIndex = Leg_CrvIndex[3];

	long Rcv_CrcyIndex = Leg_CrcyIndex[0];
	long Pay_CrcyIndex = Leg_CrcyIndex[1];
	long Calc_CrcyIndex = Leg_CrcyIndex[2];
		
	double Rcv_RefRatePeriod = Leg_RefRatePeriod[0];
	double Pay_RefRatePeriod = Leg_RefRatePeriod[1];

	double Rcv_SwapRateFixedPeriod = Leg_SwapRateFixedPeriod[0];
	double Pay_SwapRateFixedPeriod = Leg_SwapRateFixedPeriod[1];

	long Rcv_SwapRateFixedNumCpn = Leg_SwapRateFixedNumCpn[0];
	long Pay_SwapRateFixedNumCpn = Leg_SwapRateFixedNumCpn[1];

	long Rcv_CpnPeriodType = Leg_CpnPeriodType[0];
	long Pay_CpnPeriodType = Leg_CpnPeriodType[1];

	long Rcv_PaiedTime = Leg_PaiedTime[0];
	long Pay_PaiedTime = Leg_PaiedTime[1];

	long Rcv_InArrearFlag = Leg_InArrearFlag[0];
	long Pay_InArrearFlag = Leg_InArrearFlag[1];

	long Rcv_CpnDayCountType = Leg_CpnDayCntType[0];
	long Pay_CpnDayCountType = Leg_CpnDayCntType[1];

	long Rcv_ConvexityAdjustFlag = Leg_AdjustFlag[0];
	long Rcv_TimingAdjustFlag = Leg_AdjustFlag[1];
	long Pay_ConvexityAdjustFlag = Leg_AdjustFlag[2];
	long Pay_TimingAdjustFlag = Leg_AdjustFlag[3];

	long Rcv_NCapVolTerm = Leg_NCapVol[0];
	long Pay_NCapVolTerm = Leg_NCapVol[1];

	double *Rcv_CapVolTerm = Leg_CapVolTerm;
	double *Pay_CapVolTerm = Leg_CapVolTerm+Leg_NCapVol[0];

	double *Rcv_CapVol = Leg_CapVol;
	double *Pay_CapVol = Leg_CapVol+Leg_NCapVol[0];

	double Rcv_TimingCorr = Leg_TimingCorr[0];
	double Pay_TimingCorr = Leg_TimingCorr[1];

	long Rcv_NSwaptionVolSwapMat = Leg_NSwaptionVolSwapMat[0];
	long Pay_NSwaptionVolSwapMat = Leg_NSwaptionVolSwapMat[1];

	long Rcv_NSwaptionVolOptMat = Leg_NSwaptionVolOptMat[0];
	long Pay_NSwaptionVolOptMat = Leg_NSwaptionVolOptMat[1];

	double *Rcv_SwaptionVolSwapMat = Leg_SwaptionVolSwapMat;
	double *Pay_SwaptionVolSwapMat = Leg_SwaptionVolSwapMat+Leg_NSwaptionVolSwapMat[0];

	double *Rcv_SwaptionVolOptMat = Leg_SwaptionVolOptMat;
	double *Pay_SwaptionVolOptMat = Leg_SwaptionVolOptMat+Leg_NSwaptionVolOptMat[0];

	double *Rcv_SwaptionVol = Leg_SwaptionVol;
	double *Pay_SwaptionVol = Leg_SwaptionVol + Leg_NSwaptionVolSwapMat[0]*Leg_NSwaptionVolOptMat[0];

	// ���� Cash Flow
	long Rcv_NPrinCashFlow = Leg_NPrinCashFlow[0];
	long Pay_NPrinCashFlow = Leg_NPrinCashFlow[1];

	double *Rcv_PrinCashFlow = Leg_PrinCashFlow;
	double *Pay_PrinCashFlow = Leg_PrinCashFlow+Leg_NPrinCashFlow[0];

	long *Rcv_PrinSettleDate = Leg_PrinSettleDate;
	long *Pay_PrinSettleDate = Leg_PrinSettleDate+Leg_NPrinCashFlow[0];

	double *Rcv_PrinDiscFactor = Leg_PrinDiscFactor;
	double *Pay_PrinDiscFactor = Leg_PrinDiscFactor+Leg_NPrinCashFlow[0];

	// Coupon Cash Flow
	long Rcv_NCpnCashFlow = Leg_NCpnCashFlow[0];
	long Pay_NCpnCashFlow = Leg_NCpnCashFlow[1];

	long *Rcv_ResetFixDate = Leg_ResetFixDate;
	long *Pay_ResetFixDate = Leg_ResetFixDate+Leg_NCpnCashFlow[0];

	long *Rcv_DesignateResetFlag = Leg_DesignateResetFlag;
	long *Pay_DesignateResetFlag = Leg_DesignateResetFlag+Leg_NCpnCashFlow[0];

	long *Rcv_ForwardStartDate = Leg_ForwardStartDate;
	long *Pay_ForwardStartDate = Leg_ForwardStartDate+Leg_NCpnCashFlow[0];

	long *Rcv_ForwardEndDate = Leg_ForwardEndDate;
	long *Pay_ForwardEndDate = Leg_ForwardEndDate+Leg_NCpnCashFlow[0];

	long *Rcv_NFixDates = Leg_NFixDates;
	long *Pay_NFixDates = Leg_NFixDates+Leg_NCpnCashFlow[0];

	long *Rcv_NFixedDates = Leg_NFixedDates;
	long *Pay_NFixedDates = Leg_NFixedDates+Leg_NCpnCashFlow[0];

	long *Rcv_CpnFromDate = Leg_CpnFromDate;
	long *Pay_CpnFromDate = Leg_CpnFromDate+Leg_NCpnCashFlow[0];

	long *Rcv_CpnToDate = Leg_CpnToDate;
	long *Pay_CpnToDate = Leg_CpnToDate+Leg_NCpnCashFlow[0];

	long *Rcv_CpnSettleDate = Leg_CpnSettleDate;
	long *Pay_CpnSettleDate = Leg_CpnSettleDate+Leg_NCpnCashFlow[0];

	double *Rcv_CpnNA = Leg_CpnNA;
	double *Pay_CpnNA = Leg_CpnNA+Leg_NCpnCashFlow[0];

	double *Rcv_CpnSlope = Leg_CpnSlope;
	double *Pay_CpnSlope = Leg_CpnSlope+Leg_NCpnCashFlow[0];

	double *Rcv_CpnSpread = Leg_CpnSpread;
	double *Pay_CpnSpread = Leg_CpnSpread+Leg_NCpnCashFlow[0];

	double *Rcv_CpnRefRate = Leg_CpnRefRate;
	double *Pay_CpnRefRate = Leg_CpnRefRate+Leg_NCpnCashFlow[0];

	double *Rcv_CpnCashFlow = Leg_CpnCashFlow;
	double *Pay_CpnCashFlow = Leg_CpnCashFlow+Leg_NCpnCashFlow[0];

	double *Rcv_CpnDiscFactor = Leg_CpnDiscFactor;
	double *Pay_CpnDiscFactor = Leg_CpnDiscFactor+Leg_NCpnCashFlow[0];

	//// ���������� �� /////////////////////////////////////////////////////////////////////////////////////////

	double Rcv_Price[2] = {0.0, 0.0};
	double Pay_Price[2] = {0.0, 0.0};

	double Price_Up[4] = {0.0, 0.0, 0.0, 0.0};
	double Price_Dn[4] = {0.0, 0.0, 0.0, 0.0};

	double Rcv_CrcyRate = FXRateInfo[Rcv_CrcyIndex];
	double Pay_CrcyRate = FXRateInfo[Pay_CrcyIndex];
	double Calc_CrcyRate = FXRateInfo[Calc_CrcyIndex];

	double *Rcv_PrinDiscFactor_Temp;
	double *Rcv_CpnRefRate_Temp;
	double *Rcv_CpnCashFlow_Temp;
	double *Rcv_CpnDiscFactor_Temp;

	double *Pay_PrinDiscFactor_Temp;
	double *Pay_CpnRefRate_Temp;
	double *Pay_CpnCashFlow_Temp;
	double *Pay_CpnDiscFactor_Temp;

	double *CurveRateInfo_Up;
	double *CurveRateInfo_Dn;

	double *FXRateInfo_Up;
	double *FXRateInfo_Dn;

	double *Rcv_DisCrvTerm;
	double *Rcv_DisCrvRate;
	double *Rcv_RefCrvTerm;
	double *Rcv_RefCrvRate;

	double *Pay_DisCrvTerm;
	double *Pay_DisCrvRate;
	double *Pay_RefCrvTerm;
	double *Pay_RefCrvRate;

	double *Rcv_CpnRefRate_Org;
	double *Rcv_CpnCashFlow_Org;
	double *Pay_CpnRefRate_Org;
	double *Pay_CpnCashFlow_Org;

	// Key Rate Duration ����
	double Rcv_Price_Up[2] = {0.0, 0.0};
	double Rcv_Price_Dn[2] = {0.0, 0.0};
	double Pay_Price_Up[2] = {0.0, 0.0};
	double Pay_Price_Dn[2] = {0.0, 0.0};

	double *Rcv_DisCrvRate_Up;
	double *Rcv_RefCrvRate_Up;
	double *Pay_DisCrvRate_Up;
	double *Pay_RefCrvRate_Up;

	double *Rcv_DisCrvRate_Dn;
	double *Rcv_RefCrvRate_Dn;
	double *Pay_DisCrvRate_Dn;
	double *Pay_RefCrvRate_Dn;

	// CashFlow������ 0���� �Էµ� ��� ���������� ���� +1���� �� �����
	Rcv_CpnRefRate_Org = (double *)malloc((Rcv_NCpnCashFlow+1)*sizeof(double));
	Rcv_CpnCashFlow_Org = (double *)malloc((Rcv_NCpnCashFlow+1)*sizeof(double));
	Pay_CpnRefRate_Org = (double *)malloc((Pay_NCpnCashFlow+1)*sizeof(double));
	Pay_CpnCashFlow_Org = (double *)malloc((Pay_NCpnCashFlow+1)*sizeof(double));

	for(i=0;i<Rcv_NCpnCashFlow;i++)
	{
		Rcv_CpnRefRate_Org[i] =  Rcv_CpnRefRate[i];
		Rcv_CpnCashFlow_Org[i] = Rcv_CpnCashFlow[i];
	}

	for(i=0;i<Pay_NCpnCashFlow;i++)
	{
		Pay_CpnRefRate_Org[i] =  Pay_CpnRefRate[i];
		Pay_CpnCashFlow_Org[i] = Pay_CpnCashFlow[i];
	}

	// �� Curve ���� /////////////////////////////////////////////
	for(i=0;i<4;i++)
	{
		if(i==0)
			k = Rcv_DisCrvIndex;
		else if(i==1)
			k = Rcv_RefCrvIndex;
		else if(i==2)
			k = Pay_DisCrvIndex;
		else
			k = Pay_RefCrvIndex;

		NCurveSum = 0;
		for(j=0;j<k;j++) 
		{
			NCurveSum += NCurve[j];
		}

		if(i==0) // Rcv Discount Curve
		{
			Rcv_DisCrvTerm = CurveTermInfo+NCurveSum;
			Rcv_DisCrvRate = CurveRateInfo+NCurveSum;
		}
		else if(i==1) // Rcv Reference Curve
		{
			Rcv_RefCrvTerm = CurveTermInfo+NCurveSum;
			Rcv_RefCrvRate = CurveRateInfo+NCurveSum;
		}
		else if(i==2) // Pay Discount Curve
		{
			Pay_DisCrvTerm = CurveTermInfo+NCurveSum;
			Pay_DisCrvRate = CurveRateInfo+NCurveSum;
		}
		else // Pay Reference Curve
		{
			Pay_RefCrvTerm = CurveTermInfo+NCurveSum;
			Pay_RefCrvRate = CurveRateInfo+NCurveSum;
		}
	}
	//////////////////////////////////////////////////////////////
	// SOFR ���� ����
	long SOFRUseFlag = SOFRFlags[0];
	long RcvDailyRateLoggingFlag = SOFRFlags[1];
	long PayDailyRateLoggingFlag = SOFRFlags[2];
	long InterpolateFlag = SOFRFlags[3];

	long *RcvSOFRConv = SOFRConv;
	long *PaySOFRConv = SOFRConv + 4;
	long NRcvHoliday = HolidayCount[0];
	long NPayHoliday = HolidayCount[1];
	long *RcvHoliday = Holiday;
	long *PayHoliday = Holiday + NRcvHoliday;
	long NRcvRefHistory = RefRateHistoryCount[0];
	long NPayRefHistory = RefRateHistoryCount[1];
	long *RcvRefHistoryDate = RefRateHistoryDate;
	long *PayRefHistoryDate = RefRateHistoryDate + NRcvRefHistory;
	double *RcvRefHistory = RefRateHistory;
	double *PayRefHistory = RefRateHistory + NRcvRefHistory;

	long Rcv_HolidayStartDate = 20000101;
	long Rcv_HolidayEndDate = max(max(Rcv_ResetFixDate[Rcv_NCpnCashFlow-1], Rcv_ForwardEndDate[Rcv_NCpnCashFlow-1]), Rcv_CpnSettleDate[Rcv_NCpnCashFlow-1]);
	long Rcv_NHolidayFast = 0;
	long* Rcv_HolidayFast;

	long Rcv_HistoryStartDate = 20000101;
	long Rcv_HistoryEndDate = PriceDate;
	long Rcv_NHistoryFast = 0;
	long *Rcv_HistoryRateDate;
	double *Rcv_HistoryRate;

	long Pay_HolidayStartDate = 20000101;
	long Pay_HolidayEndDate = max(max(Pay_ResetFixDate[Pay_NCpnCashFlow-1], Pay_ForwardEndDate[Pay_NCpnCashFlow-1]), Pay_CpnSettleDate[Pay_NCpnCashFlow-1]);
	long Pay_NHolidayFast=0;
	long* Pay_HolidayFast;

	long Pay_HistoryStartDate = 20000101;
	long Pay_HistoryEndDate = PriceDate;
	long Pay_NHistoryFast=0;
	long *Pay_HistoryRateDate;
	double *Pay_HistoryRate;

	if (SOFRUseFlag == 1 || SOFRUseFlag == 2)
	{
		////////////////
		// Rcv Holiday, RefRate History �ʹ� �� ���ų� �ʹ� �� �̷� �����ʹ� ����
		////////////////

		Rcv_HolidayStartDate = ActDateAdjust(PriceDate, -365*3);
		Rcv_HistoryStartDate = Rcv_HolidayStartDate;

		Rcv_NHolidayFast = 0;
		for (i = 0 ; i < NRcvHoliday; i++)
		{
			if ( RcvHoliday[i] >= Rcv_HolidayStartDate && RcvHoliday[i] <= Rcv_HolidayEndDate) Rcv_NHolidayFast += 1;
		}		
		Rcv_HolidayFast = (long*)malloc(sizeof(long) * max(1,Rcv_NHolidayFast));

		k = 0;
		for (i = 0 ; i < NRcvHoliday; i++)
		{
			if ( RcvHoliday[i] >= Rcv_HolidayStartDate && RcvHoliday[i] <= Rcv_HolidayEndDate) 
			{
				Rcv_HolidayFast[k] = RcvHoliday[i];
				k += 1;
			}			
		}

		Rcv_NHistoryFast = 0;
		for (i = 0 ; i < NRcvRefHistory; i++)
		{
			if ( RcvRefHistoryDate[i] >= Rcv_HistoryStartDate && RcvRefHistoryDate[i] <= Pay_HistoryEndDate) Rcv_NHistoryFast +=1;
		}
		Rcv_HistoryRateDate = (long*)malloc(sizeof(long) * max(1, Rcv_NHistoryFast));
		Rcv_HistoryRate = (double*)malloc(sizeof(double) * max(1, Rcv_NHistoryFast));

		k = 0;
		for (i = 0 ; i < NRcvRefHistory; i++)
		{
			if ( RcvRefHistoryDate[i] >= Rcv_HistoryStartDate && RcvRefHistoryDate[i] <= Pay_HistoryEndDate)
			{
				Rcv_HistoryRateDate[k] = RcvRefHistoryDate[i];
				Rcv_HistoryRate[k] = RcvRefHistory[i];
				k += 1;
			}
		}
		
		////////////////
		// Pay Holiday, RefRate History
		////////////////
		Pay_HolidayStartDate = ActDateAdjust(PriceDate, -365*3);
		Pay_HistoryStartDate = Pay_HolidayStartDate;

		Pay_NHolidayFast = 0;
		for (i = 0 ; i < NPayHoliday; i++)
		{
			if ( PayHoliday[i] >= Pay_HolidayStartDate && PayHoliday[i] <= Pay_HolidayEndDate) Pay_NHolidayFast += 1;
		}		
		Pay_HolidayFast = (long*)malloc(sizeof(long) * max(1,Pay_NHolidayFast));

		k = 0;
		for (i = 0 ; i < NPayHoliday; i++)
		{
			if ( PayHoliday[i] >= Pay_HolidayStartDate && PayHoliday[i] <= Pay_HolidayEndDate) 
			{
				Pay_HolidayFast[k] = PayHoliday[i];
				k += 1;
			}			
		}

		Pay_NHistoryFast = 0;
		for (i = 0 ; i < NPayRefHistory; i++)
		{
			if ( PayRefHistoryDate[i] >= Pay_HistoryStartDate && PayRefHistoryDate[i] <= Pay_HistoryEndDate) Pay_NHistoryFast +=1;
		}
		Pay_HistoryRateDate = (long*)malloc(sizeof(long) * max(1, Pay_NHistoryFast));
		Pay_HistoryRate = (double*)malloc(sizeof(double) * max(1, Pay_NHistoryFast));

		k = 0;
		for (i = 0 ; i < NPayRefHistory; i++)
		{
			if ( PayRefHistoryDate[i] >= Pay_HistoryStartDate && PayRefHistoryDate[i] <= Pay_HistoryEndDate)
			{
				Pay_HistoryRateDate[k] = PayRefHistoryDate[i];
				Pay_HistoryRate[k] = PayRefHistory[i];
				k += 1;
			}
		}
	}
	else
	{
		Rcv_HolidayFast = (long*)malloc(sizeof(long) * 1);
		Rcv_HistoryRateDate = (long*)malloc(sizeof(long) * 1);
		Rcv_HistoryRate = (double*)malloc(sizeof(double) * 1);
		Pay_HolidayFast = (long*)malloc(sizeof(long) * 1);
		Pay_HistoryRateDate = (long*)malloc(sizeof(long) * 1);
		Pay_HistoryRate = (double*)malloc(sizeof(double) * 1);
	}

	//////////////////////////////////////////////////////////////
	ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
								Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
								Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
								Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
								Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
								Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,				Rcv_PrinSettleDate,
								Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
								Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
								Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
								RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
								Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
								Rcv_Price,					InterpolateFlag,			szModuleName,				szFileName);

	ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
								Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
								Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
								Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
								Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
								Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,				Pay_PrinSettleDate,
								Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
								Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
								Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
								PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
								Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
								Pay_Price,					InterpolateFlag,			szModuleName,				szFileName					);

	// ����
	ResultPrice[0] = Rcv_Price[0]*(Calc_CrcyRate/Rcv_CrcyRate) - Pay_Price[0]*(Calc_CrcyRate/Pay_CrcyRate);

	// Rcv ���� (Rcv ��ȭ)
	ResultPrice[1] = Rcv_Price[0];

	// Pay ���� (Pay ��ȭ)
	ResultPrice[2] = Pay_Price[0];

	// Rcv ������� (Rcv ��ȭ)
	ResultPrice[3] = Rcv_Price[1];

	// Pay ������� (Pay ��ȭ)
	ResultPrice[4] = Pay_Price[1];

	// Logging���ֱ�
	RcvDailyRateLoggingFlag = 0;
	PayDailyRateLoggingFlag = 0;

	if(GreekFlag == 1 && ResultCode>0)
	{
		// NPrinCashFlow or NCpnCashFlow�� 0�� �ԷµǾ����� ���������� ���� +1���� �� �����
		Rcv_PrinDiscFactor_Temp = (double *)malloc((Rcv_NPrinCashFlow+1)*sizeof(double));
		Rcv_CpnRefRate_Temp = (double *)malloc((Rcv_NCpnCashFlow+1)*sizeof(double));
		Rcv_CpnCashFlow_Temp = (double *)malloc((Rcv_NCpnCashFlow+1)*sizeof(double));
		Rcv_CpnDiscFactor_Temp = (double *)malloc((Rcv_NCpnCashFlow+1)*sizeof(double));

		Pay_PrinDiscFactor_Temp = (double *)malloc((Pay_NPrinCashFlow+1)*sizeof(double));
		Pay_CpnRefRate_Temp = (double *)malloc((Pay_NCpnCashFlow+1)*sizeof(double));
		Pay_CpnCashFlow_Temp = (double *)malloc((Pay_NCpnCashFlow+1)*sizeof(double));
		Pay_CpnDiscFactor_Temp = (double *)malloc((Pay_NCpnCashFlow+1)*sizeof(double));

		SumIndex = 0;
		for(i=0;i<NCurveIndex;i++) SumIndex += NCurve[i];

		CurveRateInfo_Up = (double *)malloc(SumIndex*sizeof(double));
		CurveRateInfo_Dn = (double *)malloc(SumIndex*sizeof(double));

		FXRateInfo_Up = (double *)malloc(NCrcyIndex*sizeof(double));
		FXRateInfo_Dn = (double *)malloc(NCrcyIndex*sizeof(double));

		
		// �ʱⰪ ���� ////////////////////////////////////////////////////////////
		for(j=0;j<Rcv_NPrinCashFlow;j++)
		{
			Rcv_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Pay_NPrinCashFlow;j++)
		{
			Pay_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Rcv_NCpnCashFlow;j++)
		{
			Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
			Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
			Rcv_CpnDiscFactor_Temp[j] = 0.0;
		}

		for(j=0;j<Pay_NCpnCashFlow;j++)
		{
			Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
			Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
			Pay_CpnDiscFactor_Temp[j] = 0.0;
		}

		// �Ʒ� ��꿡�� ���� ������ ����
		Rcv_PrinDiscFactor = Rcv_PrinDiscFactor_Temp;
		Rcv_CpnRefRate = Rcv_CpnRefRate_Temp;
		Rcv_CpnCashFlow = Rcv_CpnCashFlow_Temp;
		Rcv_CpnDiscFactor = Rcv_CpnDiscFactor_Temp;

		Pay_PrinDiscFactor = Pay_PrinDiscFactor_Temp;
		Pay_CpnRefRate = Pay_CpnRefRate_Temp;
		Pay_CpnCashFlow = Pay_CpnCashFlow_Temp;
		Pay_CpnDiscFactor = Pay_CpnDiscFactor_Temp;

		SumIndex = 0;
		for(i=0;i<NCurveIndex;i++)
		{
			for(j=0;j<NCurve[i];j++)
			{
				CurveRateInfo_Up[SumIndex+j] = CurveRateInfo[SumIndex+j];
				CurveRateInfo_Dn[SumIndex+j] = CurveRateInfo[SumIndex+j];
			}
			SumIndex += NCurve[i];
		}
		///////////////////////////////////////////////////////////////////////////
		
		// Curve�� PV01 ��� ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		for(i=0;i<4;i++) // UpPrice�� ���ϱ� ���� ����
		{
			if(i==0)
				k = Rcv_DisCrvIndex;
			else if(i==1)
				k = Rcv_RefCrvIndex;
			else if(i==2)
				k = Pay_DisCrvIndex;
			else
				k = Pay_RefCrvIndex;

			NCurveSum = 0;
			for(j=0;j<k;j++) 
			{
				NCurveSum += NCurve[j];
			}

			if(i==0) // Rcv Discount Curve
			{
				Rcv_DisCrvRate = CurveRateInfo_Up+NCurveSum;
			}
			else if(i==1) // Rcv Reference Curve
			{
				Rcv_RefCrvRate = CurveRateInfo_Up+NCurveSum;
			}
			else if(i==2) // Pay Discount Curve
			{
				Pay_DisCrvRate = CurveRateInfo_Up+NCurveSum;
			}
			else // Pay Reference Curve
			{
				Pay_RefCrvRate = CurveRateInfo_Up+NCurveSum;
			}
		}

		NCurveSum = 0;
		for(i=0;i<NCurveIndex;i++)
		{
			for(j=0;j<NCurve[i];j++)
			{
				for(ii=0;ii<4;ii++) Price_Up[ii] = 0.0;

				SumIndex = 0;
				for(ii=0;ii<NCurveIndex;ii++)
				{
					for(jj=0;jj<NCurve[ii];jj++)
					{
						if(i==ii&&j==jj)
						{
							CurveRateInfo_Up[SumIndex+jj] = CurveRateInfo[SumIndex+jj] + 0.0001; // 1bp
						}
						else
							CurveRateInfo_Up[SumIndex+jj] = CurveRateInfo[SumIndex+jj];
					}
					SumIndex += NCurve[ii];
				}

				if(i==Rcv_DisCrvIndex || i==Rcv_RefCrvIndex)
				{
					for(jj=0;jj<Rcv_NPrinCashFlow;jj++)
					{
						Rcv_PrinDiscFactor_Temp[jj] =  0.0;
					}

					for(jj=0;jj<Rcv_NCpnCashFlow;jj++)
					{
						Rcv_CpnRefRate_Temp[jj] =  Rcv_CpnRefRate_Org[jj];
						Rcv_CpnCashFlow_Temp[jj] = Rcv_CpnCashFlow_Org[jj];
						Rcv_CpnDiscFactor_Temp[jj] = 0.0;
					}

					ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
												Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
												Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
												Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
												Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
												Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,				Rcv_PrinSettleDate,
												Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
												Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
												Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
												RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
												Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,			Rcv_CpnCashFlow,			Rcv_CpnDiscFactor,			
												Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
				}
				else
				{
					Price_Up[0] = ResultPrice[1];
				}

				if(i==Pay_DisCrvIndex || i==Pay_RefCrvIndex)
				{
					for(jj=0;jj<Pay_NPrinCashFlow;jj++)
					{
						Pay_PrinDiscFactor_Temp[jj] =  0.0;
					}

					for(jj=0;jj<Pay_NCpnCashFlow;jj++)
					{
						Pay_CpnRefRate_Temp[jj] =  Pay_CpnRefRate_Org[jj];
						Pay_CpnCashFlow_Temp[jj] = Pay_CpnCashFlow_Org[jj];
						Pay_CpnDiscFactor_Temp[jj] = 0.0;
					}

					ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
												Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
												Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
												Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
												Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
												Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,				Pay_PrinSettleDate,
												Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
												Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
												Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
												PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
												Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,
												Price_Up+2,					InterpolateFlag,			szModuleName,				szFileName					);
				}
				else
				{
					Price_Up[2] = ResultPrice[2];
				}

				PV01[NCurveSum+j] = (Price_Up[0]*(Calc_CrcyRate/Rcv_CrcyRate) - Price_Up[2]*(Calc_CrcyRate/Pay_CrcyRate)) - ResultPrice[0];
			}
			NCurveSum += NCurve[i];
		}
		// Curve�� PV01 ��� �� ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		// Duration, Convexity ��� ////////////////////////////////////////////////////////////////////////////////////////////////////////////
		// Duration, Convexity ����, ������ ������ Coupon ���ڰ�� ��������� ���޵ȴٰ� �����ϰ� ����Ѵ�.
        double *Price_Up2 = (double*)malloc(sizeof(double)*4);
        double *Price_Dn2 = (double*)malloc(sizeof(double)*4);          ///// 20200519 BNK�������� �ݿ� �෹�̼� ������Ƽ ���� ������ ������� ���� ����ϰ� �ʹٰ� ��.

		for(i=0;i<4;i++)
		{
			Price_Up[i] = 0.0;
			Price_Dn[i] = 0.0;

            Price_Up2[i] = 0.0;
            Price_Dn2[i] = 0.0;
		}

		SumIndex = 0;
		for(i=0;i<NCurveIndex;i++)
		{
			for(j=0;j<NCurve[i];j++)
			{
				CurveRateInfo_Up[SumIndex+j] = CurveRateInfo[SumIndex+j] + 0.0001;
				CurveRateInfo_Dn[SumIndex+j] = CurveRateInfo[SumIndex+j] - 0.0001;
			}
			SumIndex += NCurve[i];
		}

		for(j=0;j<Rcv_NPrinCashFlow;j++)
		{
			Rcv_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Pay_NPrinCashFlow;j++)
		{
			Pay_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Rcv_NCpnCashFlow;j++)
		{
			Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
			Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
			Rcv_CpnDiscFactor_Temp[j] = 0.0;
		}

		for(j=0;j<Pay_NCpnCashFlow;j++)
		{
			Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
			Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
			Pay_CpnDiscFactor_Temp[j] = 0.0;
		}

		if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���  //200519 BNK�������� ��û���� ������� ���� ���� �ʴ� �ɷε� ���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,              			Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,	            Rcv_PrinSettleDate,
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,
										Price_Up2,					InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,	
										Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,	            Rcv_PrinSettleDate,
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,
										Price_Up2,					InterpolateFlag,			szModuleName,				szFileName					);
		}

		if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���      //200519 BNK�������� ��û���� ���� ���� �������� �ʴ� �������ε� ���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Up+2,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,	            Pay_PrinSettleDate,
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Up2+2,				InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Up+2,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,	            Pay_PrinSettleDate,
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Up2+2,				InterpolateFlag,			szModuleName,				szFileName					);
		}

		for(i=0;i<4;i++) // Dn Price�� ���ϱ� ���� ����
		{
			if(i==0)
				k = Rcv_DisCrvIndex;
			else if(i==1)
				k = Rcv_RefCrvIndex;
			else if(i==2)
				k = Pay_DisCrvIndex;
			else
				k = Pay_RefCrvIndex;

			NCurveSum = 0;
			for(j=0;j<k;j++) 
			{
				NCurveSum += NCurve[j];
			}

			if(i==0) // Rcv Discount Curve
			{
				Rcv_DisCrvRate = CurveRateInfo_Dn+NCurveSum;
			}
			else if(i==1) // Rcv Reference Curve
			{
				Rcv_RefCrvRate = CurveRateInfo_Dn+NCurveSum;
			}
			else if(i==2) // Pay Discount Curve
			{
				Pay_DisCrvRate = CurveRateInfo_Dn+NCurveSum;
			}
			else // Pay Reference Curve
			{
				Pay_RefCrvRate = CurveRateInfo_Dn+NCurveSum;
			}
		}

		for(j=0;j<Rcv_NPrinCashFlow;j++)
		{
			Rcv_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Pay_NPrinCashFlow;j++)
		{
			Pay_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Rcv_NCpnCashFlow;j++)
		{
			Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
			Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
			Rcv_CpnDiscFactor_Temp[j] = 0.0;
		}

		for(j=0;j<Pay_NCpnCashFlow;j++)
		{
			Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
			Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
			Pay_CpnDiscFactor_Temp[j] = 0.0;
		}

		if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���          //200519 BNK�������� ��û ���� ���� �������� �ʴ� �������ε� ���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Price_Dn,					InterpolateFlag, szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,	            Rcv_PrinSettleDate,
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Price_Dn2,					InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
				
            ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			Rcv_NPrinCashFlow,			Rcv_PrinCashFlow,	            Rcv_PrinSettleDate,
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Price_Dn2,					InterpolateFlag,			szModuleName,				szFileName					);
		}

		if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Dn+2,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,	            Pay_PrinSettleDate,
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,			
										Pay_CpnDiscFactor,			Price_Dn2+2,				InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Price_Dn+2,					InterpolateFlag,			szModuleName,				szFileName					);

            ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			Pay_NPrinCashFlow,			Pay_PrinCashFlow,	            Pay_PrinSettleDate,
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,			
										Pay_CpnDiscFactor,			Price_Dn2+2	,				InterpolateFlag,			szModuleName,				szFileName					);
		}



		// Duration���� ���� ���� Swap��ġ��� (Curve Dn�� ������� �����Ͽ� ���ݰ��)
		for(i=0;i<2;i++)
		{
			Rcv_Price[i] = 0.0;
			Pay_Price[i] = 0.0;
		}

		SumIndex = 0;
		for(i=0;i<NCurveIndex;i++)
		{
			for(j=0;j<NCurve[i];j++)
			{
				CurveRateInfo_Dn[SumIndex+j] = CurveRateInfo[SumIndex+j];
			}
			SumIndex += NCurve[i];
		}

		for(j=0;j<Rcv_NPrinCashFlow;j++)
		{
			Rcv_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Pay_NPrinCashFlow;j++)
		{
			Pay_PrinDiscFactor_Temp[j] =  0.0;
		}

		for(j=0;j<Rcv_NCpnCashFlow;j++)
		{
			Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
			Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
			Rcv_CpnDiscFactor_Temp[j] = 0.0;
		}

		for(j=0;j<Pay_NCpnCashFlow;j++)
		{
			Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
			Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
			Pay_CpnDiscFactor_Temp[j] = 0.0;
		}

		if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,		
										Rcv_Price,					InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
										Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
										Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
										Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
										Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
										Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
										Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
										Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
										Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
										RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
										Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
										Rcv_Price,					InterpolateFlag,			szModuleName,				szFileName					);
		}

		if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Pay_Price,					InterpolateFlag,			szModuleName,				szFileName					);
		}
		else
		{
			ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
										Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
										Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
										Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
										Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
										Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
										Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
										Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
										Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
										PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
										Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
										Pay_Price,					InterpolateFlag,			szModuleName,				szFileName					);
		}

		// Rcv Duration, Convexity
		ResultPrice[5] =  -(Price_Up[0] - Price_Dn[0])/(2*0.0001*Rcv_Price[0]); // Effective Duration
		ResultPrice[6] = (Price_Up[0] + Price_Dn[0] - 2 * Rcv_Price[0]) / (2 * 0.0001*0.0001 * Rcv_Price[0]); // Effective Convexity

        //Rcv ���ݻ� �෹�̼�, ������Ƽ
        ResultPrice[9] = -(Price_Up2[0] - Price_Dn2[0])/(2*0.0001*ResultPrice[1]);
        ResultPrice[10] = (Price_Up2[0] + Price_Dn2[0] - 2*ResultPrice[1]) / (2*0.0001*0.0001*ResultPrice[1]);
		
		// Pay Duration, Convexity
		ResultPrice[7] =  -(Price_Up[2] - Price_Dn[2])/(2*0.0001*Pay_Price[0]); // Effective Duration
		ResultPrice[8] = (Price_Up[2] + Price_Dn[2] - 2 * Pay_Price[0]) / (2 * 0.0001*0.0001 * Pay_Price[0]); // Effective Convexity

        //Pay ���ݻ� �෹�̼�, ������Ƽ
        ResultPrice[11] = -(Price_Up2[2] - Price_Dn2[2])/(2*0.0001*ResultPrice[2]);
        ResultPrice[12] = (Price_Up2[2] + Price_Dn2[2] - 2*ResultPrice[2]) / (2*0.0001*0.0001*ResultPrice[2]);
		// Duration, Convexity ��� �� ////////////////////////////////////////////////////////////////////////////////////////////////////////////

		// Key Rate Duration ///////////////////////////////////////////////////////////////////////////////////////////////////

		Rcv_DisCrvRate_Up = (double *)malloc(NCurve[Rcv_DisCrvIndex]*sizeof(double));
		Rcv_RefCrvRate_Up = (double *)malloc(NCurve[Rcv_RefCrvIndex]*sizeof(double));
		Pay_DisCrvRate_Up = (double *)malloc(NCurve[Pay_DisCrvIndex]*sizeof(double));
		Pay_RefCrvRate_Up = (double *)malloc(NCurve[Pay_RefCrvIndex]*sizeof(double));

		Rcv_DisCrvRate_Dn = (double *)malloc(NCurve[Rcv_DisCrvIndex]*sizeof(double));
		Rcv_RefCrvRate_Dn = (double *)malloc(NCurve[Rcv_RefCrvIndex]*sizeof(double));
		Pay_DisCrvRate_Dn = (double *)malloc(NCurve[Pay_DisCrvIndex]*sizeof(double));
		Pay_RefCrvRate_Dn = (double *)malloc(NCurve[Pay_RefCrvIndex]*sizeof(double));

		// Rcv Dis Key Rate Duration
		for(i=0;i<NCurve[Rcv_DisCrvIndex];i++)
		{
			for(j=0;j<NCurve[Rcv_DisCrvIndex];j++)
			{
				if(i==j)
				{
					Rcv_DisCrvRate_Up[j] = Rcv_DisCrvRate[j] + 0.0001;
					Rcv_DisCrvRate_Dn[j] = Rcv_DisCrvRate[j] - 0.0001;
				}
				else
				{
					Rcv_DisCrvRate_Up[j] = Rcv_DisCrvRate[j];
					Rcv_DisCrvRate_Dn[j] = Rcv_DisCrvRate[j];
				}
			}

			for(j=0;j<4;j++)
			{
				Price_Up[j] = 0.0;
				Price_Dn[j] = 0.0;
			}

			// Rcv Up
			for(j=0;j<Rcv_NPrinCashFlow;j++)
			{
				Rcv_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Rcv_NCpnCashFlow;j++)
			{
				Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
				Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
				Rcv_CpnDiscFactor_Temp[j] = 0.0;
			}
			
			if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate_Up,			NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate_Up,			NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Rcv Dn
			for(j=0;j<Rcv_NPrinCashFlow;j++)
			{
				Rcv_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Rcv_NCpnCashFlow;j++)
			{
				Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
				Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
				Rcv_CpnDiscFactor_Temp[j] = 0.0;
			}
			
			if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate_Dn,			NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate_Dn,			NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate,				NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,		
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Rcv Dis KeyRate Duration (Effective)
			KeyRateDuration[i] = -(Price_Up[0] - Price_Dn[0])/(2*0.0001*Rcv_Price[0]);

			// Rcv Dis KeyRate Convexity (Effective)
			KeyRateConvexity[i] = (Price_Up[0] + Price_Dn[0] - 2 * Rcv_Price[0]) / (2 * 0.0001*0.0001 * Rcv_Price[0]); 
		}

		// Rcv Ref Key Rate Duration
		for(i=0;i<NCurve[Rcv_RefCrvIndex];i++)
		{
			for(j=0;j<NCurve[Rcv_RefCrvIndex];j++)
			{
				if(i==j)
				{
					Rcv_RefCrvRate_Up[j] = Rcv_RefCrvRate[j] + 0.0001;
					Rcv_RefCrvRate_Dn[j] = Rcv_RefCrvRate[j] - 0.0001;
				}
				else
				{
					Rcv_RefCrvRate_Up[j] = Rcv_RefCrvRate[j];
					Rcv_RefCrvRate_Dn[j] = Rcv_RefCrvRate[j];
				}
			}

			for(j=0;j<4;j++)
			{
				Price_Up[j] = 0.0;
				Price_Dn[j] = 0.0;
			}

			// Rcv Up
			for(j=0;j<Rcv_NPrinCashFlow;j++)
			{
				Rcv_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Rcv_NCpnCashFlow;j++)
			{
				Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
				Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
				Rcv_CpnDiscFactor_Temp[j] = 0.0;
			}
			
			if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate_Up,			NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,		
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate_Up,			NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,		
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}


			// Rcv Dn
			for(j=0;j<Rcv_NPrinCashFlow;j++)
			{
				Rcv_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Rcv_NCpnCashFlow;j++)
			{
				Rcv_CpnRefRate_Temp[j] =  Rcv_CpnRefRate_Org[j];
				Rcv_CpnCashFlow_Temp[j] = Rcv_CpnCashFlow_Org[j];
				Rcv_CpnDiscFactor_Temp[j] = 0.0;
			}
			
			if(Rcv_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate_Dn,			NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_CpnNA+(Rcv_NCpnCashFlow-1),	Rcv_CpnSettleDate+(Rcv_NCpnCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,	
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Rcv_DisCrvTerm,				Rcv_DisCrvRate,				NCurve[Rcv_DisCrvIndex],		CrvDayCntType[Rcv_DisCrvIndex],
											Rcv_RefCrvTerm,				Rcv_RefCrvRate_Dn,			NCurve[Rcv_RefCrvIndex],	CrvDayCntType[Rcv_RefCrvIndex],	Rcv_RefRatePeriod,
											Rcv_SwapRateFixedPeriod,	Rcv_SwapRateFixedNumCpn,	Rcv_CpnPeriodType,			Rcv_PaiedTime,					Rcv_InArrearFlag,
											Rcv_CpnDayCountType,		Rcv_ConvexityAdjustFlag,	Rcv_TimingAdjustFlag,		Rcv_NCapVolTerm,				Rcv_CapVolTerm,
											Rcv_CapVol,					Rcv_TimingCorr,				Rcv_NSwaptionVolSwapMat,	Rcv_NSwaptionVolOptMat,			Rcv_SwaptionVolSwapMat,
											Rcv_SwaptionVolOptMat,		Rcv_SwaptionVol,			1,							Rcv_PrinCashFlow+(Rcv_NPrinCashFlow-1),	Rcv_PrinSettleDate+(Rcv_NPrinCashFlow-1),
											Rcv_PrinDiscFactor,			Rcv_NCpnCashFlow,			Rcv_ResetFixDate,			Rcv_DesignateResetFlag,			Rcv_ForwardStartDate,
											Rcv_ForwardEndDate,			Rcv_NFixDates,				Rcv_NFixedDates,			Rcv_CpnFromDate,				Rcv_CpnToDate,
											Rcv_CpnSettleDate,			Rcv_CpnNA,					Rcv_CpnSlope,				Rcv_CpnSpread,					SOFRUseFlag,
											RcvDailyRateLoggingFlag,	RcvSOFRConv,				Rcv_NHolidayFast,			Rcv_HolidayFast,				Rcv_NHistoryFast,
											Rcv_HistoryRateDate,		Rcv_HistoryRate,			Rcv_CpnRefRate,				Rcv_CpnCashFlow,				Rcv_CpnDiscFactor,			
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Rcv Ref KeyRate Duration (Effective)
			KeyRateDuration[NCurve[Rcv_DisCrvIndex]+i] = -(Price_Up[0] - Price_Dn[0])/(2*0.0001*Rcv_Price[0]);

			// Rcv Ref KeyRate Convexity (Effective)
			KeyRateConvexity[NCurve[Rcv_DisCrvIndex]+i] = (Price_Up[0] + Price_Dn[0] - 2 * Rcv_Price[0]) / (2 * 0.0001*0.0001 * Rcv_Price[0]); 
		}

		// Pay Dis Key Rate Duration
		for(i=0;i<NCurve[Pay_DisCrvIndex];i++)
		{
			for(j=0;j<NCurve[Pay_DisCrvIndex];j++)
			{
				if(i==j)
				{
					Pay_DisCrvRate_Up[j] = Pay_DisCrvRate[j] + 0.0001;
					Pay_DisCrvRate_Dn[j] = Pay_DisCrvRate[j] - 0.0001;
				}
				else
				{
					Pay_DisCrvRate_Up[j] = Pay_DisCrvRate[j];
					Pay_DisCrvRate_Dn[j] = Pay_DisCrvRate[j];
				}
			}

			for(j=0;j<4;j++)
			{
				Price_Up[j] = 0.0;
				Price_Dn[j] = 0.0;
			}

			// Pay Up
			for(j=0;j<Pay_NPrinCashFlow;j++)
			{
				Pay_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Pay_NCpnCashFlow;j++)
			{
				Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
				Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
				Pay_CpnDiscFactor_Temp[j] = 0.0;
			}

			if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate_Up,			NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate_Up,			NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Pay Dn
			for(j=0;j<Pay_NPrinCashFlow;j++)
			{
				Pay_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Pay_NCpnCashFlow;j++)
			{
				Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
				Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
				Pay_CpnDiscFactor_Temp[j] = 0.0;
			}

			if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate_Dn,			NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate_Dn,			NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate,				NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,		
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Pay Dis KeyRate Duration (Effective)
			KeyRateDuration[NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+i] = -(Price_Up[0] - Price_Dn[0])/(2*0.0001*Pay_Price[0]);

			// Pay Dis KeyRate Convexity (Effective)
			KeyRateConvexity[NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+i] = (Price_Up[0] + Price_Dn[0] - 2 * Pay_Price[0]) / (2 * 0.0001*0.0001 * Pay_Price[0]); 
		}

		// Pay Ref Key Rate Duration
		for(i=0;i<NCurve[Pay_RefCrvIndex];i++)
		{
			for(j=0;j<NCurve[Pay_RefCrvIndex];j++)
			{
				if(i==j)
				{
					Pay_RefCrvRate_Up[j] = Pay_RefCrvRate[j] + 0.0001;
					Pay_RefCrvRate_Dn[j] = Pay_RefCrvRate[j] - 0.0001;
				}
				else
				{
					Pay_RefCrvRate_Up[j] = Pay_RefCrvRate[j];
					Pay_RefCrvRate_Dn[j] = Pay_RefCrvRate[j];
				}
			}

			for(j=0;j<4;j++)
			{
				Price_Up[j] = 0.0;
				Price_Dn[j] = 0.0;
			}

			// Pay Up
			for(j=0;j<Pay_NPrinCashFlow;j++)
			{
				Pay_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Pay_NCpnCashFlow;j++)
			{
				Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
				Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
				Pay_CpnDiscFactor_Temp[j] = 0.0;
			}

			if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate_Up,			NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate_Up,			NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
											Price_Up,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Pay Dn
			for(j=0;j<Pay_NPrinCashFlow;j++)
			{
				Pay_PrinDiscFactor_Temp[j] =  0.0;
			}

			for(j=0;j<Pay_NCpnCashFlow;j++)
			{
				Pay_CpnRefRate_Temp[j] =  Pay_CpnRefRate_Org[j];
				Pay_CpnCashFlow_Temp[j] = Pay_CpnCashFlow_Org[j];
				Pay_CpnDiscFactor_Temp[j] = 0.0;
			}

			if(Pay_NCpnCashFlow != 1) // ���� ������ �����ϴ� ä���������� Duration���
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate_Dn,			NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_CpnNA+(Pay_NCpnCashFlow-1),	Pay_CpnSettleDate+(Pay_NCpnCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}
			else
			{
				ResultCode = IR_Leg_Value(	PriceDate,					Pay_DisCrvTerm,				Pay_DisCrvRate,				NCurve[Pay_DisCrvIndex],		CrvDayCntType[Pay_DisCrvIndex],
											Pay_RefCrvTerm,				Pay_RefCrvRate_Dn,			NCurve[Pay_RefCrvIndex],	CrvDayCntType[Pay_RefCrvIndex],	Pay_RefRatePeriod,
											Pay_SwapRateFixedPeriod,	Pay_SwapRateFixedNumCpn,	Pay_CpnPeriodType,			Pay_PaiedTime,					Pay_InArrearFlag,
											Pay_CpnDayCountType,		Pay_ConvexityAdjustFlag,	Pay_TimingAdjustFlag,		Pay_NCapVolTerm,				Pay_CapVolTerm,
											Pay_CapVol,					Pay_TimingCorr,				Pay_NSwaptionVolSwapMat,	Pay_NSwaptionVolOptMat,			Pay_SwaptionVolSwapMat,
											Pay_SwaptionVolOptMat,		Pay_SwaptionVol,			1,							Pay_PrinCashFlow+(Pay_NPrinCashFlow-1),	Pay_PrinSettleDate+(Pay_NPrinCashFlow-1),
											Pay_PrinDiscFactor,			Pay_NCpnCashFlow,			Pay_ResetFixDate,			Pay_DesignateResetFlag,			Pay_ForwardStartDate,
											Pay_ForwardEndDate,			Pay_NFixDates,				Pay_NFixedDates,			Pay_CpnFromDate,				Pay_CpnToDate,
											Pay_CpnSettleDate,			Pay_CpnNA,					Pay_CpnSlope,				Pay_CpnSpread,					SOFRUseFlag,
											PayDailyRateLoggingFlag,	PaySOFRConv,				Pay_NHolidayFast,			Pay_HolidayFast,				Pay_NHistoryFast,
											Pay_HistoryRateDate,		Pay_HistoryRate,			Pay_CpnRefRate,				Pay_CpnCashFlow,				Pay_CpnDiscFactor,			
											Price_Dn,					InterpolateFlag,			szModuleName,				szFileName					);
			}

			// Pay Ref KeyRate Duration (Effective)
			KeyRateDuration[NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+NCurve[Pay_DisCrvIndex]+i] = -(Price_Up[0] - Price_Dn[0])/(2*0.0001*Pay_Price[0]);

			// Pay Ref KeyRate Convexity (Effective)
			KeyRateConvexity[NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+NCurve[Pay_DisCrvIndex]+i] = (Price_Up[0] + Price_Dn[0] - 2 * Pay_Price[0]) / (2 * 0.0001*0.0001 * Pay_Price[0]); 
		}

		if(Rcv_DisCrvRate_Up) free(Rcv_DisCrvRate_Up);
		if(Rcv_RefCrvRate_Up) free(Rcv_RefCrvRate_Up);
		if(Pay_DisCrvRate_Up) free(Pay_DisCrvRate_Up);
		if(Pay_RefCrvRate_Up) free(Pay_RefCrvRate_Up);

		if(Rcv_DisCrvRate_Dn) free(Rcv_DisCrvRate_Dn);
		if(Rcv_RefCrvRate_Dn) free(Rcv_RefCrvRate_Dn);
		if(Pay_DisCrvRate_Dn) free(Pay_DisCrvRate_Dn);
		if(Pay_RefCrvRate_Dn) free(Pay_RefCrvRate_Dn);

		////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


		// FX Delta ////////////////////////////////////////////////////////////////////////////////////////////////////////////
		Price_Up[0] = 0.0;
		Price_Dn[0] = 0.0;
		for(i=0;i<NCrcyIndex;i++)
		{
			if(FXRateInfo[i] != 1.0) // FX Rate�� 1�� ���ð�� Base��ȭ�ν� Greek�� ������� ����
			{
				// Greek ����
				for(j=0;j<NCrcyIndex;j++)
				{
					if(i==j)
					{
						FXRateInfo_Up[j] = FXRateInfo[j]*(1+0.01);
						FXRateInfo_Dn[j] = FXRateInfo[j]*(1-0.01);
					}
					else
					{
						FXRateInfo_Up[j] = FXRateInfo[j];
						FXRateInfo_Dn[j] = FXRateInfo[j];
					}
				}

				// Up Price
				Rcv_CrcyRate = FXRateInfo_Up[Rcv_CrcyIndex];
				Pay_CrcyRate = FXRateInfo_Up[Pay_CrcyIndex];
				Calc_CrcyRate = FXRateInfo_Up[Calc_CrcyIndex];

				Price_Up[0] = ResultPrice[1]*(Calc_CrcyRate/Rcv_CrcyRate) - ResultPrice[2]*(Calc_CrcyRate/Pay_CrcyRate);

				// Dn Price
				Rcv_CrcyRate = FXRateInfo_Dn[Rcv_CrcyIndex];
				Pay_CrcyRate = FXRateInfo_Dn[Pay_CrcyIndex];
				Calc_CrcyRate = FXRateInfo_Dn[Calc_CrcyIndex];

				Price_Dn[0] = ResultPrice[1]*(Calc_CrcyRate/Rcv_CrcyRate) - ResultPrice[2]*(Calc_CrcyRate/Pay_CrcyRate);

				ResultPrice[13+i] = (Price_Up[0] - Price_Dn[0]) / ( 2 * 0.01 * FXRateInfo[i]) ;
			}
			else
			{
				ResultPrice[13+i] = 0.0;
			}
		}
		// FX Delta ��� �� /////////////////////////////////////////////////////////////////////////////////////////////////////////

		if(Rcv_PrinDiscFactor_Temp) free(Rcv_PrinDiscFactor_Temp);
		if(Rcv_CpnRefRate_Temp) free(Rcv_CpnRefRate_Temp);
		if(Rcv_CpnCashFlow_Temp) free(Rcv_CpnCashFlow_Temp);
		if(Rcv_CpnDiscFactor_Temp) free(Rcv_CpnDiscFactor_Temp);

		if(Pay_PrinDiscFactor_Temp) free(Pay_PrinDiscFactor_Temp);
		if(Pay_CpnRefRate_Temp) free(Pay_CpnRefRate_Temp);
		if(Pay_CpnCashFlow_Temp) free(Pay_CpnCashFlow_Temp);
		if(Pay_CpnDiscFactor_Temp) free(Pay_CpnDiscFactor_Temp);

		if(CurveRateInfo_Up) free(CurveRateInfo_Up);
		if(CurveRateInfo_Dn) free(CurveRateInfo_Dn);

		if(FXRateInfo_Up) free(FXRateInfo_Up);
		if(FXRateInfo_Dn) free(FXRateInfo_Dn);
	}

	if(TextFlag==1)
	{
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Rcv_PrinCashFlow", Leg_NPrinCashFlow[0], Leg_PrinCashFlow);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Rcv_PrinDiscFactor", Leg_NPrinCashFlow[0], Leg_PrinDiscFactor);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Rcv_CpnRefRate", Leg_NCpnCashFlow[0], Leg_CpnRefRate);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Rcv_CpnCouponFlow", Leg_NCpnCashFlow[0], Leg_CpnCashFlow);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Rcv_CpnDiscFactor", Leg_NCpnCashFlow[0], Leg_CpnDiscFactor);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Pay_PrinCashFlow", Leg_NPrinCashFlow[1], Leg_PrinCashFlow+Leg_NPrinCashFlow[0]);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Pay_PrinDiscFactor", Leg_NPrinCashFlow[1], Leg_PrinDiscFactor+Leg_NPrinCashFlow[0]);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Pay_CpnRefRate", Leg_NCpnCashFlow[1], Leg_CpnRefRate+Leg_NCpnCashFlow[0]);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Pay_CpnCouponFlow", Leg_NCpnCashFlow[1], Leg_CpnCashFlow+Leg_NCpnCashFlow[0]);
		LoggingDataArray(szModuleName, szFileName, "OUTPUT_Pay_CpnDiscFactor", Leg_NCpnCashFlow[1], Leg_CpnDiscFactor+Leg_NCpnCashFlow[0]);
		if(GreekFlag==1)
		{
			SumIndex = 0;
			for(i=0;i<NCurveIndex;i++) SumIndex += NCurve[i];

			LoggingDataArray(szModuleName, szFileName, "KeyRateDuration", NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+NCurve[Pay_DisCrvIndex]+NCurve[Pay_RefCrvIndex], KeyRateDuration);
			LoggingDataArray(szModuleName, szFileName, "KeyRateConvexity", NCurve[Rcv_DisCrvIndex]+NCurve[Rcv_RefCrvIndex]+NCurve[Pay_DisCrvIndex]+NCurve[Pay_RefCrvIndex], KeyRateConvexity);
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_PV01", SumIndex, PV01); // Basis Point Value
			//LoggingDataArray(szModuleName, szFileName, "OUTPUT_ResultPrice", 9+NCrcyIndex, ResultPrice);
            LoggingDataArray(szModuleName, szFileName, "OUTPUT_ResultPrice", 13+NCrcyIndex, ResultPrice);       //200519 BNK�������� �ƿ�ǲ 4�� �߰� ����
		}
		else
		{
			LoggingDataArray(szModuleName, szFileName, "OUTPUT_ResultPrice", 5, ResultPrice);
		}
	}

	if(Rcv_CpnRefRate_Org) free(Rcv_CpnRefRate_Org);
	if(Rcv_CpnCashFlow_Org) free(Rcv_CpnCashFlow_Org);
	if(Pay_CpnRefRate_Org) free(Pay_CpnRefRate_Org);
	if(Pay_CpnCashFlow_Org) free(Pay_CpnCashFlow_Org);
	if(Rcv_HolidayFast) free(Rcv_HolidayFast);
	if(Rcv_HistoryRateDate) free(Rcv_HistoryRateDate);
	if(Rcv_HistoryRate) free(Rcv_HistoryRate);
	if(Pay_HolidayFast) free(Pay_HolidayFast);
	if(Pay_HistoryRateDate) free(Pay_HistoryRateDate);
	if(Pay_HistoryRate) free(Pay_HistoryRate);

	return ResultCode;
}

void InputCheck_Pure_IRSwap(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	double *RcvDisCrvTerm,			// IN:  Rcv Discount Curve Term (������)
	double *RcvDisCrvRate,			// IN:  Rcv Discount Curve Rate (5%->0.05�Է�)
	long NRcvDisCrvTerm,			// IN:  Rcv Discount Curve Term ����
	long RcvDisCrvDayCountType,		// IN:  Rcv DIscount Curve Day Count Type
	double *PayDisCrvTerm,			// IN:  Pay Discount Curve Term (������)
	double *PayDisCrvRate,			// IN:  Pay Discount Curve Rate (5%->0.05�Է�)
	long NPayDisCrvTerm,			// IN:  Pay Discount Curve Term ����
	long PayDisCrvDayCountType,		// IN:  Pay DIscount Curve Day Count Type
	double RcvCrcy,					// IN:  Rcv-������ȭ ȯ��
	double PayCrcy,					// IN:  Pay-������ȭ ȯ��
	double CalcCrcy,				// IN:  �����ȭ-������ȭ ȯ��
	long RcvCpnDayCntType,			// IN:  Rcv Cpn Day Count Convention 
	long PayCpnDayCntType,			// IN:  Pay Cpn Day Count Convention 
	long Rcv_NPrinCashFlow,			// IN:  Rcv ������� ���� ��
	double *RcvPrinCashFlow,		// IN:  Rcv ���� ���� ���޾�
	long *RcvPrinSettleDate,		// IN:  Rcv ���� ���� ������ (YYYYMMDD)
	double *RcvPrinDiscFactor,		// OUT: Rcv ���� ���� Discount Factor
	long Pay_NPrinCashFlow,			// IN:  Pay ������� ���� ��
	double *PayPrinCashFlow,		// IN:  Pay ���� ���� ���޾�
	long *PayPrinSettleDate,		// IN:  Pay ���� ���� ������ (YYYYMMDD)
	double *PayPrinDiscFactor,		// OUT: Pay ���� ���� Discount Factor
	long Rcv_NCpnCashFlow,			// IN:	Rcv CashFlow ����
	long *Rcv_CpnFromDate,			// IN:  Rcv ����� (YYYYMMDD)
	long *Rcv_CpnToDate,			// IN:  Rcv �⸻�� (YYYYMMDD)
	long *Rcv_CpnSettleDate,		// IN:	Rcv ������ (YYYYMMDD)
	double *Rcv_CpnNA,				// IN:	Rcv Coupon ���ؿ���
	double *Rcv_CpnSlope,			// IN:	Rcv Coupon Slope
	double *Rcv_CpnSpread,			// IN:	Rcv Coupon Spread
	double *Rcv_RefRate,			// IN:	Rcv Ȯ��(����)�ݸ�
	double *Rcv_CpnCashFlow,		// IN/OUT:  Rcv ��������
	double *Rcv_DiscFactor,			// OUT: Rcv Discount Factor
	long Pay_NCpnCashFlow,			// IN:	Pay CashFlow ����
	long *Pay_CpnFromDate,			// IN:  Pay ����� (YYYYMMDD)
	long *Pay_CpnToDate,			// IN:  Pay �⸻�� (YYYYMMDD)
	long *Pay_CpnSettleDate,		// IN:  Pay ������ (YYYYMMDD)
	double *Pay_CpnNA,				// IN:  Pay Coupon ���ؿ���
	double *Pay_CpnSlope,			// IN:  Pay Coupon Slope
	double *Pay_CpnSpread,			// IN:  Pay Coupon Spread
	double *Pay_RefRate,			// IN:  Pay Ȯ��(����)�ݸ�
	double *Pay_CpnCashFlow,		// IN/OUT:  Pay ��������
	double *Pay_DiscFactor,			// OUT: Pay Discount Factor
	long TextFlag,					// IN:  Text Dump ��¿���
	char *szFileName,				// IN:  text logging file name
	char *szModuleName				// IN:  module name
)
{
	LoggingData(szModuleName, szFileName, "PriceDate", PriceDate);
	LoggingDataArray(szModuleName, szFileName, "RcvDisCrvTerm", NRcvDisCrvTerm, RcvDisCrvTerm);
	LoggingDataArray(szModuleName, szFileName, "RcvDisCrvRate", NRcvDisCrvTerm, RcvDisCrvRate);
	LoggingData(szModuleName, szFileName, "NRcvDisCrvTerm", NRcvDisCrvTerm);
	LoggingData(szModuleName, szFileName, "RcvDisCrvDayCountType", RcvDisCrvDayCountType);
	LoggingDataArray(szModuleName, szFileName, "PayDisCrvTerm", NPayDisCrvTerm, PayDisCrvTerm);
	LoggingDataArray(szModuleName, szFileName, "PayDisCrvRate", NPayDisCrvTerm, PayDisCrvRate);
	LoggingData(szModuleName, szFileName, "NPayDisCrvTerm", NPayDisCrvTerm);
	LoggingData(szModuleName, szFileName, "PayDisCrvDayCountType", PayDisCrvDayCountType);
	LoggingData(szModuleName, szFileName, "RcvCrcy", RcvCrcy);
	LoggingData(szModuleName, szFileName, "PayCrcy", PayCrcy);
	LoggingData(szModuleName, szFileName, "CalcCrcy", CalcCrcy);
	LoggingData(szModuleName, szFileName, "RcvCpnDayCntType", RcvCpnDayCntType);
	LoggingData(szModuleName, szFileName, "PayCpnDayCntType", PayCpnDayCntType);
	LoggingData(szModuleName, szFileName, "Rcv_NPrinCashFlow", Rcv_NPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "RcvPrinCashFlow", Pay_NPrinCashFlow, RcvPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "RcvPrinSettleDate", Pay_NPrinCashFlow, RcvPrinSettleDate);
	LoggingDataArray(szModuleName, szFileName, "RcvPrinDiscFactor", Pay_NPrinCashFlow, RcvPrinDiscFactor);
	LoggingData(szModuleName, szFileName, "Pay_NPrinCashFlow", Pay_NPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "PayPrinCashFlow", Rcv_NCpnCashFlow, PayPrinCashFlow);
	LoggingDataArray(szModuleName, szFileName, "PayPrinSettleDate", Rcv_NCpnCashFlow, PayPrinSettleDate);
	LoggingDataArray(szModuleName, szFileName, "PayPrinDiscFactor", Rcv_NCpnCashFlow, PayPrinDiscFactor);
	LoggingData(szModuleName, szFileName, "Rcv_NCpnCashFlow", Rcv_NCpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnFromDate", Rcv_NCpnCashFlow, Rcv_CpnFromDate);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnToDate", Rcv_NCpnCashFlow, Rcv_CpnToDate);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnSettleDate", Rcv_NCpnCashFlow, Rcv_CpnSettleDate);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnNA", Rcv_NCpnCashFlow, Rcv_CpnNA);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnSlope", Rcv_NCpnCashFlow, Rcv_CpnSlope);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnSpread", Rcv_NCpnCashFlow, Rcv_CpnSpread);
	LoggingDataArray(szModuleName, szFileName, "Rcv_RefRate", Rcv_NCpnCashFlow, Rcv_RefRate);
	LoggingDataArray(szModuleName, szFileName, "Rcv_CpnCashFlow", Rcv_NCpnCashFlow, Rcv_CpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Rcv_DiscFactor", Rcv_NCpnCashFlow, Rcv_DiscFactor);
	LoggingData(szModuleName, szFileName, "Pay_NCpnCashFlow", Pay_NCpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnFromDate", Pay_NCpnCashFlow, Pay_CpnFromDate);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnToDate", Pay_NCpnCashFlow, Pay_CpnToDate);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnSettleDate", Pay_NCpnCashFlow, Pay_CpnSettleDate);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnNA", Pay_NCpnCashFlow, Pay_CpnNA);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnSlope", Pay_NCpnCashFlow, Pay_CpnSlope);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnSpread", Pay_NCpnCashFlow, Pay_CpnSpread);
	LoggingDataArray(szModuleName, szFileName, "Pay_RefRate", Pay_NCpnCashFlow, Pay_RefRate);
	LoggingDataArray(szModuleName, szFileName, "Pay_CpnCashFlow", Pay_NCpnCashFlow, Pay_CpnCashFlow);
	LoggingDataArray(szModuleName, szFileName, "Pay_DiscFactor", Pay_NCpnCashFlow, Pay_DiscFactor);
	LoggingData(szModuleName, szFileName, "TextFlag", TextFlag);
}

long Exception_Pure_IRSwap(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	double *RcvDisCrvTerm,			// IN:  Rcv Discount Curve Term (������)
	double *RcvDisCrvRate,			// IN:  Rcv Discount Curve Rate (5%->0.05�Է�)
	long NRcvDisCrvTerm,			// IN:  Rcv Discount Curve Term ����
	long RcvDisCrvDayCountType,		// IN:  Rcv DIscount Curve Day Count Type
	double *PayDisCrvTerm,			// IN:  Pay Discount Curve Term (������)
	double *PayDisCrvRate,			// IN:  Pay Discount Curve Rate (5%->0.05�Է�)
	long NPayDisCrvTerm,			// IN:  Pay Discount Curve Term ����
	long PayDisCrvDayCountType,		// IN:  Pay DIscount Curve Day Count Type
	double RcvCrcy,					// IN:  Rcv-������ȭ ȯ��
	double PayCrcy,					// IN:  Pay-������ȭ ȯ��
	double CalcCrcy,				// IN:  �����ȭ-������ȭ ȯ��
	long RcvCpnDayCntType,			// IN:  Rcv Cpn Day Count Convention 
	long PayCpnDayCntType,			// IN:  Pay Cpn Day Count Convention 
	long Rcv_NPrinCashFlow,			// IN:  Rcv ������� ���� ��
	double *RcvPrinCashFlow,		// IN:  Rcv ���� ���� ���޾�
	long *RcvPrinSettleDate,		// IN:  Rcv ���� ���� ������ (YYYYMMDD)
	double *RcvPrinDiscFactor,		// OUT: Rcv ���� ���� Discount Factor
	long Pay_NPrinCashFlow,			// IN:  Pay ������� ���� ��
	double *PayPrinCashFlow,		// IN:  Pay ���� ���� ���޾�
	long *PayPrinSettleDate,		// IN:  Pay ���� ���� ������ (YYYYMMDD)
	double *PayPrinDiscFactor,		// OUT: Pay ���� ���� Discount Factor
	long Rcv_NCpnCashFlow,			// IN:	Rcv CashFlow ����
	long *Rcv_CpnFromDate,			// IN:  Rcv ����� (YYYYMMDD)
	long *Rcv_CpnToDate,			// IN:  Rcv �⸻�� (YYYYMMDD)
	long *Rcv_CpnSettleDate,		// IN:	Rcv ������ (YYYYMMDD)
	double *Rcv_CpnNA,				// IN:	Rcv Coupon ���ؿ���
	double *Rcv_CpnSlope,			// IN:	Rcv Coupon Slope
	double *Rcv_CpnSpread,			// IN:	Rcv Coupon Spread
	double *Rcv_RefRate,			// IN:	Rcv Ȯ��(����)�ݸ�
	double *Rcv_CpnCashFlow,		// IN/OUT:  Rcv ��������
	double *Rcv_DiscFactor,			// OUT: Rcv Discount Factor
	long Pay_NCpnCashFlow,			// IN:	Pay CashFlow ����
	long *Pay_CpnFromDate,			// IN:  Pay ����� (YYYYMMDD)
	long *Pay_CpnToDate,			// IN:  Pay �⸻�� (YYYYMMDD)
	long *Pay_CpnSettleDate,		// IN:  Pay ������ (YYYYMMDD)
	double *Pay_CpnNA,				// IN:  Pay Coupon ���ؿ���
	double *Pay_CpnSlope,			// IN:  Pay Coupon Slope
	double *Pay_CpnSpread,			// IN:  Pay Coupon Spread
	double *Pay_RefRate,			// IN:  Pay Ȯ��(����)�ݸ�
	double *Pay_CpnCashFlow,		// IN/OUT:  Pay ��������
	double *Pay_DiscFactor,			// OUT: Pay Discount Factor
	long TextFlag					// IN:  Text Dump ��¿���
)
{
	long i;

	// ���� ����
	if(PriceDate<19000101 || PriceDate>99991231) return PRICE_DATE_ERROR;

	// Rcv Discount Curve ���� ����
	if(NRcvDisCrvTerm<1) return RCV_LEG_DISCOUNT_RATE_COUNT_ERROR;

	// Pay Discount Curve ���� ����
	if(NPayDisCrvTerm<1) return PAY_LEG_DISCOUNT_RATE_COUNT_ERROR;

	// Rcv ���� �����帧 ���� ����
	if(Rcv_NPrinCashFlow<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR;

	// Pay ���� �����帧 ���� ����
	if(Pay_NPrinCashFlow<0) return PAY_LEG_PRINCIPAL_CASH_FLOW_COUNT_ERROR;

	// Rcv ���� �����帧 ���� ����
	if(Rcv_NCpnCashFlow<0) return RCV_LEG_COUPON_CASH_FLOW_COUNT_ERROR;

	// Pay ���� �����帧 ���� ����
	if(Pay_NCpnCashFlow<0) return PAY_LEG_COUPON_CASH_FLOW_COUNT_ERROR;

	// Rcv DIscount Term, Rate ����
	if(RcvDisCrvTerm[0]<0) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
	if(RcvDisCrvRate[0]<-1||RcvDisCrvRate[0]>1) return RCV_LEG_DISCOUNT_RATE_ERROR;
	for(i=1;i<NRcvDisCrvTerm;i++)
	{
		if(RcvDisCrvTerm[i]<0) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(RcvDisCrvTerm[i]<=RcvDisCrvTerm[i-1]) return RCV_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(RcvDisCrvRate[i]<-1 || RcvDisCrvRate[i]>1) return RCV_LEG_DISCOUNT_RATE_ERROR;
	}
	// Rcv Discount Curve Day Count Type ����
	if(RcvDisCrvDayCountType<1 || RcvDisCrvDayCountType>12) return RCV_LEG_DISCOUNT_DAYCOUNT_TYPE_ERROR;

	// Pay DIscount Term, Rate ����
	if(PayDisCrvTerm[0]<0) return PAY_LEG_DISCOUNT_RATE_TENOR_ERROR;
	if(PayDisCrvRate[0]<-1 || PayDisCrvRate[0]>1) return PAY_LEG_DISCOUNT_RATE_ERROR;
	for(i=1;i<NPayDisCrvTerm;i++)
	{
		if(PayDisCrvTerm[i]<0) return PAY_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(PayDisCrvTerm[i]<=PayDisCrvTerm[i-1]) return PAY_LEG_DISCOUNT_RATE_TENOR_ERROR;
		if(PayDisCrvRate[i]<-1 || PayDisCrvRate[i]>1) return PAY_LEG_DISCOUNT_RATE_ERROR;
	}
	// Pay Discount Curve Day Count Type ����
	if(PayDisCrvDayCountType<1 || PayDisCrvDayCountType>12) return PAY_LEG_DISCOUNT_DAYCOUNT_TYPE_ERROR;

	// Rcv ȯ�� ����
	if(RcvCrcy<=0) return RCV_CRCY_ERROR;

	// Pay ȯ�� ����
	if(PayCrcy<=0) return PAY_CRCY_ERROR;

	// �����ȭ ȯ�� ����
	if(CalcCrcy<=0) return PRICE_CRCY_ERROR;

	// Rcv Day Count Type ����
	if(RcvCpnDayCntType<1 || RcvCpnDayCntType>12) return RCV_LEG_COUPON_DAYCOUNT_TYPE_ERROR;
	
	// Pay Day Count Type ����
	if(PayCpnDayCntType<1 || PayCpnDayCntType>12) return PAY_LEG_COUPON_DAYCOUNT_TYPE_ERROR;

	for(i=0;i<Rcv_NPrinCashFlow;i++)
	{
		// Rcv ���� �����帧�� ����
		if(RcvPrinCashFlow[i]<0) return RCV_LEG_PRINCIPAL_CASH_FLOW_ERROR;

		// Rcv ���� ������ ����
		if(RcvPrinSettleDate[i]<19000101 || RcvPrinSettleDate[i]>99991231) return RCV_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;

		// Rcv ���� ������ �ʱ�ȭ ����
		if(RcvPrinDiscFactor[i] != 0) return RCV_LEG_PRINCIPAL_DISCOUNT_ERROR;
	}
		
	for(i=0;i<Pay_NPrinCashFlow;i++)
	{
		// Pay ���� �����帧�� ����
		if(PayPrinCashFlow[i]<0) return PAY_LEG_PRINCIPAL_CASH_FLOW_ERROR;

		// Pay ���� ������ ����
		if(PayPrinSettleDate[i]<19000101 || PayPrinSettleDate[i]>99991231) return PAY_LEG_PRINCIPAL_SETTLEMENT_DATE_ERROR;

		// Pay ���� ������ �ʱ�ȭ ����
		if(PayPrinDiscFactor[i] != 0) return PAY_LEG_PRINCIPAL_DISCOUNT_ERROR;
	}

	for(i=0;i<Rcv_NCpnCashFlow;i++)
	{
		if(Rcv_CpnCashFlow[i]==0)
		{
			// Rcv ����� ����
			if(Rcv_CpnFromDate[i] < 19000101 || Rcv_CpnFromDate[i] > 99991231) return RCV_LEG_COUPON_FORM_DATE_ERROR;

			// Rcv �⸻�� ����
			if(Rcv_CpnToDate[i] < 19000101 || Rcv_CpnToDate[i] > 99991231) return RCV_LEG_COUPON_FORM_DATE_ERROR;
			if(Rcv_CpnFromDate[i]>=Rcv_CpnToDate[i]) return RCV_LEG_COUPON_FORM_DATE_ERROR;

			// Rcv ���� ����� ����
			if(Rcv_CpnNA[i]<0) return RCV_LEG_COUPON_NOTIONAL_AMOUNT_ERROR;

			// Rcv Slope ����
			if(Rcv_CpnSlope[i]<0 || Rcv_CpnSlope[i]>9999) return RCV_LEG_COUPON_SLOPE_ERROR;

			// Rcv Spread ����
			if(Rcv_CpnSpread[i]<-1 || Rcv_CpnSpread[i]>1) return RCV_LEG_COUPON_SPREAD_ERROR;

			// Rcv Ȯ��/���� �ݸ� ����
			if(Rcv_RefRate[i]<=0) return RCV_LEG_COUPON_COUPON_RATE_ERROR;
		}
		// Rcv ������ ����
		if(Rcv_CpnSettleDate[i]<19000101 || Rcv_CpnSettleDate[i]>99991231) return RCV_LEG_COUPON_SETTLEMENT_DATE_ERROR;

		// Rcv ���� ������ �ʱ�ȭ ����
		if(Rcv_DiscFactor[i] != 0) return RCV_LEG_COUPON_DISCOUNT_FACTOR_ERROR;
	}

	for(i=0;i<Pay_NCpnCashFlow;i++)
	{
		if(Pay_CpnCashFlow[i]==0)
		{
			// Pay ����� ����
			if(Pay_CpnFromDate[i] < 19000101 || Pay_CpnFromDate[i] > 99991231) return PAY_LEG_COUPON_FORM_DATE_ERROR;

			// Pay �⸻�� ����
			if(Pay_CpnToDate[i] < 19000101 || Pay_CpnToDate[i] > 99991231) return PAY_LEG_COUPON_FORM_DATE_ERROR;
			if(Pay_CpnFromDate[i]>=Pay_CpnToDate[i]) return PAY_LEG_COUPON_FORM_DATE_ERROR;

			// Pay ���� ����� ����
			if(Pay_CpnNA[i]<0) return PAY_LEG_COUPON_NOTIONAL_AMOUNT_ERROR;

			// Pay Slope ����
			if(Pay_CpnSlope[i]<0 || Pay_CpnSlope[i]>9999) return PAY_LEG_COUPON_SLOPE_ERROR;

			// Pay Spread ����
			if(Pay_CpnSpread[i]<-1 || Pay_CpnSpread[i]>1) return PAY_LEG_COUPON_SPREAD_ERROR;

			// Pay Ȯ��/���� �ݸ� ����
			if(Pay_RefRate[i]<=0) return PAY_LEG_COUPON_COUPON_RATE_ERROR;
		}
		// Pay ������ ����
		if(Pay_CpnSettleDate[i]<19000101 || Pay_CpnSettleDate[i]>99991231) return PAY_LEG_COUPON_SETTLEMENT_DATE_ERROR;

		// Pay ���� ������ �ʱ�ȭ ����
		if(Pay_DiscFactor[i] != 0) return PAY_LEG_COUPON_DISCOUNT_FACTOR_ERROR;
	}

	// TextFlag ����
	if(TextFlag!=0 && TextFlag!=1) return TEXT_FLAG_ERROR;

	return CORRECT;
}

// ���� �����ϰ� ��� CashFlow/Coupon�� �Է¹޾Ƽ� �����Ͽ� ������ ����ϴ� �Լ�
DLLEXPORT (long) KISP_CalcPureIRSwap(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	double *RcvDisCrvTerm,			// IN:  Rcv Discount Curve Term (������)
	double *RcvDisCrvRate,			// IN:  Rcv Discount Curve Rate (5%->0.05�Է�)
	long NRcvDisCrvTerm,			// IN:  Rcv Discount Curve Term ����
	long RcvDisCrvDayCountType,		// IN:  Rcv DIscount Curve Day Count Type
	double *PayDisCrvTerm,			// IN:  Pay Discount Curve Term (������)
	double *PayDisCrvRate,			// IN:  Pay Discount Curve Rate (5%->0.05�Է�)
	long NPayDisCrvTerm,			// IN:  Pay Discount Curve Term ����
	long PayDisCrvDayCountType,		// IN:  Pay DIscount Curve Day Count Type
	double RcvCrcy,					// IN:  Rcv-������ȭ ȯ��
	double PayCrcy,					// IN:  Pay-������ȭ ȯ��
	double CalcCrcy,				// IN:  �����ȭ-������ȭ ȯ��
	long RcvCpnDayCntType,			// IN:  Rcv Cpn Day Count Convention 
	long PayCpnDayCntType,			// IN:  Pay Cpn Day Count Convention 
	long Rcv_NPrinCashFlow,			// IN:  Rcv ������� ���� ��
	double *RcvPrinCashFlow,		// IN:  Rcv ���� ���� ���޾�
	long *RcvPrinSettleDate,		// IN:  Rcv ���� ���� ������ (YYYYMMDD)
	double *RcvPrinDiscFactor,		// OUT: Rcv ���� ���� Discount Factor
	long Pay_NPrinCashFlow,			// IN:  Pay ������� ���� ��
	double *PayPrinCashFlow,		// IN:  Pay ���� ���� ���޾�
	long *PayPrinSettleDate,		// IN:  Pay ���� ���� ������ (YYYYMMDD)
	double *PayPrinDiscFactor,		// OUT: Pay ���� ���� Discount Factor
	long Rcv_NCpnCashFlow,			// IN:	Rcv CashFlow ����
	long *Rcv_CpnFromDate,			// IN:  Rcv ����� (YYYYMMDD)
	long *Rcv_CpnToDate,			// IN:  Rcv �⸻�� (YYYYMMDD)
	long *Rcv_CpnSettleDate,		// IN:	Rcv ������ (YYYYMMDD)
	double *Rcv_CpnNA,				// IN:	Rcv Coupon ���ؿ���
	double *Rcv_CpnSlope,			// IN:	Rcv Coupon Slope
	double *Rcv_CpnSpread,			// IN:	Rcv Coupon Spread
	double *Rcv_RefRate,			// IN:	Rcv Ȯ��(����)�ݸ�
	double *Rcv_CpnCashFlow,		// IN/OUT:  Rcv ��������
	double *Rcv_DiscFactor,			// OUT: Rcv Discount Factor
	long Pay_NCpnCashFlow,			// IN:	Pay CashFlow ����
	long *Pay_CpnFromDate,			// IN:  Pay ����� (YYYYMMDD)
	long *Pay_CpnToDate,			// IN:  Pay �⸻�� (YYYYMMDD)
	long *Pay_CpnSettleDate,		// IN:  Pay ������ (YYYYMMDD)
	double *Pay_CpnNA,				// IN:  Pay Coupon ���ؿ���
	double *Pay_CpnSlope,			// IN:  Pay Coupon Slope
	double *Pay_CpnSpread,			// IN:  Pay Coupon Spread
	double *Pay_RefRate,			// IN:  Pay Ȯ��(����)�ݸ�
	double *Pay_CpnCashFlow,		// IN/OUT:  Pay ��������
	double *Pay_DiscFactor,			// OUT: Pay Discount Factor
	long GreekFlag,					// IN:  Greek��¿��� (0 : �����, 1 : ���)
	long TextFlag,					// IN:  Text Dump ��¿���
	double *ResultPrice				// OUT: ����� ��� (����, Rcv����, Pay����)
)
{
	char szModuleName[] = "Pure_IRSwap";
	char szFileName[100];
	get_filename(szFileName, szModuleName);

	if(TextFlag == 1)
	{
		InputCheck_Pure_IRSwap(	PriceDate,			RcvDisCrvTerm,		RcvDisCrvRate,		NRcvDisCrvTerm,			RcvDisCrvDayCountType,
								PayDisCrvTerm,		PayDisCrvRate,		NPayDisCrvTerm,		PayDisCrvDayCountType,	RcvCrcy,
								PayCrcy,			CalcCrcy,			RcvCpnDayCntType,	PayCpnDayCntType,		Rcv_NPrinCashFlow,
								RcvPrinCashFlow,	RcvPrinSettleDate,	RcvPrinDiscFactor,	Pay_NPrinCashFlow,		PayPrinCashFlow,
								PayPrinSettleDate,	PayPrinDiscFactor,	Rcv_NCpnCashFlow,	Rcv_CpnFromDate,		Rcv_CpnToDate,
								Rcv_CpnSettleDate,	Rcv_CpnNA,			Rcv_CpnSlope,		Rcv_CpnSpread,			Rcv_RefRate,
								Rcv_CpnCashFlow,	Rcv_DiscFactor,		Pay_NCpnCashFlow,	Pay_CpnFromDate,		Pay_CpnToDate,
								Pay_CpnSettleDate,	Pay_CpnNA,			Pay_CpnSlope,		Pay_CpnSpread,			Pay_RefRate,
								Pay_CpnCashFlow,	Pay_DiscFactor,		TextFlag,			szFileName,				szModuleName
								);
	}

	long ResultCode = -1;

	ResultCode = Exception_Pure_IRSwap(	PriceDate,			RcvDisCrvTerm,		RcvDisCrvRate,		NRcvDisCrvTerm,			RcvDisCrvDayCountType,
										PayDisCrvTerm,		PayDisCrvRate,		NPayDisCrvTerm,		PayDisCrvDayCountType,	RcvCrcy,
										PayCrcy,			CalcCrcy,			RcvCpnDayCntType,	PayCpnDayCntType,		Rcv_NPrinCashFlow,
										RcvPrinCashFlow,	RcvPrinSettleDate,	RcvPrinDiscFactor,	Pay_NPrinCashFlow,		PayPrinCashFlow,
										PayPrinSettleDate,	PayPrinDiscFactor,	Rcv_NCpnCashFlow,	Rcv_CpnFromDate,		Rcv_CpnToDate,
										Rcv_CpnSettleDate,	Rcv_CpnNA,			Rcv_CpnSlope,		Rcv_CpnSpread,			Rcv_RefRate,
										Rcv_CpnCashFlow,	Rcv_DiscFactor,		Pay_NCpnCashFlow,	Pay_CpnFromDate,		Pay_CpnToDate,
										Pay_CpnSettleDate,	Pay_CpnNA,			Pay_CpnSlope,		Pay_CpnSpread,			Pay_RefRate,
										Pay_CpnCashFlow,	Pay_DiscFactor,		TextFlag			);

	if(ResultCode<0)
	{
		LoggingData(szModuleName, szFileName, "ErrorCode", ResultCode);
		return ResultCode;
	}

	long i;
	double Rcv_Value = 0.0;
	double Pay_Value = 0.0;

	for(i=0;i<3;i++) ResultPrice[i] = 0.0;
	
	// Rcv ��������
	for(i=0;i<Rcv_NCpnCashFlow;i++)
	{
		if(PriceDate<Rcv_CpnSettleDate[i])
		{
			Rcv_DiscFactor[i] = Calc_DiscountFactor(PriceDate, RcvDisCrvTerm, RcvDisCrvRate, NRcvDisCrvTerm, RcvDisCrvDayCountType, Rcv_CpnSettleDate[i]);
			if(Rcv_CpnCashFlow[i]==0)
			{
				Rcv_CpnCashFlow[i] = Rcv_CpnNA[i] * (Rcv_CpnSlope[i] * Rcv_RefRate[i] + Rcv_CpnSpread[i]) * DayCountFraction(Rcv_CpnFromDate[i], Rcv_CpnToDate[i], RcvCpnDayCntType);
			}
			Rcv_Value += Rcv_CpnCashFlow[i]*Rcv_DiscFactor[i];
		}
		else
		{
			Rcv_DiscFactor[i] = 1.0;
		}
	}

	// Pay ��������
	for(i=0;i<Pay_NCpnCashFlow;i++)
	{
		if(PriceDate<Pay_CpnSettleDate[i])
		{
			Pay_DiscFactor[i] = Calc_DiscountFactor(PriceDate, PayDisCrvTerm, PayDisCrvRate, NPayDisCrvTerm, PayDisCrvDayCountType, Pay_CpnSettleDate[i]);
			if(Pay_CpnCashFlow[i]==0)
			{
				Pay_CpnCashFlow[i] = Pay_CpnNA[i] * (Pay_CpnSlope[i] * Pay_RefRate[i] + Pay_CpnSpread[i]) * DayCountFraction(Pay_CpnFromDate[i], Pay_CpnToDate[i], PayCpnDayCntType);
			}
			Pay_Value += Pay_CpnCashFlow[i]*Pay_DiscFactor[i];
		}
		else
		{
			Pay_DiscFactor[i] = 1.0;
		}
	}

	// Rcv ��������
	for(i=0;i<Rcv_NPrinCashFlow;i++)
	{
		if(PriceDate<RcvPrinSettleDate[i])
		{
			RcvPrinDiscFactor[i] = Calc_DiscountFactor(PriceDate, RcvDisCrvTerm, RcvDisCrvRate, NRcvDisCrvTerm, RcvDisCrvDayCountType, RcvPrinSettleDate[i]);
			Rcv_Value += RcvPrinCashFlow[i]*RcvPrinDiscFactor[i];
		}
		else
		{
			RcvPrinDiscFactor[i] = 1.0;
		}
	}

	// Pay ��������
	for(i=0;i<Pay_NPrinCashFlow;i++)
	{
		if(PriceDate<PayPrinSettleDate[i])
		{
			PayPrinDiscFactor[i] = Calc_DiscountFactor(PriceDate, PayDisCrvTerm, PayDisCrvRate, NPayDisCrvTerm, PayDisCrvDayCountType, PayPrinSettleDate[i]);
			Pay_Value += PayPrinCashFlow[i]*PayPrinDiscFactor[i];
		}
		else
		{
			PayPrinDiscFactor[i] = 1.0;
		}
	}

	// ���ݰ��
	ResultPrice[0] = (Rcv_Value / RcvCrcy - Pay_Value / PayCrcy) * CalcCrcy;
	ResultPrice[1] = Rcv_Value;
	ResultPrice[2] = Pay_Value;

	if(TextFlag == 1)
	{
		LoggingDataArray(szModuleName, szFileName, "RcvPrinCashFlow", Rcv_NPrinCashFlow, RcvPrinCashFlow);
		LoggingDataArray(szModuleName, szFileName, "RcvPrinDiscFactor", Rcv_NPrinCashFlow, RcvPrinDiscFactor);
		LoggingDataArray(szModuleName, szFileName, "PayPrinCashFlow", Pay_NPrinCashFlow, PayPrinCashFlow);
		LoggingDataArray(szModuleName, szFileName, "PayPrinDiscFactor", Pay_NPrinCashFlow, PayPrinDiscFactor);
		LoggingDataArray(szModuleName, szFileName, "Rcv_CpnCashFlow", Rcv_NCpnCashFlow, Rcv_CpnCashFlow);
		LoggingDataArray(szModuleName, szFileName, "Rcv_DiscFactor", Rcv_NCpnCashFlow, Rcv_DiscFactor);
		LoggingDataArray(szModuleName, szFileName, "Pay_CpnCashFlow", Pay_NCpnCashFlow, Pay_CpnCashFlow);
		LoggingDataArray(szModuleName, szFileName, "Pay_DiscFactor", Pay_NCpnCashFlow, Pay_DiscFactor);
		LoggingDataArray(szModuleName, szFileName, "ResultPrice", 3, ResultPrice);
	}

	return ResultCode;
}

double Current_SOFR_SwapRate(
	long DayCountFlagFloat,					// Float DayCountFlag [3] Act/365 �׿� Act/360
	long DayCountFlagFixed,					// Fixed DayCountFlag [3] Act/365 �׿� Act/360
				
	double NotionalFloat,					// Float Notional
	double NotionalFixed,					// Fixed Notional

	long NCurveFloatRef,
	double *TermCurveFloatRef,
	double *RateCurveFloatRef,

	long NCurveFloatDisc,
	double *TermCurveFloatDisc,
	double *RateCurveFloatDisc,

	long NCurveFixedDisc,
	double *TermCurveFixedDisc,
	double *RateCurveFixedDisc,

	long NDate_Float,
	long* ForwardStartDate_CDate_Float,
	long* ForwardEndDate_CDate_Float,
	long* PayDate_CDate_Float,

	long NDate_Fixed,
	long* ForwardStartDate_CDate_Fixed,
	long* ForwardEndDate_CDate_Fixed,
	long* PayDate_CDate_Fixed,

	long SOFRUseFlag,
	long *SOFRConv,
	long NHoliday,
	long* Holiday,
	long InterpolateFlag,

	double CalcFX,
	double FloatFX,
	double FixedFX,
	long DailyRateLogging,
	char* szFileName,
	char* szModuleName
	)
{
	
	long i, j,k;
	long ForwardStartIdx, ForwardEndIdx;
	long ForwardStartExlDate, ForwardEndExlDate;

	long LockOutDays = SOFRConv[0];
	long LookBackDays = SOFRConv[1];
	long ObservShift = SOFRConv[2];
	long HolidayCalcFlag = SOFRConv[3];

	double SOFR_Swap_Spread = 0.0;
	double denominator_float = 365.0;
	double denominator_fixed = 365.0;

	if (DayCountFlagFloat != 3) denominator_float = 360.0;
	if (DayCountFlagFixed != 3) denominator_fixed = 360.0;
	
	//////////////////////////////
	// History Rate ��� ����	//
	//////////////////////////////	
	long nTempHist = 0;
	long TempHistDate[1] = {-100};
	double TempHistRate[1] = {0.0};

	double P_Pay;
	double T1 = 0.0;
	double P0 = 1.0, P1 = 1.0;
	double TPay;
	double FloatValue, FixValue;
	double dt_Fix;
	double SOFR_Compound;
	double Annual_OIS = 0.0;

	double FX = 1.0;
	double NA = 1.0;

	long nSatSunDay = 0;
	long* SatSunDay;

	double r;
	long* PayDays = (long*)malloc(sizeof(long) * NDate_Float);
	double* CubicCArrayFloatRef = (double*)malloc(sizeof(double) * NCurveFloatRef);
	double* CubicCArrayFloatDisc = (double*)malloc(sizeof(double) * NCurveFloatDisc);
	double* CubicCArrayFixedDisc = (double*)malloc(sizeof(double) * NCurveFixedDisc);
	long CaliResult = 0;

	if (InterpolateFlag == 1)
	{
		CaliResult = Calibration_CubicSpline_Params(NCurveFloatRef, TermCurveFloatRef,RateCurveFloatRef, CubicCArrayFloatRef);
		if (CaliResult < 0) InterpolateFlag = 0;
		CaliResult = Calibration_CubicSpline_Params(NCurveFloatDisc, TermCurveFloatDisc,RateCurveFloatDisc, CubicCArrayFloatDisc);
		if (CaliResult < 0) InterpolateFlag = 0;
		CaliResult = Calibration_CubicSpline_Params(NCurveFixedDisc, TermCurveFixedDisc,RateCurveFixedDisc, CubicCArrayFixedDisc);
		if (CaliResult < 0) InterpolateFlag = 0;
	}

	ForwardStartIdx = 0;
	FloatValue = 0.0;
	if (SOFRUseFlag == 0) 
	{
		P0 = 1.0;
	}
	for (i = 0 ; i < NDate_Float; i++)
	{
		ForwardStartIdx = ActDayCount(ForwardStartDate_CDate_Float[0], ForwardStartDate_CDate_Float[i]);
		ForwardEndIdx = ActDayCount(ForwardStartDate_CDate_Float[0],ForwardEndDate_CDate_Float[i]);
		ForwardStartExlDate = CdrD2ExcD(ForwardStartDate_CDate_Float[i]);
		ForwardEndExlDate = CdrD2ExcD(ForwardEndDate_CDate_Float[i]);

		nSatSunDay = 0;
		for (j = ForwardStartExlDate - 50; j < ForwardEndExlDate; j++)
		{
			if (isweekend(j) == 1) nSatSunDay +=1;
		}
		SatSunDay = (long*)malloc(sizeof(long) * max(1,nSatSunDay));

		k = 0;
		for (j = ForwardStartExlDate - 50; j < ForwardEndExlDate; j++)
		{
			if (isweekend(j) == 1)
			{
				SatSunDay[k] = ActDayCount(ForwardStartDate_CDate_Float[0], ExcD2CdrD(j));
				k += 1;
			}
		}

		if (SOFRUseFlag == 1)
		{
			SOFR_Compound = SOFR_ForwardRate_Compound(NCurveFloatRef, TermCurveFloatRef, RateCurveFloatRef, CubicCArrayFloatRef,ForwardStartIdx, ForwardEndIdx, ForwardStartExlDate,ForwardEndExlDate,
													LockOutDays, LookBackDays, ObservShift, HolidayCalcFlag, NHoliday , 
													Holiday, nSatSunDay, SatSunDay, 0, nTempHist, TempHistDate, TempHistRate, 
													denominator_float, Annual_OIS, DailyRateLogging, InterpolateFlag, 0,
													szModuleName,szFileName);

			PayDays[i] = ActDayCount(ForwardStartDate_CDate_Float[0], PayDate_CDate_Float[i]);
			TPay = ((double)PayDays[i])/denominator_float;
			if (InterpolateFlag == 0) r = Linear_Interpolation_1D(TermCurveFloatDisc, RateCurveFloatDisc, NCurveFloatDisc, TPay );
			else r = CubicInterpolation(NCurveFloatDisc, TermCurveFloatDisc, RateCurveFloatDisc, CubicCArrayFloatDisc, TPay);

			P_Pay = exp(-r * TPay);

			NA = NotionalFloat;
			FX = CalcFX/FloatFX ;
			FloatValue += FX* NA * SOFR_Compound * P_Pay;
		}
		else
		{
			PayDays[i] = ActDayCount(ForwardStartDate_CDate_Float[0], PayDate_CDate_Float[i]);
			TPay = ((double)PayDays[i])/denominator_float;
			if (InterpolateFlag == 0) r = Linear_Interpolation_1D(TermCurveFloatDisc, RateCurveFloatDisc, NCurveFloatDisc, TPay );
			else r = CubicInterpolation(NCurveFloatDisc, TermCurveFloatDisc, RateCurveFloatDisc, CubicCArrayFloatDisc, TPay);
			P_Pay = exp(-r * TPay);

			T1 = ((double)ForwardEndIdx)/denominator_float;
			if (InterpolateFlag == 0) r = Linear_Interpolation_1D(TermCurveFloatRef, RateCurveFloatRef, NCurveFloatRef, T1 );
			else r = CubicInterpolation(NCurveFloatRef, TermCurveFloatRef, RateCurveFloatRef, CubicCArrayFloatRef, T1);
			
			P1 = exp(-r * T1);

			NA = NotionalFloat;
			FX = CalcFX/FloatFX ;

			FloatValue += NA * FX * (P0 / P1 - 1.0) * P_Pay;
			P0 = P1;
		}

		free(SatSunDay);
	}

	FixValue = 0.0;
	for (i = 0 ; i < NDate_Fixed; i++)
	{
		dt_Fix = ((double)ActDayCount(ForwardStartDate_CDate_Fixed[i],ForwardEndDate_CDate_Fixed[i]))/denominator_fixed;
		TPay = ((double)ActDayCount(ForwardStartDate_CDate_Fixed[0],PayDate_CDate_Fixed[i]))/denominator_fixed;

		if (InterpolateFlag == 0) r = Linear_Interpolation_1D(TermCurveFixedDisc, RateCurveFixedDisc, NCurveFixedDisc, TPay );
		else r = CubicInterpolation(NCurveFixedDisc, TermCurveFixedDisc, RateCurveFixedDisc, CubicCArrayFixedDisc, TPay);
		P_Pay = exp(-r * TPay);

		NA = NotionalFixed;
		FX = CalcFX/FixedFX ;
		FixValue += NA*FX * P_Pay * dt_Fix;
	}

	SOFR_Swap_Spread = FloatValue / FixValue;

	free(PayDays);
	free(CubicCArrayFloatRef);
	free(CubicCArrayFloatDisc);
	free(CubicCArrayFixedDisc);

	return SOFR_Swap_Spread;
}

void InputCheck_KISP_CalcCurrentSOFRSwap (
	long PriceDate,						// IN: ���ݰ����
	long Rcv_CpnType,					// IN: Receive Coupon Type 1:���� 2:����
	long Rcv_DayCountConv,				// IN: Rcv DayCountConv 3: Act/365 �׿� Act/360
	long Rcv_Ncf,						// IN: Receive Coupon ����
	long* Rcv_ForwardStartDate_Ctype,	// IN: Receive Forward StartDate

	long* Rcv_ForwardEndDate_Ctype,		// IN: Receive Forward EndDate
	long* Rcv_PayDate_Ctype,			// IN: Receive PayDate
	long Rcv_NAFlag,					// IN: Receive NA ����
	double Rcv_Notional,				// IN: Receive Notional Amount
	long Pay_CpnType,					// IN: Payment Coupon Type 1:���� 2:����

	long Pay_DayCountConv,				// IN: Pay DayCountConv 3: Act/365 �׿� Act/360
	long Pay_Ncf,						// IN: Payment Coupon ����
	long* Pay_ForwardStartDate_Ctype,	// IN: Payment Forward StartDate
	long* Pay_ForwardEndDate_Ctype,		// IN: Payment Forward EndDate
	long* Pay_PayDate_Ctype,			// IN: Payment PayDate

	long Pay_NAFlag,					// IN: Payment NA ����
	double Pay_Notional,				// IN: Payment Notional Amount
	long NCurveIndex,					// IN:  �Է� Curve ����
	long *NCurve,						// IN:  Curve �� (�Է� ������� Index������)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,				// IN:  Curve ����

	double *CurveRateInfo,				// IN:  Curve Rate ( 0.01(1%)������ �Է�) 
	long NCrcyIndex,					// IN:  �Է� ��ȭ ����
	double *FXRateInfo,					// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,					// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,				// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )

	long* SOFRFlags,					// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag [3] RateInterpolation Flag
	long* SOFRConv,						// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,					// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����	
	long* Holiday,						// IN: Holiday Rcv,Pay
	long TextFlag,
	char* szFileName,
	char* szModuleName
	)
{
	long i;
	long Sum_NCurve = 0;
	for(i=0;i<NCurveIndex;i++) Sum_NCurve += NCurve[i];
	LoggingData(szModuleName, szFileName, "PriceDate", PriceDate);
	LoggingData(szModuleName, szFileName, "Rcv_CpnType", Rcv_CpnType);
	LoggingData(szModuleName, szFileName, "Rcv_DayCountConv",Rcv_DayCountConv);
	LoggingData(szModuleName, szFileName, "Rcv_Ncf",Rcv_Ncf);

	LoggingDataArray(szModuleName, szFileName, "Rcv_ForwardStartDate_Ctype", Rcv_Ncf, Rcv_ForwardStartDate_Ctype);
	LoggingDataArray(szModuleName, szFileName, "Rcv_ForwardEndDate_Ctype", Rcv_Ncf, Rcv_ForwardEndDate_Ctype);
	LoggingDataArray(szModuleName, szFileName, "Rcv_PayDate_Ctype", Rcv_Ncf, Rcv_PayDate_Ctype);
	LoggingData(szModuleName, szFileName, "Rcv_NAFlag",Rcv_NAFlag);
	LoggingData(szModuleName, szFileName, "Rcv_Notional",Rcv_Notional);

	LoggingData(szModuleName, szFileName, "Pay_CpnType", Pay_CpnType);
	LoggingData(szModuleName, szFileName, "Pay_DayCountConv",Pay_DayCountConv);
	LoggingData(szModuleName, szFileName, "Pay_Ncf",Pay_Ncf);

	LoggingDataArray(szModuleName, szFileName, "Pay_ForwardStartDate_Ctype", Pay_Ncf, Pay_ForwardStartDate_Ctype);
	LoggingDataArray(szModuleName, szFileName, "Pay_ForwardEndDate_Ctype", Pay_Ncf, Pay_ForwardEndDate_Ctype);
	LoggingDataArray(szModuleName, szFileName, "Pay_PayDate_Ctype", Pay_Ncf, Pay_PayDate_Ctype);
	LoggingData(szModuleName, szFileName, "Pay_NAFlag",Pay_NAFlag);
	LoggingData(szModuleName, szFileName, "Pay_Notional",Pay_Notional);

	LoggingData(szModuleName, szFileName, "NCurveIndex",NCurveIndex);
	LoggingDataArray(szModuleName, szFileName, "NCurve", NCurveIndex, NCurve);
	LoggingDataArray(szModuleName, szFileName, "CurveTermInfo", Sum_NCurve, CurveTermInfo);
	LoggingDataArray(szModuleName, szFileName, "CurveRateInfo", Sum_NCurve, CurveRateInfo);

	LoggingData(szModuleName, szFileName, "NCrcyIndex",NCrcyIndex);
	LoggingDataArray(szModuleName, szFileName, "FXRateInfo", NCrcyIndex, FXRateInfo);
	LoggingDataArray(szModuleName, szFileName, "Leg_CrvIndex", 4, Leg_CrvIndex);
	LoggingDataArray(szModuleName, szFileName, "Leg_CrcyIndex", 3, Leg_CrcyIndex);

	LoggingDataArray(szModuleName, szFileName, "SOFRFlags", 4, SOFRFlags);
	LoggingDataArray(szModuleName, szFileName, "SOFRConv", 8, SOFRConv);
	LoggingDataArray(szModuleName, szFileName, "HolidayCount", 2, HolidayCount);
	LoggingDataArray(szModuleName, szFileName, "Holiday", HolidayCount[0] + HolidayCount[1], Holiday);
	LoggingData(szModuleName, szFileName, "TextFlag", TextFlag);	
	
}

long Exception_CalcCurrentSOFRSwap(
	long PriceDate,						// IN: ���ݰ����
	long Rcv_CpnType,					// IN: Receive Coupon Type 1:���� 2:����
	long Rcv_DayCountConv,				// IN: Rcv DayCountConv 3: Act/365 �׿� Act/360
	long Rcv_Ncf,						// IN: Receive Coupon ����
	long* Rcv_ForwardStartDate_Ctype,	// IN: Receive Forward StartDate

	long* Rcv_ForwardEndDate_Ctype,		// IN: Receive Forward EndDate
	long* Rcv_PayDate_Ctype,			// IN: Receive PayDate
	long Rcv_NAFlag,					// IN: Receive NA ����
	double Rcv_Notional,				// IN: Receive Notional Amount
	long Pay_CpnType,					// IN: Payment Coupon Type 1:���� 2:����

	long Pay_DayCountConv,				// IN: Pay DayCountConv 3: Act/365 �׿� Act/360
	long Pay_Ncf,						// IN: Payment Coupon ����
	long* Pay_ForwardStartDate_Ctype,	// IN: Payment Forward StartDate
	long* Pay_ForwardEndDate_Ctype,		// IN: Payment Forward EndDate
	long* Pay_PayDate_Ctype,			// IN: Payment PayDate

	long Pay_NAFlag,					// IN: Payment NA ����
	double Pay_Notional,				// IN: Payment Notional Amount
	long NCurveIndex,					// IN:  �Է� Curve ����
	long *NCurve,						// IN:  Curve �� (�Է� ������� Index������)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,				// IN:  Curve ����

	double *CurveRateInfo,				// IN:  Curve Rate ( 0.01(1%)������ �Է�) 
	long NCrcyIndex,					// IN:  �Է� ��ȭ ����
	double *FXRateInfo,					// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,					// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,				// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )

	long* SOFRFlags,					// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag [3] RateInterpolation Flag
	long* SOFRConv,						// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,					// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����	
	long* Holiday,						// IN: Holiday Rcv,Pay
	long TextFlag
	)
{
	long i, j;
	long Sum_Term;
	long SOFRUseFlag = SOFRFlags[0];
	long LockOutRef = SOFRConv[0];
	long LookBackRef = SOFRConv[1];
	long ObservShiftRef = SOFRConv[2];
	long HolidayFlagRef = SOFRConv[3];

	if(TextFlag != 0 && TextFlag != 1) return TEXT_FLAG_ERROR;
	if (SOFRFlags[0] < 0 || SOFRFlags[0] > 1) return SOFRUSEERROR;
	if (SOFRFlags[1] < 0 || SOFRFlags[1] > 1) return SOFRLOGGINGERROR; 
	if (SOFRFlags[2] < 0 || SOFRFlags[2] > 1) return SOFRLOGGINGERROR;
	if (SOFRFlags[3] < 0 || SOFRFlags[3] > 1) return SOFRINTERPOLERROR;

	if (SOFRFlags[0] == 1 || SOFRFlags[0] == 2)
	{
		if (SOFRConv[0] < 0 || SOFRConv[0] > 40 || SOFRConv[4] < 0 || SOFRConv[4] > 40) return LOCKOUTERROR; 
		if (SOFRConv[1] < 0 || SOFRConv[1] > 40 || SOFRConv[5] < 0 || SOFRConv[5] > 40) return LOOKBACKERROR;
		if (SOFRConv[2] < 0 || SOFRConv[2] > 1 || SOFRConv[6] < 0 || SOFRConv[6] > 1) return OBSERVSHIFTERROR;
		if (SOFRConv[3] < 0 || SOFRConv[3] > 3 || SOFRConv[7] < 0 || SOFRConv[7] > 3) return HOLICALCFLAGERROR;

		for (i = 1 ; i < HolidayCount[0]; i++)
		{
			if (Holiday[i] < 0) return HOLIDAY_ERROR;
			if (Holiday[i] < Holiday[i-1]) return HOLIDAY_SORTINGERROR;
		}
		for (i = HolidayCount[0]+1; i < HolidayCount[0] + HolidayCount[1]; i++)
		{
			if (Holiday[i] < 0) return HOLIDAY_ERROR;
			if (Holiday[i] < Holiday[i-1]) return HOLIDAY_SORTINGERROR;
		}

	}
	// Price Date ����
	if(PriceDate<19000101 || PriceDate>99991231) return PRICE_DATE_ERROR;

	// �Է� Curve ���� ����
	if(NCurveIndex<1) return NUM_CURVE_INDEX_ERROR;

	if (Rcv_CpnType != 1 && Rcv_CpnType != 2) return RCV_LEG_COUPON_PERIOD_TYPE_ERROR;
	if (Pay_CpnType != 1 && Pay_CpnType != 2) return PAY_LEG_COUPON_PERIOD_TYPE_ERROR;


	Sum_Term = 0;
	for(i=0;i<NCurveIndex;i++)
	{
		// �Է� Curve Term ���� ����
		if(NCurve[i]<1) return NUM_CURVE_ERROR;

		// �Է� Curve Term, Rate ����
		if(CurveTermInfo[Sum_Term]<0) return CURVE_TERM_ERROR;
		if(CurveRateInfo[Sum_Term]<-1 || CurveRateInfo[Sum_Term]>1) return CURVE_RATE_ERROR;
		for(j=1;j<NCurve[i];j++)
		{
			if(CurveTermInfo[Sum_Term+j]<0) return CURVE_TERM_ERROR;
			if(CurveTermInfo[Sum_Term+j]<=CurveTermInfo[Sum_Term+j-1]) return CURVE_TERM_ERROR;
			if(CurveRateInfo[Sum_Term+j]<-1 || CurveRateInfo[Sum_Term+j]>1) return CURVE_RATE_ERROR;
		}

		Sum_Term += NCurve[i];		
	}

	// �Է� ȯ�� ���� ����
	if(NCrcyIndex<1) return NUM_CRCY_ERROR;
	
	for(i=0;i<NCrcyIndex;i++)
	{
		// ȯ�� ����
		if(FXRateInfo[i]<=0) return CRCY_RATE_ERROR;
	}

	// Leg�� Curve Index ����
	if(Leg_CrvIndex[0]<0 || Leg_CrvIndex[0]>=NCurveIndex) return RCV_DISCOUNT_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[1]<0 || Leg_CrvIndex[1]>=NCurveIndex) return RCV_REF_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[2]<0 || Leg_CrvIndex[2]>=NCurveIndex) return PAY_DISCOUNT_CURVE_INDEX_ERROR;
	if(Leg_CrvIndex[3]<0 || Leg_CrvIndex[3]>=NCurveIndex) return PAY_REF_CURVE_INDEX_ERROR;

	// Leg�� Crcy Index ����
	if(Leg_CrcyIndex[0]<0 || Leg_CrcyIndex[0]>=NCrcyIndex) return RCV_CRCY_ERROR;
	if(Leg_CrcyIndex[1]<0 || Leg_CrcyIndex[1]>=NCrcyIndex) return PAY_CRCY_ERROR;
	if(Leg_CrcyIndex[2]<0 || Leg_CrcyIndex[2]>=NCrcyIndex) return PRICE_CRCY_ERROR;

	// CF����
	for (i = 0 ; i < Rcv_Ncf; i++)
	{
		if (Rcv_ForwardStartDate_Ctype[i] < 19000101 || Rcv_ForwardStartDate_Ctype[i] > 99991231) return RCV_LEG_FORWARD_START_DATE_ERROR;
		if (Rcv_ForwardEndDate_Ctype[i] < 19000101 || Rcv_ForwardEndDate_Ctype[i] > 99991231) return RCV_LEG_FORWARD_END_DATE_ERROR;
		if (Rcv_PayDate_Ctype[i] < 19000101 || Rcv_PayDate_Ctype[i] > 99991231) return RCV_LEG_FORWARD_END_DATE_ERROR;

		if (Rcv_ForwardStartDate_Ctype[i] > Rcv_ForwardEndDate_Ctype[i]) return RCV_LEG_FORWARD_START_DATE_ERROR;
	}

	for (i = 0 ; i < Pay_Ncf; i++)
	{
		if (Pay_ForwardStartDate_Ctype[i] < 19000101 || Pay_ForwardStartDate_Ctype[i] > 99991231) return PAY_LEG_FORWARD_START_DATE_ERROR;
		if (Pay_ForwardEndDate_Ctype[i] < 19000101 || Pay_ForwardEndDate_Ctype[i] > 99991231) return PAY_LEG_FORWARD_END_DATE_ERROR;
		if (Pay_PayDate_Ctype[i] < 19000101 || Pay_PayDate_Ctype[i] > 99991231) return PAY_LEG_FORWARD_END_DATE_ERROR;

		if (Pay_ForwardStartDate_Ctype[i] > Pay_ForwardEndDate_Ctype[i]) return PAY_LEG_FORWARD_START_DATE_ERROR;
	}
	return 1;
}

DLLEXPORT (long) KISP_CalcCurrentSOFRSwap (
	long PriceDate,						// IN: ���ݰ����
	long Rcv_CpnType,					// IN: Receive Coupon Type 1:���� 2:����
	long Rcv_DayCountConv,				// IN: Rcv DayCountConv 3: Act/365 �׿� Act/360
	long Rcv_Ncf,						// IN: Receive Coupon ����
	long* Rcv_ForwardStartDate_Ctype,	// IN: Receive Forward StartDate

	long* Rcv_ForwardEndDate_Ctype,		// IN: Receive Forward EndDate
	long* Rcv_PayDate_Ctype,			// IN: Receive PayDate
	long Rcv_NAFlag,					// IN: Receive NA ����
	double Rcv_Notional,				// IN: Receive Notional Amount
	long Pay_CpnType,					// IN: Payment Coupon Type 1:���� 2:����

	long Pay_DayCountConv,				// IN: Pay DayCountConv 3: Act/365 �׿� Act/360
	long Pay_Ncf,						// IN: Payment Coupon ����
	long* Pay_ForwardStartDate_Ctype,	// IN: Payment Forward StartDate
	long* Pay_ForwardEndDate_Ctype,		// IN: Payment Forward EndDate
	long* Pay_PayDate_Ctype,			// IN: Payment PayDate

	long Pay_NAFlag,					// IN: Payment NA ����
	double Pay_Notional,				// IN: Payment Notional Amount
	long NCurveIndex,					// IN:  �Է� Curve ����
	long *NCurve,						// IN:  Curve �� (�Է� ������� Index������)  ( ũ�� : NCurveIndex )
	double *CurveTermInfo,				// IN:  Curve ����

	double *CurveRateInfo,				// IN:  Curve Rate ( 0.01(1%)������ �Է�) 
	long NCrcyIndex,					// IN:  �Է� ��ȭ ����
	double *FXRateInfo,					// IN:  ȯ�� (USD���� �Ǵ� �����ȭ ����)
	long *Leg_CrvIndex,					// IN:  Leg �� Curve Index ( [0] : Rcv Discount Curve Index, [1] : Rcv Reference Curve Index, [2] : Pay Discount Curve Index, [3] : Pay Discount Curve Index )
	long *Leg_CrcyIndex,				// IN:  Leg �� ��ȭ Index ( [0] : Rcv, [1] : Pay, [2] : �����ȭ )

	long* SOFRFlags,					// IN: [0] SOFR��뿩��, [1] Receive RefRate Logging Flag, [2] Pay RefRate Logging Flag [3] RateInterpolation Flag
	long* SOFRConv,						// IN: [0] LockOutRef, [1]LookBackRef, [2]Observ Shift Ref, [3]HolidayFlag Ref, [4]LockOutRef, [5]LookBackRef, [6]Observ Shift Ref, [7]HolidayFlag Ref, 
	long* HolidayCount,					// IN: [0] Rcv Holiday ���� [1] Pay Holiday ����	
	long* Holiday,						// IN: Holiday Rcv,Pay
	long TextFlag,

	double* ResultPrice
	)
{
	long i;
	long j;
	long k;
	long NCurveSum = 0;
	long ResultCode = 1;

	char szModuleName[] = "KISP_CalcCurrentSOFRSwap";
	char szFileName[100];
	get_filename(szFileName, szModuleName);
	
	if(TextFlag == 1)
	{
		InputCheck_KISP_CalcCurrentSOFRSwap (
			 PriceDate,Rcv_CpnType,Rcv_DayCountConv,Rcv_Ncf,Rcv_ForwardStartDate_Ctype,
			 Rcv_ForwardEndDate_Ctype,Rcv_PayDate_Ctype,Rcv_NAFlag,Rcv_Notional,Pay_CpnType,
			 Pay_DayCountConv,Pay_Ncf,Pay_ForwardStartDate_Ctype,Pay_ForwardEndDate_Ctype,Pay_PayDate_Ctype,
			 Pay_NAFlag,Pay_Notional,NCurveIndex,NCurve,CurveTermInfo,			
			 CurveRateInfo,	NCrcyIndex,		FXRateInfo,			Leg_CrvIndex,				Leg_CrcyIndex,			
			 SOFRFlags,	SOFRConv,			HolidayCount,			Holiday,				TextFlag,
			 szFileName,szModuleName);
	}

	if( (Rcv_CpnType == 1 && Pay_CpnType == 2) || (Rcv_CpnType == 2 && Pay_CpnType == 1)) ResultCode = 1;
	else ResultCode = RCV_LEG_COUPON_PERIOD_TYPE_ERROR;

	ResultCode = Exception_CalcCurrentSOFRSwap(
		PriceDate,Rcv_CpnType,Rcv_DayCountConv,Rcv_Ncf,Rcv_ForwardStartDate_Ctype,
			 Rcv_ForwardEndDate_Ctype,Rcv_PayDate_Ctype,Rcv_NAFlag,Rcv_Notional,Pay_CpnType,
			 Pay_DayCountConv,Pay_Ncf,Pay_ForwardStartDate_Ctype,Pay_ForwardEndDate_Ctype,Pay_PayDate_Ctype,
			 Pay_NAFlag,Pay_Notional,NCurveIndex,NCurve,CurveTermInfo,			
			 CurveRateInfo,	NCrcyIndex,		FXRateInfo,			Leg_CrvIndex,				Leg_CrcyIndex,			
			 SOFRFlags,	SOFRConv,			HolidayCount,			Holiday,				TextFlag);



	if (ResultCode < 0) return ResultCode;

	double* Rcv_DisCrvTerm;
	double* Rcv_DisCrvRate;
	double* Rcv_RefCrvTerm;
	double* Rcv_RefCrvRate;
	double* Pay_DisCrvTerm;
	double* Pay_DisCrvRate;
	double* Pay_RefCrvTerm;
	double* Pay_RefCrvRate;
	
		// ��������
	long Rcv_DisCrvIndex = Leg_CrvIndex[0];
	long Rcv_RefCrvIndex = Leg_CrvIndex[1];
	long Pay_DisCrvIndex = Leg_CrvIndex[2];
	long Pay_RefCrvIndex = Leg_CrvIndex[3];

	long Rcv_CrcyIndex = Leg_CrcyIndex[0];
	long Pay_CrcyIndex = Leg_CrcyIndex[1];
	long Calc_CrcyIndex = Leg_CrcyIndex[2];

	long NRcv_DisCrvTerm = NCurve[Rcv_DisCrvIndex];
	long NRcv_RefCrvTerm = NCurve[Rcv_RefCrvIndex];
	long NPay_DisCrvTerm = NCurve[Pay_DisCrvIndex];
	long NPay_RefCrvTerm = NCurve[Pay_RefCrvIndex];

	double Rcv_CrcyRate = FXRateInfo[Rcv_CrcyIndex];
	double Pay_CrcyRate = FXRateInfo[Pay_CrcyIndex];
	double Calc_CrcyRate = FXRateInfo[Calc_CrcyIndex];

	// �� Curve ���� /////////////////////////////////////////////
	for(i=0;i<4;i++)
	{
		if(i==0)
			k = Rcv_DisCrvIndex;
		else if(i==1)
			k = Rcv_RefCrvIndex;
		else if(i==2)
			k = Pay_DisCrvIndex;
		else
			k = Pay_RefCrvIndex;

		NCurveSum = 0;
		for(j=0;j<k;j++) 
		{
			NCurveSum += NCurve[j];
		}

		if(i==0) // Rcv Discount Curve
		{
			Rcv_DisCrvTerm = CurveTermInfo+NCurveSum;
			Rcv_DisCrvRate = CurveRateInfo+NCurveSum;
		}
		else if(i==1) // Rcv Reference Curve
		{
			Rcv_RefCrvTerm = CurveTermInfo+NCurveSum;
			Rcv_RefCrvRate = CurveRateInfo+NCurveSum;
		}
		else if(i==2) // Pay Discount Curve
		{
			Pay_DisCrvTerm = CurveTermInfo+NCurveSum;
			Pay_DisCrvRate = CurveRateInfo+NCurveSum;
		}
		else // Pay Reference Curve
		{
			Pay_RefCrvTerm = CurveTermInfo+NCurveSum;
			Pay_RefCrvRate = CurveRateInfo+NCurveSum;
		}
	}

	//////////////////////////////////////////////////////////////
	// SOFR ���� ����
	long SOFRUseFlag = SOFRFlags[0];
	long RcvDailyRateLoggingFlag = SOFRFlags[1];
	long PayDailyRateLoggingFlag = SOFRFlags[2];
	long InterpolateFlag = SOFRFlags[3];

	long *RcvSOFRConv = SOFRConv;
	long *PaySOFRConv = SOFRConv + 4;
	long NRcvHoliday = HolidayCount[0];
	long NPayHoliday = HolidayCount[1];
	long *RcvHoliday = Holiday;
	long *PayHoliday = Holiday + NRcvHoliday;

	long Rcv_HolidayStartDate = 20000101;
	long Rcv_HolidayEndDate = max(Rcv_ForwardEndDate_Ctype[Rcv_Ncf-1], Rcv_PayDate_Ctype[Rcv_Ncf-1]);
	long Rcv_NHolidayFast = 0;
	long* Rcv_HolidayFast;

	long Pay_HolidayStartDate = 20000101;
	long Pay_HolidayEndDate = max(Pay_ForwardEndDate_Ctype[Pay_Ncf-1], Pay_PayDate_Ctype[Pay_Ncf-1]);
	long Pay_NHolidayFast=0;
	long* Pay_HolidayFast;

	if (SOFRUseFlag == 1 || SOFRUseFlag == 2)
	{
		////////////////
		// Rcv Holiday, RefRate History �ʹ� �� ���ų� �ʹ� �� �̷� �����ʹ� ����
		////////////////

		Rcv_HolidayStartDate = ActDateAdjust(PriceDate, -365*3);

		Rcv_NHolidayFast = 0;
		for (i = 0 ; i < NRcvHoliday; i++)
		{
			if ( RcvHoliday[i] >= Rcv_HolidayStartDate && RcvHoliday[i] <= Rcv_HolidayEndDate) Rcv_NHolidayFast += 1;
		}		
		Rcv_HolidayFast = (long*)malloc(sizeof(long) * max(1,Rcv_NHolidayFast));

		k = 0;
		for (i = 0 ; i < NRcvHoliday; i++)
		{
			if ( RcvHoliday[i] >= Rcv_HolidayStartDate && RcvHoliday[i] <= Rcv_HolidayEndDate) 
			{
				Rcv_HolidayFast[k] = RcvHoliday[i];
				k += 1;
			}			
		}
		
		////////////////
		// Pay Holiday, RefRate History
		////////////////
		Pay_HolidayStartDate = ActDateAdjust(PriceDate, -365*3);

		Pay_NHolidayFast = 0;
		for (i = 0 ; i < NPayHoliday; i++)
		{
			if ( PayHoliday[i] >= Pay_HolidayStartDate && PayHoliday[i] <= Pay_HolidayEndDate) Pay_NHolidayFast += 1;
		}		
		Pay_HolidayFast = (long*)malloc(sizeof(long) * max(1,Pay_NHolidayFast));

		k = 0;
		for (i = 0 ; i < NPayHoliday; i++)
		{
			if ( PayHoliday[i] >= Pay_HolidayStartDate && PayHoliday[i] <= Pay_HolidayEndDate) 
			{
				Pay_HolidayFast[k] = PayHoliday[i];
				k += 1;
			}			
		}
	}
	else
	{
		Rcv_HolidayFast = (long*)malloc(sizeof(long) * 1);
		Pay_HolidayFast = (long*)malloc(sizeof(long) * 1);
	}

	long DayCountFlagFloat;
	long DayCountFlagFixed;

	double NotionalFloat;
	double NotionalFixed;
	double FloatFX, FixedFX, CalcFX;

	long NFloatRef;
	double* FloatRefTerm;
	double* FloatRefRate;
	
	long NFloatDisc;
	double* FloatDiscTerm;
	double* FloatDiscRate;

	long NFixedDisc;
	double* FixedDiscTerm;
	double* FixedDiscRate;

	long NFloatCF, NFixedCF;

	long* Float_ForwardStartDate;
	long* Float_ForwardEndDate;
	long* Float_PayDate;

	long* Fixed_ForwardStartDate;
	long* Fixed_ForwardEndDate;
	long* Fixed_PayDate;

	long Float_NHoliday;
	long* Float_Holiday;
	long* Float_SOFRConv;
	long DailyRateLogging = 0;

	double CurrentSOFRSwapRate = 0.0;

	if (Rcv_CpnType == 2)
	{
		DailyRateLogging = RcvDailyRateLoggingFlag;
		DayCountFlagFloat = Rcv_DayCountConv;
		DayCountFlagFixed = Pay_DayCountConv;

		if (Rcv_NAFlag == 1 && Pay_NAFlag == 1)
		{
			NotionalFloat = Rcv_Notional;
			NotionalFixed = Pay_Notional;
		}
		else
		{
			NotionalFloat = 1.0;
			NotionalFixed = 1.0;
		}

		FloatFX = Rcv_CrcyRate;
		FixedFX = Pay_CrcyRate;
		CalcFX = Calc_CrcyRate;

		NFloatRef = NRcv_RefCrvTerm;
		FloatRefTerm = Rcv_RefCrvTerm;
		FloatRefRate = Rcv_RefCrvRate;

		NFloatDisc = NRcv_DisCrvTerm;
		FloatDiscTerm = Rcv_DisCrvTerm;
		FloatDiscRate = Rcv_DisCrvRate;

		NFixedDisc = NPay_DisCrvTerm;
		FixedDiscTerm = Pay_DisCrvTerm;
		FixedDiscRate = Pay_DisCrvRate;

		Float_NHoliday = Rcv_NHolidayFast;
		Float_Holiday = Rcv_HolidayFast;
		for (i = 0 ; i< Float_NHoliday; i++)
		{
			Float_Holiday[i] = ActDayCount(Rcv_ForwardStartDate_Ctype[0], Float_Holiday[i]);
		}
		NFloatCF = Rcv_Ncf;
		Float_ForwardStartDate = Rcv_ForwardStartDate_Ctype;
		Float_ForwardEndDate = Rcv_ForwardEndDate_Ctype;
		Float_PayDate = Rcv_PayDate_Ctype;

		NFixedCF = Pay_Ncf;
		Fixed_ForwardStartDate = Pay_ForwardStartDate_Ctype;
		Fixed_ForwardEndDate = Pay_ForwardEndDate_Ctype;
		Fixed_PayDate = Pay_PayDate_Ctype;

		Float_SOFRConv = RcvSOFRConv;

	}
	else
	{
		DailyRateLogging = PayDailyRateLoggingFlag;
		DayCountFlagFloat = Pay_DayCountConv;
		DayCountFlagFixed = Rcv_DayCountConv;

		if (Rcv_NAFlag == 1 && Pay_NAFlag == 1)
		{
			NotionalFloat = Pay_Notional;
			NotionalFixed = Rcv_Notional;
		}
		else
		{
			NotionalFloat = 1.0;
			NotionalFixed = 1.0;
		}

		FloatFX = Pay_CrcyRate;
		FixedFX = Rcv_CrcyRate;
		CalcFX = Calc_CrcyRate;

		NFloatRef = NPay_RefCrvTerm;
		FloatRefTerm = Pay_RefCrvTerm;
		FloatRefRate = Pay_RefCrvRate;

		NFloatDisc = NPay_DisCrvTerm;
		FloatDiscTerm = Pay_DisCrvTerm;
		FloatDiscRate = Pay_DisCrvRate;

		NFixedDisc = NRcv_DisCrvTerm;
		FixedDiscTerm = Rcv_DisCrvTerm;
		FixedDiscRate = Rcv_DisCrvRate;

		Float_NHoliday = Pay_NHolidayFast;
		Float_Holiday = Pay_HolidayFast;
		for (i = 0 ; i<  Float_NHoliday; i++)
		{
			Float_Holiday[i] = ActDayCount(Pay_ForwardStartDate_Ctype[0], Float_Holiday[i]);
		}

		NFloatCF = Pay_Ncf;
		Float_ForwardStartDate = Pay_ForwardStartDate_Ctype;
		Float_ForwardEndDate = Pay_ForwardEndDate_Ctype;
		Float_PayDate = Pay_PayDate_Ctype;

		NFixedCF = Rcv_Ncf;
		Fixed_ForwardStartDate = Rcv_ForwardStartDate_Ctype;
		Fixed_ForwardEndDate = Rcv_ForwardEndDate_Ctype;
		Fixed_PayDate = Rcv_PayDate_Ctype;

		Float_SOFRConv = PaySOFRConv;
	}

	CurrentSOFRSwapRate = Current_SOFR_SwapRate(DayCountFlagFloat,DayCountFlagFixed,NotionalFloat,NotionalFixed,NFloatRef,
												FloatRefTerm,FloatRefRate,NFloatDisc,FloatDiscTerm,FloatDiscRate,
												NFixedDisc,FixedDiscTerm,FixedDiscRate,NFloatCF,Float_ForwardStartDate,
												Float_ForwardEndDate,Float_PayDate,NFixedCF,Fixed_ForwardStartDate,Fixed_ForwardEndDate,
												Fixed_PayDate,SOFRUseFlag,Float_SOFRConv,Float_NHoliday,Float_Holiday,
												InterpolateFlag,CalcFX,FloatFX,FixedFX,DailyRateLogging,
												szFileName,szModuleName);

	ResultPrice[0] = CurrentSOFRSwapRate;

	free(Rcv_HolidayFast);
	free(Pay_HolidayFast);
	return ResultCode;
}

// ��� Swap Rate�� �����ڻ� Swap�� IRS�� �������� �Ѵ�.
// �����ڻ� Swap�� Reference Curve(Floating)�� Swap �ݸ��� �ƴϴ�.
// Floating Leg�� ������ Rcv Leg�� ��������
// ���� Leg�� 
double Calc_SwapRate(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	long SwapEffectiveDate,			// IN:  �����ڻ� Swap�� Effective Date

	long NRefCrvTerm,				// IN:  Floating Curve Term ����
	double *RefCrvTerm,				// IN:  Floating Curve Term
	double *RefCrvRate,				// IN:  Floating Curve Rate
	long RefCrvDayCntType,			// IN:  Floating Curve Type

	long Flt_NDisCrvTerm,			// IN:  Floating Leg Discount Curve Term ����
	double *Flt_DisCrvTerm,			// IN:  Floating Leg Discount Curve Term
	double *Flt_DisCrvRate,			// IN:  Floating Leg Discount Curve Rate
	long Flt_DisCrvDayCntType,		// IN:  Floating Leg Discount Curve Type

	long Fix_NDisCrvTerm,			// IN:  Fixed Leg Discount Curve Term ����
	double *Fix_DisCrvTerm,			// IN:  Fixed Leg Discount Curve Term
	double *Fix_DisCrvRate,			// IN:  Fixed Leg Discount Curve Rate
	long Fix_DisCrvDayCntType,		// IN:  Fixed Leg Discount Curve Type

	long Flt_DayCntType,			// IN:  Floating Leg Day Count Convention 
	long Flt_NCpnCashFlow,			// IN:  Floating Leg Coupon ����
	long *Flt_ForwardStartDate,		// IN:  Floating Leg ���� ���� ������ (YYYYMMDD)
	long *Flt_ForwardEndDate,		// IN:  Floating Leg ���� ���� ������ (YYYYMMDD)
	long *Flt_CpnFromDate,			// IN:  Floating Leg ����� (YYYYMMDD)
	long *Flt_CpnToDate,			// IN:  Floating Leg �⸻�� (YYYYMMDD)
	long *Flt_CpnSettleDate,		// IN:  Floating Leg ������ (YYYYMMDD)

	long Fix_DayCntType,			// IN:  Fixed Leg Day Count Convention 
	long Fix_NCpnCashFlow,			// IN:  Fixed Leg Coupon ����
	long *Fix_CpnFromDate,			// IN:  Fixed Leg ����� (YYYYMMDD)
	long *Fix_CpnToDate,			// IN:  Fixed Leg �⸻�� (YYYYMMDD)
	long *Fix_CpnSettleDate			// IN:  Fixed Leg ������ (YYYYMMDD)
)
{
	long i;
	double Flt_LegValue = 0.0;
	double Fix_LegValue = 0.0;
	double ResultRate = 0.0;

	double Flt_DF_EffDate = Calc_DiscountFactor(PriceDate, Flt_DisCrvTerm, Flt_DisCrvRate, Flt_NDisCrvTerm, Flt_DisCrvDayCntType, SwapEffectiveDate);
	double Fix_DF_EffDate = Calc_DiscountFactor(PriceDate, Fix_DisCrvTerm, Fix_DisCrvRate, Fix_NDisCrvTerm, Fix_DisCrvDayCntType, SwapEffectiveDate);

	for(i=0;i<Flt_NCpnCashFlow;i++)
	{
		Flt_LegValue += Calc_DiscountFactor(PriceDate, Flt_DisCrvTerm, Flt_DisCrvRate, Flt_NDisCrvTerm, Flt_DisCrvDayCntType, Flt_CpnSettleDate[i])/Flt_DF_EffDate  // P( t, SettleD[i], Flt DayConv)
						* (	Calc_DiscountFactor(PriceDate, RefCrvTerm, RefCrvRate, NRefCrvTerm, RefCrvDayCntType, Flt_ForwardStartDate[i])
							/ Calc_DiscountFactor(PriceDate, RefCrvTerm, RefCrvRate, NRefCrvTerm, RefCrvDayCntType, Flt_ForwardEndDate[i]) -1 ) // P(t, ForwardStart[i], Ref DayConv)/P(t, ForwardEnd[i], Ref DayConv) -1
						* DayCountFraction(Flt_CpnFromDate[i],Flt_CpnToDate[i],Flt_DayCntType)
						/ DayCountFraction(Flt_ForwardStartDate[i],Flt_ForwardEndDate[i],RefCrvDayCntType);
	}

	for(i=0;i<Fix_NCpnCashFlow;i++)
	{
		Fix_LegValue += DayCountFraction(Flt_CpnFromDate[i],Flt_CpnToDate[i],Flt_DayCntType)
						* Calc_DiscountFactor(PriceDate, Fix_DisCrvTerm, Fix_DisCrvRate, Fix_NDisCrvTerm, Fix_DisCrvDayCntType, Fix_CpnSettleDate[i])/Fix_DF_EffDate; // P( t, SettleD[i], Fix DayConv)
	}

	ResultRate = Flt_LegValue/Fix_LegValue;

	return ResultRate;

}


