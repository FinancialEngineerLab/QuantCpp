#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <windows.h>
#include <cmath>
#include <algorithm>
#include <locale>
#include <set>
#include <map>
#include <iomanip>
#include <sstream>

using std::string;
using std::cout;
using std::endl;
using std::ifstream;
using std::ofstream;
using std::vector;
using std::abs;
using std::sqrt;
using std::max;
using std::set;
using std::find;
using std::begin;
using std::end;
using std::replace;
using std::map;
using std::pair;
using std::stringstream;
using std::sort;


string root_dir = "./";
string input_dir = root_dir + "CRIF/";
string output_dir = root_dir + "Results/";

vector<string> gv_tenor_list = { "2w", "1m","3m","6m","1y","2y","3y","5y","10y","15y","20y","30y" };
vector<string> gv_Rates_list = { "Risk_IRCurve", "Risk_Inflation", "Risk_XCcyBasis", "Risk_IRVol", "Risk_InflationVol" };
vector<string> gv_FX_list = { "Risk_FX", "Risk_FXVol" };
vector<string> gv_CreditQ_list = { "Risk_CreditQ", "Risk_CreditVol", "Risk_BaseCorr" };
vector<string> gv_CreditNonQ_list = { "Risk_CreditNonQ", "Risk_CreditVolNonQ" };
vector<string> gv_Equity_list = { "Risk_Equity", "Risk_EquityVol" };
vector<string> gv_Commodity_list = { "Risk_Commodity", "Risk_CommodityVol" };

vector<string> gv_RiskClass_List = { "Rates", "FX", "CreditQ", "CreditNonQ", "Equity", "Commodity" };

const double norm_ppf_99 = 2.3263478740408408;
const double norm_ppf_995 = 2.5758293035489004;

string string_tolower(string str) {
	for (auto& c : str) {
		c = tolower(c);
	}
	return str;
}

std::string string_replace(std::string str, const std::string& from, const std::string& to) {
	size_t start_pos = 0;
	while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
		str.replace(start_pos, from.length(), to);
		start_pos += to.length(); // Handles case where 'to' is a substring of 'from'
	}
	return str;
}

string to_string(double x) {
	stringstream stream;
	stream << std::fixed << std::setprecision(2) << x; //round to 2
	string s = stream.str();
	return s;
}
string to_string(int x) {
	stringstream stream;
	stream << x;
	string s = stream.str();
	return s;
}

/*
double to_double(string& x) {
	if (x == "") return std::nan("");
	else return std::stod(x);
}
*/

// 2021.12.14 ����
double to_double(string x) {
	if (x == "") return std::nan("");
	else return std::stod(x);
}

vector<double> to_double(vector<string>& x) {
	vector<double> ret;
	for (string a : x) {
		ret.push_back(to_double(a));
	}
	return ret;
}
vector<vector<double>> to_double(vector<vector<string>>& x) {
	vector<vector<double>> ret;
	for (vector<string> a : x) {
		ret.push_back(to_double(a));
	}
	return ret;
}

int to_int(string x) {
	return std::stoi(x);
}

double sum(vector<double>& x) {
	double s = 0.0;
	for (auto a : x) {
		s += a;
	}
	return s;
}


double round(double value, double decimal) {
	double multiplier = std::pow(10.0, decimal);
	return std::ceil(value * multiplier) / multiplier;
}

template <typename T>
vector<T> sel_column(vector<vector<T>>& table, int index) {
	vector<T> sel;

	int r = table.size();
	int c = table[0].size();

	for (int i = 0; i < r; i++) {
		for (int j = 0; j < c; j++) {
			if (j == index) {
				sel.push_back(table[i][j]);
			}
		}
	}

	return sel;
}


template <typename T>
void print(T x) {
	cout << x << endl;
}
void print(double x) {
	cout << std::fixed << std::setprecision(6) << x << endl;
}
template <typename T>
void print(vector<T> x) {
	for (auto a : x) {
		cout << a << ", ";
	}
	cout << endl;
}
template <typename T>
void print(vector<vector<T>> x) {
	for (auto b : x) {
		for (auto a : b) {
			cout << a << ", ";
		}
		cout << endl;
	}
	cout << endl;
}
template <typename T, typename W>
void print(map<T, W> x) {
	for (auto a : x) {
		cout << a.first << ": " << a.second << ", ";
	}
	cout << endl;
}

/*
template <typename T>
bool isin(T elem, vector<T>& list) {
	//found
	if (find(begin(list), end(list), elem) != end(list)) {
		return true;
	}
	else {
		return false;
	}
}
*/

// ���� 2021.12.14
template <typename T>
bool isin(T elem, vector<T> list) {
	//found
	if (find(begin(list), end(list), elem) != end(list)) {
		return true;
	}
	else {
		return false;
	}
}

template <typename T>
int loc(T elem, vector<T>& list) {
	//found
	if (find(begin(list), end(list), elem) != end(list)) {
		auto it = find(begin(list), end(list), elem);
		int idx = it - begin(list);
		return idx;
	}
	else {
		return -1;
	}
}

/*
template <typename T>
vector<T> append(vector<T>& a, vector<T>& b) {
	vector<T> x;
	x.insert(end(x), begin(a), end(a));
	x.insert(end(x), begin(b), end(b));
	return x;
		
}*/

template <typename T>
vector<T> append(vector<T> a, vector<T> b) {
	vector<T> x;
	x.insert(end(x), begin(a), end(a));
	x.insert(end(x), begin(b), end(b));
	return x;

}

