#pragma once
#include "common.h"
#include "dirent.h"

enum class CSVState {
	UnquotedField,
	QuotedField,
	QuotedQuote
};

vector<string> readCSVRow(const string &row) {
	CSVState state = CSVState::UnquotedField;
	vector<string> fields{ "" };
	size_t i = 0; // index of the current field
	for (char c : row) {
		switch (state) {
		case CSVState::UnquotedField:
			switch (c) {
			case ',': // end of field
				fields.push_back(""); i++;
				break;
			case '"': state = CSVState::QuotedField;
				break;
			default:  fields[i].push_back(c);
				break;
			}
			break;
		case CSVState::QuotedField:
			switch (c) {
			case '"': state = CSVState::QuotedQuote;
				break;
			default:  fields[i].push_back(c);
				break;
			}
			break;
		case CSVState::QuotedQuote:
			switch (c) {
			case ',': // , after closing quote
				fields.push_back(""); i++;
				state = CSVState::UnquotedField;
				break;
			case '"': // "" -> "
				fields[i].push_back('"');
				state = CSVState::QuotedField;
				break;
			default:  // end of quote
				state = CSVState::UnquotedField;
				break;
			}
			break;
		}
	}
	return fields;
}

/// Read CSV file, Excel dialect. Accept "quoted fields ""with quotes"""
vector<vector<string>> readCSV(std::istream &in) {
	vector<vector<string>> table;
	string row;
	while (!in.eof()) {
		std::getline(in, row);
		if (in.bad() || in.fail()) {
			break;
		}
		auto fields = readCSVRow(row);
		table.push_back(fields);
	}
	return table;
}

vector<vector<string>> readCSV(string &filename) {
	ifstream myfile;

	myfile.open(filename);
	auto content = readCSV(myfile);
	myfile.close();
	return content;
}



vector<string> scanDirForCsv(string &input_dir) {
	vector<string> ret;

	DIR *dir;
	struct dirent *ent;
	if ((dir = opendir(input_dir.c_str())) != NULL) {
		/* scan all the files and directories within directory */
		while ((ent = readdir(dir)) != NULL) {
			string filename(ent->d_name);
			if (filename.size() >= 4) {
				string ext = filename.substr(filename.size() - 4);
				if (ext == ".csv") {
					ret.push_back(filename);
				}
			}
		}
		closedir(dir);
	}
	else {
		/* could not open directory */
		perror("");
	}

	return ret;
}

/*
void saveAsCsv(vector<vector<string>>& content, string &output_filename) {
	ofstream outfile(output_filename);
	for (auto r : content) {
		for (auto c : r) {
			outfile << c << ",";
		}
		outfile << endl;
	}
}
*/

// 2021.12.14 ����
void saveAsCsv(vector<vector<string>> content, string output_filename) {
	ofstream outfile(output_filename);
	for (auto r : content) {
		for (auto c : r) {
			outfile << c << ",";
		}
		outfile << endl;
	}
}
