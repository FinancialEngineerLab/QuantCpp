#pragma once
#include "common.h"
#include "CRIF.h"
#include "OUTPUT.h"
#include "Weights_Corr.h"
#include "K.h"

class SIMM
{
public:
	CRIFTable crif;
	long mode;					// 0 : AmountUSD�� ����Ͽ� USD���� ����.     1 : �����ȭ�� ȯ���� �߰� �Է¹ް�, Amount�� ����Ͽ� ����
	string calc_currency;		// �����ȭ (�빮�ڷ� �Է�).  ex) KRW
	double Exchange_Rate;		// �����ȭ�� USD���� ȯ��

	//# Global CRIF
	SIMM(vector<vector<string>>& crif_raw, string _calc_currency, double _Exchange_Rate, bool _Secured, long _mode) {
		if (_Secured) {
			this->crif.input_data_S(crif_raw);
		}
		else {
			this->crif.input_data_P(crif_raw);
		}
		this->calc_currency = _calc_currency;
		this->Exchange_Rate = _Exchange_Rate;
		this->mode = _mode;
	}
	SIMM(CRIFTable _crif, string _calc_currency, double _Exchange_Rate, long _mode) {
		this->crif = _crif;
		this->calc_currency = _calc_currency;
		this->Exchange_Rate = _Exchange_Rate;
		this->mode = _mode;
	}

	//# Concentration Threshold ���
	double CR(double sum_s, double T) {
		return max(1, sqrt(abs(sum_s) / T));
	}

	//# mode�� ���� CRIF���� �ΰ����� Sum ��� 
	double sum_sensitivities(CRIFTable& df, long mode) {
		vector<double> temp_amount;
		if (mode == 0) {
			temp_amount = df.get_AmountUSD();
			return sum(temp_amount);
		}
		else if (mode == 1) {
			temp_amount = df.get_Amount();
			return sum(temp_amount);
		}
	}

	//# CRIF���� �׳� ����(list)
	vector<string> tenor_list(CRIFTable& df) {
		vector<string> col = df.get_Label1();
		set<string> s;
		for (string cell : col) {
			//found
			if (isin(cell, gv_tenor_list)) {
				s.insert(string_tolower(cell));
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� risk class ���� (list)
	vector<string> Riskclass_list(CRIFTable& crif) {
		vector<string> col = crif.get_RiskType();
		set<string> s;

		for (string cell : col) {
			if (cell != "") {
				s.insert(cell);
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� currency ���� (list)
	vector<string> currency_list(CRIFTable& df) {
		vector<string> col = df.get_Qualifier();
		set<string> s;

		for (string cell : col) {
			if (cell != "" && cell.size() == 3) {
				s.insert(cell);
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� currency pair ���� (list)
	vector<string> currencyPair_list() {
		vector<string> col = this->crif.get_Qualifier();

		vector<string> currencyPair;
		for (string cell : col) {
			if (cell != "" && cell.size() == 6) {
				currencyPair.push_back(cell);

			}
		}


		//# USDKRW�� KRWUSD�� ���� Pair�� �����ϱ� ������
		//# �ߺ��Ǵ� Pair�� �����ϰ� ����Ʈ�� �߰�
		vector<string> currencyPair_list;
		set<string> s;
		for (string x : currencyPair) {
			string y = x.substr(3, 3) + x.substr(0, 3);
			if (!isin(y, currencyPair_list)) {
				currencyPair_list.push_back(x);
				s.insert(x);
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� qualifier ���� (list)
	vector<string> qualifier_list(CRIFTable& df) {
		vector<string> col = df.get_Qualifier();
		set<string> s;

		for (string cell : col) {
			if (cell != "") {
				s.insert(cell);
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� product class ���� (list)
	vector<string> product_list() {
		vector<string> col = this->crif.get_ProductClass();
		set<string> s;

		for (string cell : col) {
			if (cell != "") {
				s.insert(cell);
			}
		}

		vector<string> l(s.begin(), s.end());
		return l;
	}

	//# CRIF���� bucket ���� (list)
	vector<int> bucket_list(CRIFTable& df) {
		vector<string> col = df.get_Bucket();
		set<int> s;

		if (isin(string("Residual"), col)) {
			for (string cell : col) {
				if (cell != "" && cell != "Residual") {
					s.insert(to_int(cell));
				}
			}
			s.insert(0);
		}
		else {
			for (string cell : col) {
				if (cell != "") {
					s.insert(to_int(cell));
				}
			}
		}

		vector<int> l(s.begin(), s.end());
		return l;
	}

	//# Scaling Function of time t (for Curvature Margin)
	double SF(string t) {
		if (t == "2w") {
			return 0.5;
		}
		else if (t.find("m") != string::npos || t.find("M") != string::npos) {
			double tt;
			if (t.find("m") != string::npos) {
				tt = (365.0 / 12.0) * to_double(string_replace(t, "m", ""));
			}
			else if (t.find("M") != string::npos) {
				tt = (365.0 / 12.0) * to_double(string_replace(t, "M", ""));
			}
			return 0.5 * min(1, 14.0 / tt);
		}
		else if (t.find("y") != string::npos || t.find("Y") != string::npos) {
			double tt;
			if (t.find("y") != string::npos) {
				tt = 365.0 * to_double(string_replace(t, "y", ""));
			}
			else if (t.find("Y") != string::npos) {
				tt = 365.0 * to_double(string_replace(t, "Y", ""));
			}
			return 0.5 * min(1, 14.0 / tt);
		}

		cout << "UNREACHABLE" << endl;
		exit(1);
	}

	//# ����Ʈ���� distinct�� element�� ���� �ϴ� �Լ�
	template <typename T>
	vector<T> unique(vector<T>& a) {
		set<T> s;
		for (auto e : a) {
			s.insert(e);
		}
		vector<T> l(s.begin(), s.end());
		return l;
	}

	//# Delta/Vega/Curvature/Base Correlation Margin�� �����Ͽ� �ϳ��� dictionary��
	//# sum�Ͽ� ������Ʈ
	map<string, RiskClassTable> IM_x(CRIFTable& crif) {

		map<string, RiskClassTable> Total_Dict;


		map<string, RiskClassTable> RatesDeltaDict = RatesDeltaMargin(crif);
		map<string, RiskClassTable> DeltaDict = DeltaMargin(crif);
		map<string, RiskClassTable> RatesVegaDict = RatesVegaMargin(crif);
		map<string, RiskClassTable> VegaDict = VegaMargin(crif);
		map<string, RiskClassTable> RatesCurvatureDict = RatesCurvatureMargin(crif);
		map<string, RiskClassTable> CurvatureDict = CurvatureMargin(crif);
		map<string, RiskClassTable> BaseCorrDict = BaseCorrMargin(crif);

		for (string s : gv_RiskClass_List) {
			
			Total_Dict[s] = RatesDeltaDict[s] + DeltaDict[s] + RatesVegaDict[s] + VegaDict[s] + RatesCurvatureDict[s] + CurvatureDict[s] + BaseCorrDict[s];
			
			//@ ������
			//cout << s << endl;
			//BaseCorrDict[s].print();
			//RatesDeltaDict[s].print();
			//DeltaDict[s].print();
			//RatesVegaDict[s].print();
			//VegaDict[s].print();
			//RatesCurvatureDict[s].print();
			//CurvatureDict[s].print();
			
			//Total_Dict[s].print();
		}



		for (auto& x : Total_Dict) {
			string dic_riskClass = x.first;
			if (dic_riskClass != "CreditQ") {
				x.second.IM_sensi.erase("BaseCorr");
			}
		}

		/*for (auto& x : Total_Dict) {
			for (auto& y : x.second.IM_sensi) {
				y.second *= this->Exchange_Rate;
			}
		}*/

		return Total_Dict;
	}

	//# Product Class �� SIMM ���
	double SIMM_Product(map<string, RiskClassTable>& Aggregated_SIMM) {
		map<string, double> SIMM_RiskClasses;

		for (string risk_class : gv_RiskClass_List) {
			double SIMM_riskClass = Aggregated_SIMM[risk_class].sum();
			SIMM_RiskClasses[risk_class] = SIMM_riskClass;
		}

		double SIMM_Product = 0;
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				double psi_;
				if (i == j) {
					psi_ = 1;
				}
				else {
					psi_ = _psi(gv_RiskClass_List[i], gv_RiskClass_List[j]);
				}

				SIMM_Product += psi_ * SIMM_RiskClasses[gv_RiskClass_List[i]] * SIMM_RiskClasses[gv_RiskClass_List[j]];
			}
		}

		return sqrt(SIMM_Product);

	}

	ProductClassTable results_productClass(map<string, RiskClassTable>& results_dic) {

		ProductClassTable p;

		for (string risk_class : gv_RiskClass_List) {
			RiskClassTable dic_sensiType = results_dic[risk_class];

			//@ Curvature, Delta, Vega, (BaseCorr)�� ���� 0�϶� ����� ���� ����
			bool empty = true;
			for (auto x : dic_sensiType.IM_sensi) {
				if (x.second != 0.0) {
					empty = false;
				}
			}
			if (!empty) {
				dic_sensiType.IM_RiskClass = dic_sensiType.sum();
				p.RiskClass[risk_class] = dic_sensiType;
			}

		}

		return p;
	}

	OutputTable results_total() {
		double SIMM_finalNumber = 0.0;
		double AddOn_MS = 0.0;
		map<string, double> dic_addon;
		double IM_Final = 0.0;
		CRIFTable Temp_CRIFTable;

		OutputTable df_total;


		for (string product_class : this->product_list()) {

			//@ ���� �ڵ忡���� IM_x �� �ߺ����� ���ż� ��ȿ�����̾���
			Temp_CRIFTable = this->crif.sel_ProductClass(product_class);
			auto imx = this->IM_x(Temp_CRIFTable);
			auto df_prod = this->results_productClass(imx);
			auto simm_prod = this->SIMM_Product(imx);

			df_prod.IM_ProductClass = simm_prod;
			IM_Final += simm_prod;
			df_total.ProductClass[product_class] = df_prod;

			vector<string> rcl = this->Riskclass_list(this->crif);

			if (isin(string("Param_ProductClassMultiplier"), rcl)) {
				auto df_MS = this->crif.sel_RiskType("Param_ProductClassMultiplier");
				auto df_MS_prod = df_MS.sel_Qualifier(product_class);
				double MS = this->sum_sensitivities(df_MS_prod, mode) - 1.0;
				AddOn_MS += simm_prod * MS;
			}


			dic_addon[product_class] = simm_prod;
			SIMM_finalNumber += simm_prod;

		}


		double AddOn_Margin = round(AddOn_MS + AddOn_IM(), 2);
		IM_Final += AddOn_Margin;

		df_total.SIMM = IM_Final;

		if (AddOn_Margin != 0) {
			df_total.AddOn = AddOn_Margin;
			df_total.AddOn_enabled = true;
		}
		else {
			df_total.AddOn_enabled = false;
		}

		return df_total;
	}

	CRIFTable output1(double total_SIMM) {

		int n = this->crif.crif_table.size();

		for (int i = 0; i < n; i++) {
			CRIFRow& row = this->crif.crif_table[i];

			CRIFTable one_row;
			one_row.crif_table.push_back(row);

			SIMM one_simm(one_row, calc_currency, Exchange_Rate, mode);
			OutputTable one_res = one_simm.results_total();

			row.IM = one_res.SIMM;

			
			CRIFTable except_one_row = this->crif;
			except_one_row.crif_table.erase(except_one_row.crif_table.begin() + i);
			
			SIMM except_one_simm(except_one_row, calc_currency, Exchange_Rate, mode);
			OutputTable except_one_res = except_one_simm.results_total();

			row.Impact = total_SIMM - except_one_res.SIMM;
			


		}

		return this->crif;
	}

	OutputTable output2(OutputTable& original) {
		OutputTable output2 = original;

		
		for (string product_class : this->product_list()) {
			auto table_productclass = this->crif.sel_ProductClass(product_class);


			{ //Rates

				CRIFTable table_riskclass;
				

				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Rates_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto qualifier_list = this->qualifier_list(table_riskclass);

				for (string qualifier : qualifier_list) {
					CRIFTable one_qual = table_riskclass.sel_Qualifier(qualifier);

					SIMM one_qual_simm(one_qual, calc_currency, Exchange_Rate, mode);
					OutputTable one_qual_res = one_qual_simm.results_total();
					
					
					auto& rct = output2.ProductClass[product_class].RiskClass["Rates"];
					auto one_rct = one_qual_res.ProductClass[product_class].RiskClass["Rates"];

					for (auto one_sensi : one_rct.IM_sensi) {
						rct.sensi_bucket[one_sensi.first].IM_Bucket[qualifier] = one_sensi.second;
					}
				}
			}
			{ //FX

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_FX_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto qualifier_list = this->qualifier_list(table_riskclass);

				for (string qualifier : qualifier_list) {
					CRIFTable one_qual = table_riskclass.sel_Qualifier(qualifier);

					SIMM one_qual_simm(one_qual, calc_currency, Exchange_Rate, mode);
					OutputTable one_qual_res = one_qual_simm.results_total();


					auto& rct = output2.ProductClass[product_class].RiskClass["FX"];
					auto one_rct = one_qual_res.ProductClass[product_class].RiskClass["FX"];

					for (auto one_sensi : one_rct.IM_sensi) {
						rct.sensi_bucket[one_sensi.first].IM_Bucket[qualifier] = one_sensi.second;
					}
				}
			}
			{ //Equity

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Equity_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable one_bucket = table_riskclass.sel_Bucket(bucket);

					SIMM one_bucket_simm(one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable one_bucket_res = one_bucket_simm.results_total();


					auto& rct = output2.ProductClass[product_class].RiskClass["Equity"];
					auto one_rct = one_bucket_res.ProductClass[product_class].RiskClass["Equity"];

					for (auto one_sensi : one_rct.IM_sensi) {
						if (bucket == 0)
							rct.sensi_bucket[one_sensi.first].IM_Bucket["Residual"] = one_sensi.second;
						else
							rct.sensi_bucket[one_sensi.first].IM_Bucket[to_string(bucket)] = one_sensi.second;
					}
				}
			}
			{ //CreditQ

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_CreditQ_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable one_bucket = table_riskclass.sel_Bucket(bucket);

					SIMM one_bucket_simm(one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable one_bucket_res = one_bucket_simm.results_total();


					auto& rct = output2.ProductClass[product_class].RiskClass["CreditQ"];
					auto one_rct = one_bucket_res.ProductClass[product_class].RiskClass["CreditQ"];

					for (auto one_sensi : one_rct.IM_sensi) {
						if (bucket == 0)
							rct.sensi_bucket[one_sensi.first].IM_Bucket["Residual"] = one_sensi.second;
						else
							rct.sensi_bucket[one_sensi.first].IM_Bucket[to_string(bucket)] = one_sensi.second;
					}
				}
			}
			{ //CreditNonQ

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_CreditNonQ_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable one_bucket = table_riskclass.sel_Bucket(bucket);

					SIMM one_bucket_simm(one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable one_bucket_res = one_bucket_simm.results_total();


					auto& rct = output2.ProductClass[product_class].RiskClass["CreditNonQ"];
					auto one_rct = one_bucket_res.ProductClass[product_class].RiskClass["CreditNonQ"];

					for (auto one_sensi : one_rct.IM_sensi) {
						if (bucket == 0)
							rct.sensi_bucket[one_sensi.first].IM_Bucket["Residual"] = one_sensi.second;
						else
							rct.sensi_bucket[one_sensi.first].IM_Bucket[to_string(bucket)] = one_sensi.second;
					}
				}
			}
			{ //Commodity

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Commodity_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable one_bucket = table_riskclass.sel_Bucket(bucket);

					SIMM one_bucket_simm(one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable one_bucket_res = one_bucket_simm.results_total();


					auto& rct = output2.ProductClass[product_class].RiskClass["Commodity"];
					auto one_rct = one_bucket_res.ProductClass[product_class].RiskClass["Commodity"];

					for (auto one_sensi : one_rct.IM_sensi) {
						if (bucket == 0)
							rct.sensi_bucket[one_sensi.first].IM_Bucket["Residual"] = one_sensi.second;
						else
							rct.sensi_bucket[one_sensi.first].IM_Bucket[to_string(bucket)] = one_sensi.second;
					}
				}
			}

			

		}

		return output2;
	}

	OutputTable output3(OutputTable& original) {
		OutputTable output3 = original;

		for (string product_class : this->product_list()) {
			
			auto table_productclass = this->crif.sel_ProductClass(product_class);
			auto table_not_productclass = this->crif.sel_not_ProductClass(product_class);

			//@ Impact_ProductClass
			SIMM except_product_simm(table_not_productclass, calc_currency, Exchange_Rate, mode);
			OutputTable except_product_res = except_product_simm.results_total();

			auto &pct = output3.ProductClass[product_class];
			pct.Impact_ProductClass = output3.SIMM - except_product_res.SIMM;

			//@ Impact_RiskClass
			for (auto riskClassTable : pct.RiskClass) {
				string risk_class = riskClassTable.first;
				CRIFTable table_not_riskclass;
				
				if (risk_class == "Rates") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_Rates_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}
				else if (risk_class == "FX") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_FX_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}
				else if (risk_class == "CreditQ") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_CreditQ_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}
				else if (risk_class == "CreditNonQ") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_CreditNonQ_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}
				else if (risk_class == "Equity") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_Equity_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}
				else if (risk_class == "Commodity") {
					for (auto row : table_productclass.crif_table) {
						if (!isin(row.RiskType, gv_Commodity_list)) {
							table_not_riskclass.crif_table.push_back(row);
						}
					}
				}

				SIMM except_risk_simm(table_not_riskclass, calc_currency, Exchange_Rate, mode);
				OutputTable except_risk_res = except_risk_simm.results_total();

				auto& rct = output3.ProductClass[product_class].RiskClass[risk_class];
				auto except_risk_pct = except_risk_res.ProductClass[product_class];

				rct.Impact_RiskClass = pct.IM_ProductClass - except_risk_pct.IM_ProductClass;

				//@ Impact_SensiType
				for (auto im_sensi : rct.IM_sensi) {
					auto& impact_sensi = rct.Impact_sensi;

					impact_sensi[im_sensi.first] = im_sensi.second;
				}
				
			}


			
			//@ Impact_bucket
			{ //Rates

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Rates_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto qualifier_list = this->qualifier_list(table_riskclass);

				for (string qualifier : qualifier_list) {
					CRIFTable except_one_qual = table_riskclass.sel_not_Qualifier(qualifier);

					SIMM except_one_qual_simm(except_one_qual, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_qual_res = except_one_qual_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["Rates"];
					auto except_one_rct = except_one_qual_res.ProductClass[product_class].RiskClass["Rates"];

					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_qual.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							rct.sensi_bucket[sensi.first].Impact_Bucket[qualifier] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[qualifier] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}
				}
			}
			{ //FX

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_FX_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto qualifier_list = this->qualifier_list(table_riskclass);

				for (string qualifier : qualifier_list) {
					CRIFTable except_one_qual = table_riskclass.sel_not_Qualifier(qualifier);

					SIMM except_one_qual_simm(except_one_qual, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_qual_res = except_one_qual_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["FX"];
					auto except_one_rct = except_one_qual_res.ProductClass[product_class].RiskClass["FX"];


					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_qual.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							rct.sensi_bucket[sensi.first].Impact_Bucket[qualifier] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[qualifier] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}
				}
			}
			{ //Equity

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Equity_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable except_one_bucket = table_riskclass.sel_not_Bucket(bucket);
					


					SIMM except_one_bucket_simm(except_one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_bucket_res = except_one_bucket_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["Equity"];
					auto except_one_rct = except_one_bucket_res.ProductClass[product_class].RiskClass["Equity"];

					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_bucket.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[sensi.first] - 0.0;
							else
								rct.sensi_bucket[sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
							else
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}
					

				}
			}
			{ //CreditQ

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_CreditQ_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable except_one_bucket = table_riskclass.sel_not_Bucket(bucket);


					SIMM except_one_bucket_simm(except_one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_bucket_res = except_one_bucket_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["CreditQ"];
					auto except_one_rct = except_one_bucket_res.ProductClass[product_class].RiskClass["CreditQ"];

					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_bucket.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[sensi.first] - 0.0;
							else
								rct.sensi_bucket[sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
							else
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}

				}
			}
			{ //CreditNonQ

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_CreditNonQ_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable except_one_bucket = table_riskclass.sel_not_Bucket(bucket);


					SIMM except_one_bucket_simm(except_one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_bucket_res = except_one_bucket_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["CreditNonQ"];
					auto except_one_rct = except_one_bucket_res.ProductClass[product_class].RiskClass["CreditNonQ"];

					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_bucket.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[sensi.first] - 0.0;
							else
								rct.sensi_bucket[sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
							else
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}

				}
			}
			{ //Commodity

				CRIFTable table_riskclass;


				int n = table_productclass.crif_table.size();
				for (int i = 0; i < n; i++) {
					CRIFRow row = table_productclass.crif_table[i];

					if (isin(row.RiskType, gv_Commodity_list)) {
						table_riskclass.crif_table.push_back(row);
					}
				}

				auto bucket_list = this->bucket_list(table_riskclass);

				for (int bucket : bucket_list) {
					CRIFTable except_one_bucket = table_riskclass.sel_not_Bucket(bucket);


					SIMM except_one_bucket_simm(except_one_bucket, calc_currency, Exchange_Rate, mode);
					OutputTable except_one_bucket_res = except_one_bucket_simm.results_total();


					auto& rct = output3.ProductClass[product_class].RiskClass["Commodity"];
					auto except_one_rct = except_one_bucket_res.ProductClass[product_class].RiskClass["Commodity"];

					//@ risk class�� �����ϴ� row�� �� �������ϰ��, �״�� IM_SensiType�� Impact�� �ǵ��� �Ѵ�
					if (except_one_bucket.crif_table.size() == 0) {
						for (auto sensi : rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[sensi.first] - 0.0;
							else
								rct.sensi_bucket[sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[sensi.first] - 0.0;
						}
					}
					else {
						for (auto except_one_sensi : except_one_rct.IM_sensi) {
							if (bucket == 0)
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket["Residual"] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
							else
								rct.sensi_bucket[except_one_sensi.first].Impact_Bucket[to_string(bucket)] = rct.IM_sensi[except_one_sensi.first] - except_one_sensi.second;
						}
					}

				}
			}
		}

		return output3;
	}

	double AddOn_IM() {
		CRIFTable df_factorNotional = this->crif.sel_RiskType("Param_AddOnNotionalFactor", "Notional");
		CRIFTable df_fixed = this->crif.sel_RiskType("Param_AddOnFixedAmount");

		double AddOn = 0.0;
		vector<double> Temp_Vector1;
		vector<double> Temp_Vector2;
		if (mode == 0) {
			Temp_Vector1 = df_fixed.get_AmountUSD();
			AddOn = sum(Temp_Vector1);
		}
		else if (mode == 1) {
			Temp_Vector1 = df_fixed.get_Amount();
			AddOn = sum(Temp_Vector1);
		}

		vector<string> qualifier_list = this->qualifier_list(df_factorNotional);

		for (string qualifier : qualifier_list) {
			CRIFTable df_qualifier = df_factorNotional.sel_Qualifier(qualifier);
			CRIFTable df_factor = df_qualifier.sel_RiskType("Param_AddOnNotionalFactor");
			CRIFTable df_notional = df_qualifier.sel_RiskType("Notional");
			double factor, notional = 0.0;
			if (mode == 0) {
				Temp_Vector1 = df_factor.get_AmountUSD();
				factor = sum(Temp_Vector1) / 100.0;
				Temp_Vector2 = df_notional.get_AmountUSD();
				notional = sum(Temp_Vector2);
			}
			else if (mode == 1){
				Temp_Vector1 = df_factor.get_Amount();
				factor = sum(Temp_Vector1) / 100.0;
				Temp_Vector2 = df_notional.get_Amount();
				notional = sum(Temp_Vector2);
			}


			AddOn += factor * notional;
		}


		return AddOn;
	}


	//# Rates�� �ٸ� �����ڻ�� �ٸ��� risk class�� Risk_IRCurve, Risk_Inflation, Risk_XCcyBasis
	//# �� �����̰�, ��ȭ�� ���� ���� ������ ���̹Ƿ� ������ �Լ��� ����
	map<string, RiskClassTable> RatesDeltaMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;
		vector<string> rcl = this->Riskclass_list(crif);
		vector<string> gotRiskType;
		vector<string> Label;
		//# Rates�� ������ risk class�� �ش� �Լ����� ó���ϵ��� �ϴ� ��ġ
		if (find(begin(rcl), end(rcl), "Risk_IRCurve") == end(rcl)
			&& find(begin(rcl), end(rcl), "Risk_Inflation") == end(rcl)
			&& find(begin(rcl), end(rcl), "Risk_XCcyBasis") == end(rcl)) {
			return updates;
		}
		else {
			map<string, double> CR_dict;
			vector<double> K_list;
			vector<double> S_list;
			
			CRIFTable df = crif.sel_RiskType("Risk_IRCurve", "Risk_Inflation", "Risk_XCcyBasis");
			vector<string> currency_list = this->currency_list(df);
			for (string currency : currency_list) {

				vector<double> WS_list;
				vector<string> tenor_K;
				vector<string> index;

				//# ��ȭ�� CRIF
				auto df_currency = df.sel_Qualifier(currency);

				//# Risk_XCcyBasis�� CR ��� �� �ݿ����� �ʱ� ������ ���ܵ�
				auto df_CR = df_currency.drop_RiskType("Risk_XCcyBasis");

				//# Concentration Thresholds
				double T = _T("Rates", currency, -1, "Delta", Exchange_Rate);
				auto CR = this->CR(this->sum_sensitivities(df_CR, mode), T);
				CR_dict[currency] = CR;

				//# Global CRIF���� Rates risk class �� �����ϴ� class�� �����Ͽ� for loop
				gotRiskType = df_currency.sel_RiskType("Risk_IRCurve", "Risk_Inflation", "Risk_XCcyBasis").get_RiskType();
				auto Rates_riskClass = this->unique(gotRiskType);

				for (string risk_class : Rates_riskClass) {
					//# Risk class�� CRIF
					auto df_riskClass = df_currency.sel_RiskType(risk_class);

					//# Amount(or AmountUSD) Sum as List according to "mode"
					auto sensitivities = this->sum_sensitivities(df_riskClass, mode);

					if (risk_class == "Risk_Inflation") {
						auto RW = to_double(wnc_06_IR_RW_Others[0]);
						auto WS = RW * sensitivities * CR;
						WS_list.push_back(WS);

						//# tenor_K��� ����Ʈ�� �ؿ� Risk_IRCurve�� tenor�� �־��ְ�
						//# ���� Risk_Inflation�� 'Inf'��, Risk_XCcyBasis�� XCcy�� �־
						//# Phi / Rho �� Correlation �ҷ��ö� tenor_K �����Ͽ� �ݿ�
						tenor_K.push_back("Inf");
						index.push_back("Inf");
					}
					else if (risk_class == "Risk_XCcyBasis") {
						auto RW = to_double(wnc_06_IR_RW_Others[1]);
						auto WS = RW * sensitivities;
						WS_list.push_back(WS);
						tenor_K.push_back("XCcy");
						index.push_back("XCcy");
					}
					else if (risk_class == "Risk_IRCurve") {
						//# Mapping sensitivity to tenor k in a dict
						//# e.g. 3m: 10000
						map<string, map<string, double>> s_by_subcurve;

						//# CRIF �� �ݸ�Ŀ�� ����Ʈ Libor3m, OIS ��
						Label = df_riskClass.get_Label2();
						auto subcurve_list = this->unique(Label);
						for (auto subcurve : subcurve_list) {
							//# �ݸ�Ŀ�꺰 CRIF
							auto df_subcurve = df_riskClass.sel_Label2(subcurve);

							map<string, double> dict_s;
							//# for loop by tenor
							for (auto tenor : this->tenor_list(df_subcurve)) {
								//# Tenor�� CRIF
								auto df_tenor = df_subcurve.sel_Label1(tenor);

								//# Key: tenor, Value: delta
								dict_s[tenor] = this->sum_sensitivities(df_tenor, mode);

								//# Key: �ݸ�Ŀ��, Value: dict_s
								s_by_subcurve[subcurve] = dict_s;

								auto RW = _RW(risk_class, currency, tenor, -1);
								auto s = s_by_subcurve[subcurve][tenor];
								auto WS = RW * s * CR;
								WS_list.push_back(WS);
								tenor_K.push_back(tenor);
								index.push_back(subcurve);
							}
						}

					}

				}

				auto K = K_Delta("Rates", WS_list, vector<double>(), vector<string>(), tenor_K, index);
				K_list.push_back(K);

				auto S_b = max(min(sum(WS_list), K), -K);
				S_list.push_back(S_b);

			}


			vector<double> K_squared;
			for (auto k : K_list) {
				K_squared.push_back(k*k);
			}
			auto K_squared_sum = sum(K_squared);
			int n = currency_list.size();
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (i == j) {
						continue;
					}
					else {
						auto cur_b = currency_list[i];
						auto cur_c = currency_list[j];

						auto g = min(CR_dict[cur_b], CR_dict[cur_c]) / max(CR_dict[cur_b], CR_dict[cur_c]);
						double gamma;
						if (n > 1) {
							gamma = to_double(wnc_08_IR_Corr[3]);
						}
						else {
							gamma = 1.0;
						}

						auto S1 = S_list[i];
						auto S2 = S_list[j];

						K_squared_sum += gamma * S1 * S2 * g;
					}
				}
			}

			updates["Rates"].IM_sensi["Delta"] += sqrt(K_squared_sum);

			return updates;

		}


	}


	map<string, RiskClassTable> DeltaMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;
		double K_squared_sum;
		vector<string> temp_vector_str;
		auto rcl = this->Riskclass_list(crif);
		if (!isin(string("Risk_FX"), rcl) && !isin(string("Risk_CreditQ"), rcl) && !isin(string("Risk_CreditNonQ"), rcl) && !isin(string("Risk_Equity"), rcl) && !isin(string("Risk_Commodity"), rcl)) {
			return updates;
		}
		else {
			vector<string> allowed_riskClasses = { "Risk_FX","Risk_CreditQ","Risk_CreditNonQ","Risk_Equity","Risk_Commodity" };
			vector<string> riskClass_list;
			for (auto x : rcl) {
				if (isin(x, allowed_riskClasses)) {
					riskClass_list.push_back(x);
				}
			}

			for (string risk_class : riskClass_list) {
				double K_Res = 0;
				vector<double> K_list;
				vector<double> S_list;


				//# FX
				if (risk_class == "Risk_FX") {
					vector<double> WS_list;
					vector<double> CR_list;
					auto df_FX = crif.sel_RiskType(risk_class);
					temp_vector_str = df_FX.get_Qualifier();
					auto currency_list = this->unique(temp_vector_str);
					for (string currency : currency_list) {
						auto df_currency = df_FX.sel_Qualifier(currency);
						auto T = _T(risk_class, currency, -1, "Delta", Exchange_Rate);
						auto sensitivities = this->sum_sensitivities(df_currency, mode);
						auto CR = this->CR(sensitivities, T);
						CR_list.push_back(CR);
						double RW;

						auto FX_RW_list = _RW_FX(risk_class, "", "", -1);
						if (currency == "BRL") {
							RW = FX_RW_list[1];
						}
						else if (currency == this->calc_currency) {
							RW = 0;
						}
						else {
							RW = FX_RW_list[0];
						}

						WS_list.push_back(sensitivities * CR * RW);
					}

					auto K = K_Delta(risk_class, WS_list, CR_list, currency_list, vector<string>(), vector<string>());
					updates["FX"].IM_sensi["Delta"] += K;
				}
				//# CreditQ, CreditNonQ, Equity, Commodity
				else {
					auto df = crif.sel_RiskType(risk_class);
					auto bucket_list = this->bucket_list(df);


					for (int bucket : bucket_list) {
						CRIFTable df_bucket;

						if (bucket == 0) {
							for (auto row : df.crif_table) {
								if (row.RiskType == risk_class && row.Bucket == "Residual") {
									df_bucket.crif_table.push_back(row);
								}
							}
						}
						else {
							for (auto row : df.crif_table) {
								if (row.RiskType == risk_class && row.Bucket == to_string(bucket)) {
									df_bucket.crif_table.push_back(row);
								}
							}
						}

						//# Risk Weight
						auto RW = _RW(risk_class, "", "", bucket);

						//# Concentration Thresholds
						auto T = _T(risk_class, "", bucket, "Delta", Exchange_Rate);

						vector<double> WS_list;
						vector<double> CR_list;
						vector<string> index;


						auto qualifier_list = this->qualifier_list(df_bucket);

						for (auto qualifier : qualifier_list) {
							auto df_qualifier = df_bucket.sel_Qualifier(qualifier);

							//# Credit
							if (risk_class == "Risk_CreditQ" || risk_class == "Risk_CreditNonQ") {
								auto sensitivities_CR = this->sum_sensitivities(df_qualifier, mode);
								auto CR = max(1, sqrt(abs(sensitivities_CR) / T));
								temp_vector_str = df_qualifier.get_Label2();
								auto label2_list = this->unique(temp_vector_str);
								for (auto label2 : label2_list) {
									auto df_label2 = df_qualifier.sel_Label2(label2);

									for (auto tenor : this->tenor_list(df_qualifier)) {
										auto df_tenor = df_label2.sel_Label1(tenor);
										auto sensitivities = this->sum_sensitivities(df_tenor, mode);

										WS_list.push_back(RW * sensitivities * CR);
										CR_list.push_back(CR);

										if (bucket == 0) {
											index.push_back("Res");
										}
										else {
											if (risk_class == "Risk_CreditQ") {
												index.push_back(qualifier);
											}
											else if (risk_class == "Risk_CreditNonQ") {
												index.push_back(label2);
											}
										}
									}
								}
							}
				
							//# Equity, Commodity
							else if (risk_class == "Risk_Equity" || risk_class == "Risk_Commodity") {
								//auto delta = sum(df_qualifier.get_AmountUSD());
								auto sensitivities_EQCO = this->sum_sensitivities(df_qualifier, mode);
								auto CR = max(1, sqrt(abs(sensitivities_EQCO) / T));
								CR_list.push_back(CR);
								WS_list.push_back(RW * sensitivities_EQCO * CR);
							}
						}


						auto K = K_Delta(risk_class, WS_list, CR_list, bucket, vector<string>(), index);


						if (bucket == 0) {
							K_Res += K;
						}
						else {
							K_list.push_back(K);
							auto S_b = max(min(sum(WS_list), K), -K);
							S_list.push_back(S_b);
						}


					}

					vector<int> bucket_list_;
					for (auto x : bucket_list) {
						if (x != 0) {
							bucket_list_.push_back(x);
						}
					}
					bucket_list = bucket_list_;



					vector<double> K_sq;
					for (auto x : K_list) {
						K_sq.push_back(x*x);
					}
					K_squared_sum = sum(K_sq);
					int n = bucket_list.size();
					for (int i = 0; i < n; i++) {
						for (int j = 0; j < n; j++) {
							if (i == j) {
								continue;
							}
							else {
								auto bucket1 = bucket_list[i];
								auto bucket2 = bucket_list[j];
								double g;
								double gamma_;

								if (isin(risk_class, gv_Rates_list)) {
									//@ ���� �ڵ� ����
									/*
									g = min(CR_list) / max(CR_list);

									if (this->currency_list().size() > 1) {

									}
									*/
									cout << "UNREACHABLE" << endl;
									exit(1);
								}
								else if (isin(risk_class, gv_FX_list)) {
									g = 1;
									gamma_ = to_double(wnc_24_FX_Corr[4]);
								}
								else if (isin(risk_class, gv_CreditNonQ_list)) {
									g = 1;
									gamma_ = _gamma(risk_class, -1, -1);
								}
								else {
									g = 1;
									gamma_ = _gamma(risk_class, bucket1, bucket2);
								}

								auto S1 = S_list[i];
								auto S2 = S_list[j];
								K_squared_sum += gamma_ * S1 * S2 * g;
							}
						}
					}
				}




				if (isin(risk_class, gv_CreditQ_list)) {
					updates["CreditQ"].IM_sensi["Delta"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_CreditNonQ_list)) {
					updates["CreditNonQ"].IM_sensi["Delta"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_Equity_list)) {
					updates["Equity"].IM_sensi["Delta"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_Commodity_list)) {
					updates["Commodity"].IM_sensi["Delta"] += sqrt(K_squared_sum);
				}

			}
		}

		return updates;
	}

	map<string, RiskClassTable> RatesVegaMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;

		vector<double> K_list;
		map<string, double> S_dict;
		map<string, double> VCR_dict;

		vector<string> TempRiskClass;

		auto rcl = this->Riskclass_list(crif);
		vector<string> allowed_riskClasses = { "Risk_IRVol","Risk_InflationVol" };
		vector<string> riskClass_list;
		for (auto x : rcl) {
			if (isin(x, allowed_riskClasses)) {
				riskClass_list.push_back(x);
			}
		}


		if (!isin(string("Risk_IRVol"), rcl) && !isin(string("Risk_InflationVol"), rcl)) {
			return updates;
		}
		else {
			for (auto risk_class : riskClass_list) {
				double VRW = to_double(wnc_06_IR_RW_Others[3]);
				auto currency_list = this->currency_list(crif);

				for (auto currency : currency_list) {
					CRIFTable df_currency;
					for (auto& row : crif.crif_table) {
						if (isin(row.RiskType, allowed_riskClasses) && row.Qualifier == currency) {
							df_currency.crif_table.push_back(row);
						}
					}

					vector<double> VR;
					vector<string> index;
					auto sensitivities_CR = this->sum_sensitivities(df_currency, mode);

					auto VT = _T("Rates", currency, -1, "Vega", Exchange_Rate);
					auto VCR = max(1, sqrt(abs(sensitivities_CR) / VT));
					VCR_dict[currency] = VCR;
					TempRiskClass = df_currency.sel_RiskType("Risk_IRVol", "Risk_InflationVol").get_RiskType();
					auto Rates_riskClass = this->unique(TempRiskClass);
					for (auto risk_class : Rates_riskClass) {
						auto df_riskClass = df_currency.sel_RiskType(risk_class);

						auto tenor_list = this->tenor_list(df_riskClass);
						for (auto tenor : tenor_list) {
							auto df_tenor = df_riskClass.sel_Label1(tenor);
							auto sensitivities = this->sum_sensitivities(df_tenor, mode);

							VR.push_back(VRW * sensitivities * VCR);

							if (risk_class == "Risk_IRVol") {
								index.push_back(tenor);
							}
							else {
								index.push_back("Inf");
							}
						}
					}

					auto K = K_Vega("Rates", VR, vector<double>(), -1, index);
					K_list.push_back(K);

					auto S = max(min(sum(VR), K), -K);
					S_dict[currency] = S;
				}

				vector<double> K_squared;
				for (auto k : K_list) {
					K_squared.push_back(k*k);
				}
				auto K_squared_sum = sum(K_squared);
				int n = currency_list.size();
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						if (i == j) {
							continue;
						}
						else {
							auto cur_b = currency_list[i];
							auto cur_c = currency_list[j];

							auto g = min(VCR_dict[cur_b], VCR_dict[cur_c]) / max(VCR_dict[cur_b], VCR_dict[cur_c]);
							double gamma = to_double(wnc_08_IR_Corr[3]);



							K_squared_sum += gamma * S_dict[cur_b] * S_dict[cur_c] * g;
						}
					}
				}

				updates["Rates"].IM_sensi["Vega"] += sqrt(K_squared_sum);
				return updates; //@ ���� ���ڿ�
			}
		}

		cout << "UNREACHABLE" << endl;
		exit(1);
	}

	map<string, RiskClassTable> VegaMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;
		vector<string> allowed_riskClasses = { "Risk_CreditVol","Risk_CreditVolNonQ","Risk_EquityVol","Risk_CommodityVol","Risk_FXVol" };
		vector<string> riskClass_list;
		vector<string> temp_vector_str;
		for (auto x : this->Riskclass_list(crif)) {
			if (isin(x, allowed_riskClasses)) {
				riskClass_list.push_back(x);
			}
		}

		for (auto risk_class : riskClass_list) {

			//# Index by Bucket 
			double K_Res = 0;
			vector<double> K_list;
			vector<double> S_list;

			vector<string> credit = { "Risk_CreditVol","Risk_CreditVolNonQ" };
			vector<string> equity = { "Risk_EquityVol" };
			vector<string> commodity = { "Risk_CommodityVol" };
			vector<string> fx = { "Risk_FXVol" };

			CRIFTable TempCRIFTable;

			//# Skip risk_class not in the lists

			if (!isin(risk_class, append(append(append(credit, equity), commodity), fx))) {
				return updates;
			}
			else if (isin(risk_class, fx)) {
				vector<double> VR_list;
				vector<double> VCR_list;

				for (auto currency_pair : this->currencyPair_list()) {
					//# k: currency_pair

					vector<string> pair_list = { currency_pair, currency_pair.substr(3,3) + currency_pair.substr(0,3) };

					CRIFTable df;
					for (auto row : crif.crif_table) {
						if (row.RiskType == risk_class && isin(row.Qualifier, pair_list)) {
							df.crif_table.push_back(row);
						}
					}

					vector<double> FX_RW_list = _RW_FX(risk_class, "", "", -1);
					double RW;

					if (currency_pair.find("BRL") != string::npos) {
						RW = FX_RW_list[1];
					}
					else {
						RW = FX_RW_list[0];
					}


					auto sigma = RW * sqrt(365.0 / 14.0) / norm_ppf_99;
					auto HVR = FX_RW_list[2]; //# Historical Volatility Ratio
					auto VRW = FX_RW_list[3]; //# Vega Risk Weight

					double VT = _T(risk_class, currency_pair, -1, "Vega", Exchange_Rate);

					auto sensitivities = this->sum_sensitivities(df, mode);

					double VR_ik = HVR * sigma * sensitivities;
					auto VCR = max(1, sqrt(abs(VR_ik) / VT));
					VCR_list.push_back(VCR);

					auto VR_k = VRW * VR_ik * VCR;
					VR_list.push_back(VR_k);

				}

				updates["FX"].IM_sensi["Vega"] += K_Vega(risk_class, VR_list, VCR_list, -1, vector<string>());

			}
			//# Equity, Commodity, Credit
			else {
				TempCRIFTable = crif.sel_RiskType(risk_class);
				auto bucket_list = this->bucket_list(TempCRIFTable);

				for (int bucket : bucket_list) {
					CRIFTable df;

					if (bucket == 0) {
						for (auto row : crif.crif_table) {
							if (row.RiskType == risk_class && row.Bucket == "Residual") {
								df.crif_table.push_back(row);
							}
						}
					}
					else {
						for (auto row : crif.crif_table) {
							if (row.RiskType == risk_class && row.Bucket == to_string(bucket)) {
								df.crif_table.push_back(row);
							}
						}
					}

					//# Risk Weight
					auto RW = _RW(risk_class, "", "", bucket);

					//# Concentration Thresholds
					auto T = _T(risk_class, "", bucket, "Delta", Exchange_Rate);

					vector<double> VR;
					vector<double> VCR_list;
					vector<string> index;


					auto qualifier_list = this->qualifier_list(df);

					for (auto qualifier : qualifier_list) {
						auto df_qualifier = df.sel_Qualifier(qualifier);

						vector<double> VR_ik;
						auto RW = _RW(risk_class, "", "", bucket);
						auto sigma = RW * sqrt(365.0 / 14.0) / norm_ppf_99;

						double HVR; //# Historical Volatility Ratio
						double VRW; //# Vega Risk Weight

						if (isin(risk_class, equity)) {
							HVR = to_double(wnc_16_Equity_RW_Others[0]);

							if (bucket == 12) {
								VRW = to_double(wnc_16_Equity_RW_Others[2]);
							}
							else {
								VRW = to_double(wnc_16_Equity_RW_Others[1]);
							}
						}
						else if (isin(risk_class, commodity)) {
							HVR = to_double(wnc_20_Commodity_RW_Others[0]);
							VRW = to_double(wnc_20_Commodity_RW_Others[1]);
						}
						else if (isin(risk_class, credit)) {
							double VT = _T(risk_class, "", bucket, "Vega", Exchange_Rate);
							auto sensitivities_VT = this->sum_sensitivities(df_qualifier, mode);
							auto VCR = max(1, sqrt(abs(sensitivities_VT) / VT));

							temp_vector_str = df_qualifier.get_Label2();
							auto label2_list = this->unique(temp_vector_str);
							for (auto label2 : label2_list) {
								auto df_label2 = df_qualifier.sel_Label2(label2);

								for (auto tenor : this->tenor_list(df_qualifier)) {
									auto df_tenor = df_label2.sel_Label1(tenor);
									auto sensitivities = this->sum_sensitivities(df_tenor, mode);

									double VRW;

									if (risk_class == "Risk_CreditVol") {
										VRW = to_double(wnc_10_CreditQ_RW_Others[0]);
									}
									else if (risk_class == "Risk_CreditVolNonQ") {
										VRW = to_double(wnc_14_CreditNonQ_Corr[0]);
									}

									VR.push_back(VRW * sensitivities * VCR);
									VCR_list.push_back(VCR);

									if (bucket == 0) {
										index.push_back("Res");
									}
									else {
										if (risk_class == "Risk_CreditVol") {
											index.push_back(qualifier);
										}
										else if (risk_class == "Risk_CreditVolNonQ") {
											index.push_back(label2);
										}

									}
								}
							}
						}

						if (isin(risk_class, append(equity, commodity))) {
							auto sensitivities = this->sum_sensitivities(df_qualifier, mode);
							VR_ik.push_back(HVR * sigma * sensitivities);

							auto VR_i = sum(VR_ik);
							auto VT = _T(risk_class, "", bucket, "Vega", Exchange_Rate);
							auto VCR = max(1, sqrt(abs(VR_i) / VT));

							VCR_list.push_back(VCR);
							VR.push_back(VR_i * VRW * VCR);


						}
					}

					auto K = K_Vega(risk_class, VR, VCR_list, bucket, index);

					if (bucket == 0) {
						K_Res += K;
					}
					else {
						K_list.push_back(K);
						auto S = max(min(sum(VR), K), -K);
						S_list.push_back(S);
					}
				}

				vector<int> bucket_list_;
				for (auto x : bucket_list) {
					if (x != 0) {
						bucket_list_.push_back(x);
					}
				}
				bucket_list = bucket_list_;

				vector<double> K_squared;
				for (auto k : K_list) {
					K_squared.push_back(k*k);
				}
				auto K_squared_sum = sum(K_squared);
				int n = S_list.size();
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						if (i == j) {
							continue;
						}
						else {
							int bucket_b = bucket_list[i];
							int bucket_c = bucket_list[j];
							double gamma;


							if (risk_class == "Risk_CreditVolNonQ") {
								gamma = _gamma(risk_class, -1, -1);
							}
							else {
								gamma = _gamma(risk_class, bucket_b, bucket_c);
							}



							K_squared_sum += gamma * S_list[i] * S_list[j];
						}
					}
				}



				if (isin(risk_class, gv_CreditQ_list)) {
					updates["CreditQ"].IM_sensi["Vega"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_CreditNonQ_list)) {
					updates["CreditNonQ"].IM_sensi["Vega"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_Equity_list)) {
					updates["Equity"].IM_sensi["Vega"] += sqrt(K_squared_sum) + K_Res;
				}
				else if (isin(risk_class, gv_Commodity_list)) {
					updates["Commodity"].IM_sensi["Vega"] += sqrt(K_squared_sum) + K_Res;
				}

			}
		}


		return updates;
	}

	map<string, RiskClassTable> RatesCurvatureMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;

		auto rcl = this->Riskclass_list(crif);
		vector<string> allowed_riskClasses = { "Risk_IRVol","Risk_InflationVol" };
		vector<string> riskClass_list;
		vector<string> Temp_RiskType;
		vector<string> Temp_df_currency_label;
		for (auto x : rcl) {
			if (isin(x, allowed_riskClasses)) {
				riskClass_list.push_back(x);
			}
		}

		if (!isin(string("Risk_IRVol"), rcl) && !isin(string("Risk_InflationVol"), rcl)) {
			return updates;
		}
		else {
			for (auto risk_class : riskClass_list) {
				vector<double> K_list;
				vector<double> S_list;

				double K = 0;
				double CVR_sum = 0;
				double CVR_abs_sum = 0;

				auto currency_list = this->currency_list(crif);
				for (auto currency : currency_list) {

					CRIFTable df_currency;
					for (auto& row : crif.crif_table) {
						if (isin(row.RiskType, allowed_riskClasses) && row.Qualifier == currency) {
							df_currency.crif_table.push_back(row);
						}
					}

					Temp_RiskType = df_currency.sel_RiskType("Risk_IRVol", "Risk_InflationVol").get_RiskType();
					auto Rates_riskClass = this->unique(Temp_RiskType);
					vector<string> index;
					vector<double> CVR_ik;

					for (auto risk_class : Rates_riskClass) {
						auto df_riskClass = df_currency.sel_RiskType(risk_class);
						Temp_df_currency_label = df_riskClass.get_Label1();
						for (auto tenor : this->unique(Temp_df_currency_label)) {
							auto df_tenor = df_riskClass.sel_Label1(tenor);

							auto sensitivities = this->sum_sensitivities(df_tenor, mode);

							auto CVR = this->SF(tenor) * sensitivities;
							CVR_ik.push_back(CVR);
							CVR_sum += CVR;
							CVR_abs_sum += abs(CVR);

							if (risk_class == "Risk_IRVol") {
								index.push_back(tenor);
							}
							else {
								index.push_back("Inf");
							}
						}
					}

					auto K = K_Curvature("Rates", CVR_ik, -1, index);
					K_list.push_back(K);

					auto S = max(min(sum(CVR_ik), K), -K);
					S_list.push_back(S);

					// Bucket (Rates ������ currency) �� 1���� ��� ��ī��� ���ذ� ���� ó�� (CVR Aggregation ���� ����)
					if (currency_list.size() == 1) {
						updates["Rates"].IM_sensi["Curvature"] = K;
					}
				}

				// Bucket�� 1���� ���� ���� ����
				if (currency_list.size() == 1) {
					continue;
				}

				auto Theta = min(CVR_sum / CVR_abs_sum, 0);
				auto Lambda = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta) - Theta;

				vector<double> K_squared;
				for (auto k : K_list) {
					K_squared.push_back(k*k);
				}
				auto K_squared_sum = sum(K_squared);
				int n = S_list.size();
				for (int i = 0; i < n; i++) {
					for (int j = 0; j < n; j++) {
						if (i == j) {
							continue;
						}
						else {

							double gamma = to_double(wnc_08_IR_Corr[3]);

							K_squared_sum += S_list[i] * S_list[j] * (gamma * gamma);
						}
					}
				}

				auto HVR = to_double(wnc_06_IR_RW_Others[2]);
				updates["Rates"].IM_sensi["Curvature"] += max(CVR_sum + Lambda * sqrt(K_squared_sum), 0) / (HVR*HVR);
				return updates; //@ ���� ���ڿ�
			}
		}

		return updates;
	}

	map<string, RiskClassTable> CurvatureMargin(CRIFTable& crif) {
		map<string, RiskClassTable> updates;


		vector<int> bucket_list;

		vector<string> credit = { "Risk_CreditVol","Risk_CreditVolNonQ" };
		vector<string> equity = { "Risk_EquityVol" };
		vector<string> commodity = { "Risk_CommodityVol" };
		vector<string> fx = { "Risk_FXVol" };
		vector<string> TempLabel;


		CRIFTable TempRiskCRIFTable;
		vector<string> allowed_riskClasses = append(append(append(credit, equity), commodity), fx);
		vector<string> riskClass_list;
		for (auto x : this->Riskclass_list(crif)) {
			if (isin(x, allowed_riskClasses)) {
				riskClass_list.push_back(x);
			}
		}

		for (auto risk_class : allowed_riskClasses) {
			double K = 0;
			double K_Res = 0;
			vector<double> K_list;
			vector<double> S_list;

			double CVR_sum = 0;
			double CVR_sum_res = 0;
			double CVR_abs_sum = 0;
			double CVR_abs_sum_res = 0;

			auto df = crif.sel_RiskType(risk_class);

			double Theta;
			double Lambda;
			double Theta_res;
			double Lambda_res;

			//# Skip risk_class not in the lists
			if (!isin(risk_class, allowed_riskClasses)) {
				;
			}

			//# Equity, Commodity, Credit
			else if (isin(risk_class, append(append(credit, equity), commodity))) {
				TempRiskCRIFTable = crif.sel_RiskType(risk_class);
				bucket_list = this->bucket_list(TempRiskCRIFTable);

				for (int bucket : bucket_list) {
					CRIFTable df;
					if (bucket == 0) {
						for (auto row : crif.crif_table) {
							if (row.RiskType == risk_class && row.Bucket == "Residual") {
								df.crif_table.push_back(row);
							}
						}
					}
					else {
						for (auto row : crif.crif_table) {
							if (row.RiskType == risk_class && row.Bucket == to_string(bucket)) {
								df.crif_table.push_back(row);
							}
						}
					}

					vector<double> CVR_i;
					vector<double> VCR_list;
					vector<string> index;

					for (auto qualifier : this->qualifier_list(df)) {
						auto df_qualifier = df.sel_Qualifier(qualifier);

						auto tenor_list = df_qualifier.get_Label1();
						vector<double> vega_list;
						if (mode == 0) {
							vega_list = df_qualifier.get_AmountUSD();
						}
						else if (mode == 1) {
							vega_list = df_qualifier.get_Amount();
						}
						auto RW = _RW(risk_class, "", "", bucket);
						auto sigma = RW * sqrt(365.0 / 14.0) / norm_ppf_99;

						if (isin(risk_class, append(equity, commodity))) {
							//# No curvature margin for equity with bucket 12
							if (isin(risk_class, equity) && bucket == 12) {
								sigma = 0;
							}

							vector<double> CVR_ik;
							int n = tenor_list.size();
							for (int i = 0; i < n; i++) {
								CVR_ik.push_back(this->SF(tenor_list[i]) * sigma * vega_list[i]);

							}
							CVR_i.push_back(sum(CVR_ik));


						}
						else if (isin(risk_class, credit)) {
							TempLabel = df_qualifier.get_Label2();
							auto label2_list = this->unique(TempLabel);
							for (auto label2 : label2_list) {
								auto df_label2 = df_qualifier.sel_Label2(label2);

								for (auto tenor : this->tenor_list(df_qualifier)) {
									auto df_tenor = df_label2.sel_Label1(tenor);

									auto VRW = to_double(wnc_10_CreditQ_RW_Others[0]);
									auto sensitivities = this->sum_sensitivities(df_tenor, mode);

									if (bucket == 0) {
										index.push_back("Res");
									}
									else {
										if (risk_class == "Risk_CreditVol") {
											index.push_back(qualifier);
										}
										else if (risk_class == "Risk_CreditVolNonQ") {
											index.push_back(label2);
										}
									}

									CVR_i.push_back(this->SF(tenor) * sensitivities);
								}
							}
						}
					}

					auto K = K_Curvature(risk_class, CVR_i, bucket, index);


					//#  Residual bucket
					if (bucket == 0) {
						K_Res += K;
						CVR_sum_res += sum(CVR_i);
						vector<double> CVR_i_abs;
						for (auto x : CVR_i) {
							CVR_i_abs.push_back(abs(x));
						}
						CVR_abs_sum_res += sum(CVR_i_abs);
					}
					else {
						if (risk_class == "Risk_EquityVol" && bucket == 12) {
							;
						}
						else {
							K_list.push_back(K);
							auto S = max(min(sum(CVR_i), K), -K);
							S_list.push_back(S);
							CVR_sum += sum(CVR_i);
							vector<double> CVR_i_abs;
							for (auto x : CVR_i) {
								CVR_i_abs.push_back(abs(x));
							}
							CVR_abs_sum += sum(CVR_i_abs);
						}
					}

					// Bucket�� 1���ϰ�� ��ī��� ����(CVR�� ��ġ�� �ʰ� K�� ��������� ���)�� ���缭 ���
					if (bucket_list.size() == 1 && bucket == 0) {
						auto CurvatureMargin_NonRes = 0;
						auto CurvatureMargin_Res = K_Res;

						if (isin(risk_class, equity)) {
							updates["Equity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (isin(risk_class, commodity)) {
							updates["Commodity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (risk_class == "Risk_CreditVol") {
							updates["CreditQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (risk_class == "Risk_CreditVolNonQ") {
							updates["CreditNonQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
					}
					if (bucket_list.size() == 1 && bucket != 0) {
						auto CurvatureMargin_NonRes = K;
						auto CurvatureMargin_Res = 0;

						if (isin(risk_class, equity)) {
							updates["Equity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (isin(risk_class, commodity)) {
							updates["Commodity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (risk_class == "Risk_CreditVol") {
							updates["CreditQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
						else if (risk_class == "Risk_CreditVolNonQ") {
							updates["CreditNonQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
						}
					}

				}
				// Bucket�� 1���� ��� �ؿ��� CVR Aggregation�� �ϸ� �ȵǹǷ� ���� ���� ����
				if (bucket_list.size() == 1) {
					continue;
				}
			}

			//# FX
			else if (isin(risk_class, fx)) {
				vector<double> CVR_list;

				for (auto currency_pair : this->currencyPair_list()) {

					vector<string> pair_list = { currency_pair, currency_pair.substr(3,3) + currency_pair.substr(0,3) };

					CRIFTable df;
					for (auto row : crif.crif_table) {
						if (row.RiskType == risk_class && isin(row.Qualifier, pair_list)) {
							df.crif_table.push_back(row);
						}
					}

					vector<double> FX_RW_list = _RW_FX(risk_class, "", "", -1);
					double RW;
					double rho;

					if (currency_pair.find("BRL") != string::npos) {
						RW = FX_RW_list[1];
						rho = pow(to_double(wnc_24_FX_Corr[1]), 2);
					}
					else {
						RW = FX_RW_list[0];
						rho = pow(to_double(wnc_24_FX_Corr[0]), 2);
					}


					auto sigma = RW * sqrt(365.0 / 14.0) / norm_ppf_99;
					vector<double> vega_list;
					if (mode == 0) {
						vega_list = df.get_AmountUSD();
					}
					else if(mode == 1) {
						vega_list = df.get_Amount();
					}
					auto tenor_list = df.get_Label1();

					double CVR = 0;
					int n = vega_list.size();
					for (int i = 0; i < n; i++) {
						CVR += this->SF(tenor_list[i]) * sigma * vega_list[i];
					}
					CVR_list.push_back(CVR);


				}

				auto K = K_Curvature(risk_class, CVR_list, -1, vector<string>());
				K_list.push_back(K);

				for (auto x : CVR_list) {
					CVR_sum += x;
					CVR_abs_sum += abs(x);
				}

				auto Theta = min(CVR_sum / CVR_abs_sum, 0);
				auto Lambda = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta) - Theta;
			
				// Qualifier�� 1���϶� K ���� ��ü Curvature�μ� ��� (��ī��� ����)
				if (currencyPair_list().size() == 1) {
					updates["FX"].IM_sensi["Curvature"] += K;
				}
				else {
					updates["FX"].IM_sensi["Curvature"] += max(CVR_sum + Lambda * K, 0);
				}
				
			}

			if (isin(risk_class, fx)) {
				;
			}
			else if (risk_class == "Risk_EquityVol" && isin(12, bucket_list) && bucket_list.size() == 1) {
				;
			}
			else {
				//# Make Exceptions on Lambda & Theta for Residual bucket
				if (isin(0, this->unique(bucket_list)) && this->unique(bucket_list).size() > 1) {
					Theta = min(CVR_sum / CVR_abs_sum, 0);
					Lambda = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta) - Theta;

					Theta_res = min(CVR_sum_res / CVR_abs_sum_res, 0);
					Lambda_res = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta_res) - Theta_res;
				}
				else if (!isin(0, bucket_list)) {
					Theta = min(CVR_sum / CVR_abs_sum, 0);
					Lambda = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta) - Theta;

					Theta_res = 0;
					Lambda_res = 0;

				}
				else if (isin(0, this->unique(bucket_list)) && this->unique(bucket_list).size() == 1) {
					Theta = 0;
					Lambda = 0;

					Theta_res = min(CVR_sum_res / CVR_abs_sum_res, 0);
					Lambda_res = (norm_ppf_995 * norm_ppf_995 - 1) * (1 + Theta_res) - Theta_res;

				}

				vector<double> K_sq;
				for (auto x : K_list) {
					K_sq.push_back(x*x);
				}
				double K_squared = sum(K_sq);

				if (!isin(risk_class, fx)) {
					vector<int> bucket_list_;
					for (auto x : bucket_list) {
						if (x != 0) {
							bucket_list_.push_back(x);
						}
					}
					bucket_list = bucket_list_;


					int n = S_list.size();
					for (int i = 0; i < n; i++) {
						for (int j = 0; j < n; j++) {
							if (i == j) {
								continue;
							}
							else {

								if (isin(risk_class, append(append(equity, commodity), credit))) {

									int bucket_b = bucket_list[i];
									int bucket_c = bucket_list[j];
									double gamma;


									if (risk_class == "Risk_CreditVolNonQ") {
										gamma = _gamma(risk_class, -1, -1);
									}
									else {
										gamma = _gamma(risk_class, bucket_b, bucket_c);
									}



									K_squared += gamma * gamma * S_list[i] * S_list[j];
								}

							}

						}
					}
				}

				auto CurvatureMargin_NonRes = max(CVR_sum + Lambda * sqrt(K_squared), 0);
				auto CurvatureMargin_Res = max(CVR_sum_res + Lambda_res * K_Res, 0);
				
				if (isin(risk_class, equity)) {
					updates["Equity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
				}
				else if (isin(risk_class, commodity)) {
					updates["Commodity"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
				}
				else if (risk_class == "Risk_CreditVol") {
					updates["CreditQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
				}
				else if (risk_class == "Risk_CreditVolNonQ") {
					updates["CreditNonQ"].IM_sensi["Curvature"] += CurvatureMargin_NonRes + CurvatureMargin_Res;
				}
			}
		}





		return updates;
	}



	map<string, RiskClassTable> BaseCorrMargin(CRIFTable& crif) {
		auto df = crif.sel_RiskType("Risk_BaseCorr");

		map<string, RiskClassTable> updates;
		vector<double> WS_list;

		auto qualifier_list = this->qualifier_list(df);
		for (string qualifier : qualifier_list) {
			auto df_qualifier = df.sel_Qualifier(qualifier);
			double RW = to_double(wnc_10_CreditQ_RW_Others)[1];
			double sensitivities = this->sum_sensitivities(df_qualifier, mode);
			double WS = RW * sensitivities;

			WS_list.push_back(WS);

		}

		double BaseCorr = 0;
		int size = WS_list.size();


		for (int i = 0; i < size; i++) {
			for (int j = 0; j < size; j++) {
				double rho_;

				if (i == j || qualifier_list[i] == qualifier_list[j]) { //@ ���� �ڵ� ����
					rho_ = 1.0;
				}
				else {
					rho_ = _rho("Risk_BaseCorr", "", "", -1);
				}

				BaseCorr += WS_list[i] * WS_list[j] * rho_;
			}
		}



		updates["CreditQ"].IM_sensi["BaseCorr"] += sqrt(BaseCorr);

		return updates;
	}

};