#pragma once
#include "common.h"

struct bucketcmp {
	bool operator()(const string& a, const string& b) const {
		int x, y;
		bool x_int = false, y_int = false;

		try {
			x = to_int(a);
			x_int = true;
		}
		catch (...) {
			;
		}
		try {
			y = to_int(b);
			y_int = true;
		}
		catch (...) {
			;
		}

		if (x_int && y_int) {
			return x < y;
		}
		else if (x_int && !y_int) {
			return true;
		}
		else if (!x_int && y_int) {
			return false;
		}
		else {
			if (a.length() < b.length()) {
				return true;
			}
			else if (a.length() > b.length()) {
				return false;
			}
			else {
				return a < b;
			}
		}
	}
};

struct SensiType_Bucket {
	map<string, double, bucketcmp> IM_Bucket;
	map<string, double, bucketcmp> Impact_Bucket;
};

class RiskClassTable {
public:
	double IM_RiskClass = 0.0;
	double Impact_RiskClass = 0.0;
	map<string, double> IM_sensi;
	map<string, double> Impact_sensi;
	map<string, SensiType_Bucket> sensi_bucket;

	double sum() {
		double s = 0.0;
		for (auto a : IM_sensi) {
			s += a.second;
		}
		return s;
	}

	RiskClassTable() {
		IM_sensi["BaseCorr"] = 0.0;
		IM_sensi["Delta"] = 0.0;
		IM_sensi["Vega"] = 0.0;
		IM_sensi["Curvature"] = 0.0;
	}

	void print() {
		cout << std::fixed << std::setprecision(6) << IM_sensi["Delta"] << ", " << IM_sensi["Vega"] << ", " << IM_sensi["Curvature"] << ", " << IM_sensi["BaseCorr"]  << endl;
	}

	RiskClassTable operator + (RiskClassTable &obj) {

		RiskClassTable res;
		res.IM_sensi["BaseCorr"] = this->IM_sensi["BaseCorr"] + obj.IM_sensi["BaseCorr"];
		res.IM_sensi["Delta"] = this->IM_sensi["Delta"] + obj.IM_sensi["Delta"];
		res.IM_sensi["Vega"] = this->IM_sensi["Vega"] + obj.IM_sensi["Vega"];
		res.IM_sensi["Curvature"] = this->IM_sensi["Curvature"] + obj.IM_sensi["Curvature"];
		return res;
	}
};

class ProductClassTable {
public:
	double IM_ProductClass = 0.0;
	double Impact_ProductClass = 0.0;
	map<string, RiskClassTable> RiskClass;
};

class OutputTable {
public:
	double SIMM = 0.0;
	double AddOn = 0.0;
	bool AddOn_enabled = true;
	map<string, ProductClassTable> ProductClass;

	vector<vector<string>> export_string() {
		vector<vector<string>> ret;

		if (AddOn_enabled) {
			vector<string> head = { "Total", "Add-On", "Product Class", "IM_ProductClass", "Risk Class", "IM_RiskClass", "Sensitivity Type", "IM_SensiType" };
			ret.push_back(head);

			for (pair<string, ProductClassTable> product : this->ProductClass) {
				for (pair<string, RiskClassTable> risk : product.second.RiskClass) {
					for (pair<string, double> sensi : risk.second.IM_sensi) {
						vector<string> r = {
							to_string(this->SIMM),
							to_string(this->AddOn),
							product.first,
							to_string(product.second.IM_ProductClass),
							risk.first,
							to_string(risk.second.IM_RiskClass),
							sensi.first,
							to_string(sensi.second)
						};
						ret.push_back(r);
					}
				}
			}
		}
		else {
			vector<string> head = { "Total", "Product Class", "IM_ProductClass", "Risk Class", "IM_RiskClass", "Sensitivity Type", "IM_SensiType" };
			ret.push_back(head);

			for (pair<string, ProductClassTable> product : this->ProductClass) {
				for (pair<string, RiskClassTable> risk : product.second.RiskClass) {
					for (pair<string, double> sensi : risk.second.IM_sensi) {
						vector<string> r = {
							to_string(this->SIMM),
							product.first,
							to_string(product.second.IM_ProductClass),
							risk.first,
							to_string(risk.second.IM_RiskClass),
							sensi.first,
							to_string(sensi.second)
						};
						ret.push_back(r);
					}
				}
			}
		}


		return ret;
	}

	// Bucket�� ����� ���� �Լ�. Role ���� Secured �϶� 1, Pledgor�϶� -1 
	vector<vector<string>> export_string2(double Role) {
		vector<vector<string>> ret;

		if (AddOn_enabled) {
			vector<string> head = { "Total", "Add-On", "Product Class", "IM_ProductClass", "Risk Class", "IM_RiskClass", "Sensitivity Type", "IM_SensiType", "Bucket", "IM_Bucket" };
			ret.push_back(head);

			for (pair<string, ProductClassTable> product : this->ProductClass) {
				for (pair<string, RiskClassTable> risk : product.second.RiskClass) {
					for (pair<string, double> sensi : risk.second.IM_sensi) {
						if (sensi.first == "BaseCorr") {
							vector<string> r = {
							to_string(Role * (this->SIMM)),
							to_string(Role * (this->AddOn)),
							product.first,
							to_string(Role * product.second.IM_ProductClass),
							risk.first,
							to_string(Role * risk.second.IM_RiskClass),
							sensi.first,
							to_string(Role * sensi.second),
							"",
							to_string(Role * sensi.second)
							};
							ret.push_back(r);
							continue;
						}


						for (auto im_bucket : risk.second.sensi_bucket[sensi.first].IM_Bucket) {
							/*bool bucket_not_number = false;
							try {
								to_int(im_bucket.first);
							}
							catch (...) {
								bucket_not_number = true;
							}
							
							if (sensi.first == "Curvature" || sensi.first == "Vega") {
								if (bucket_not_number) {
									if (im_bucket.first.length() == 3) {
										continue;
									}
								}
							}

							if (sensi.first == "Delta") {
								if (bucket_not_number) {
									if (im_bucket.first.length() == 6) {
										continue;
									}
								}
							}*/

							if (im_bucket.second == 0.0) {
								continue;
							}
														
							vector<string> r = {
							to_string(Role * (this->SIMM)),
							to_string(Role * (this->AddOn)),
							product.first,
							to_string(Role * product.second.IM_ProductClass),
							risk.first,
							to_string(Role * risk.second.IM_RiskClass),
							sensi.first,
							to_string(Role * sensi.second),
							im_bucket.first,
							to_string(Role * im_bucket.second)
							};
							ret.push_back(r);
							
						}
						
					}
				}
			}
		}
		else {
			vector<string> head = { "Total",  "Product Class", "IM_ProductClass", "Risk Class", "IM_RiskClass", "Sensitivity Type", "IM_SensiType", "Bucket", "IM_Bucket" };
			ret.push_back(head);

			for (pair<string, ProductClassTable> product : this->ProductClass) {
				for (pair<string, RiskClassTable> risk : product.second.RiskClass) {
					for (pair<string, double> sensi : risk.second.IM_sensi) {
						if (sensi.first == "BaseCorr") {
							vector<string> r = {
							to_string(Role * this->SIMM),
							product.first,
							to_string(Role * product.second.IM_ProductClass),
							risk.first,
							to_string(Role * risk.second.IM_RiskClass),
							sensi.first,
							to_string(Role * sensi.second),
							"",
							to_string(Role * sensi.second)
							};
							ret.push_back(r);
							continue;
						}

						// ��� ����� 0�� Bucket�� ������� ����

						for (auto im_bucket : risk.second.sensi_bucket[sensi.first].IM_Bucket) {						

							if (im_bucket.second == 0.0) {
								continue;
							}
							
										
							vector<string> r = {
							to_string(Role * this->SIMM),
							product.first,
							to_string(Role * product.second.IM_ProductClass),
							risk.first,
							to_string(Role * risk.second.IM_RiskClass),
							sensi.first,
							to_string(Role * sensi.second),
							im_bucket.first,
							to_string(Role * im_bucket.second)
							};
							ret.push_back(r);
							
							
						}

					}
				}
			}
		}


		return ret;
	}

	// Impact�� ���߹������� ���������Ƿ� ���� Role�� ������
	vector<vector<string>> export_string3() {
		vector<vector<string>> ret;

		vector<string> head = { "Total", "Product Class", "Impact_ProductClass", "Risk Class", "Impact_RiskClass", "Sensitivity Type", "Impact_SensiType", "Bucket", "Impact_Bucket" };
		ret.push_back(head);

		for (pair<string, ProductClassTable> product : this->ProductClass) {
			for (pair<string, RiskClassTable> risk : product.second.RiskClass) {
				for (pair<string, double> sensi : risk.second.Impact_sensi) {
					if (sensi.first == "BaseCorr") {
						vector<string> r = {
						to_string(this->SIMM),
						product.first,
						to_string(product.second.Impact_ProductClass),
						risk.first,
						to_string(risk.second.Impact_RiskClass),
						sensi.first,
						to_string(sensi.second),
						"",
						to_string(sensi.second)
						};
						ret.push_back(r);
						continue;
					}

					for (auto impact_bucket : risk.second.sensi_bucket[sensi.first].Impact_Bucket) {
						
						
						bool bucket_not_number = false;
						try {
							to_int(impact_bucket.first);
						}
						catch (...) {
							bucket_not_number = true;
						}

						if (sensi.first == "Curvature" || sensi.first == "Vega") {
							if (bucket_not_number) {
								if (impact_bucket.first.length() == 3) {
									continue;
								}
							}
						}

						if (sensi.first == "Delta") {
							if (bucket_not_number) {
								if (impact_bucket.first.length() == 6) {
									continue;
								}
							}
						}
						else {
							if (impact_bucket.second == 0.0) {
								continue;
							}
						}
						
						vector<string> r = {
						to_string(this->SIMM),
						product.first,
						to_string(product.second.Impact_ProductClass),
						risk.first,
						to_string(risk.second.Impact_RiskClass),
						sensi.first,
						to_string(sensi.second),
						impact_bucket.first,
						to_string(impact_bucket.second)
						};
						ret.push_back(r);
						
						
					}

				}
			}
		}



		return ret;
	}


};