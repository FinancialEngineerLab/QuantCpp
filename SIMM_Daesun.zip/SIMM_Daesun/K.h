#pragma once
#include "common.h"

double K_Delta(string risk_class, vector<double> WS_list, vector<double> CR_list, vector<string> bucket, vector<string> tenor, vector<string> index) {
	
	vector<double> WS_sq;
	vector<string> risk_class_list;
	for (auto w : WS_list) {
		WS_sq.push_back(w*w);
	}
	auto K = sum(WS_sq);
	int n = WS_list.size();
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (i == j) {
				continue;
			}
			else {
				double phi;
				double rho_;
				double f;

				//# Rates
				if (risk_class == "Rates") {
					if (index[i] == index[j]) {
						phi = 1;
					}
					else if (index[i] == "XCcy" || index[j] == "XCcy") {
						phi = to_double(wnc_08_IR_Corr[2]);
					}
					else if (index[i] == "Inf" || index[j] == "Inf") {
						phi = to_double(wnc_08_IR_Corr[1]);
					}
					else {
						phi = to_double(wnc_08_IR_Corr[0]);
					}

					vector<string> x({ "Inf", "XCcy" });

					if (!isin(index[i], x) && !isin(index[j], x)) {
						rho_ = _rho("Risk_IRCurve", tenor[i], tenor[j], -1);
					}
					else {
						rho_ = 1;
					}
				}
				//# Credit
				else if (isin(risk_class, append(gv_CreditQ_list, gv_CreditNonQ_list))) {
					rho_ = _rho(risk_class, index[i], index[j], -1);
				}
				//# Equity, Commodity, FX
				else {
					if (isin(risk_class, append(gv_Equity_list, gv_Commodity_list))) {
						cout << "UNREACHABLE" << endl;
					}
					else if (isin(risk_class, gv_FX_list)) {
						auto cur1 = bucket[i];
						auto cur2 = bucket[j];

						if ((cur1 == "BRL" && cur2 != "BRL") || (cur1 != "BRL" && cur2 != "BRL")) {
							rho_ = to_double(wnc_24_FX_Corr[1]);
						}
						else {
							rho_ = to_double(wnc_24_FX_Corr[0]);
						}
					}
				}

				if (risk_class == "Rates") {
					f = 1;
				}
				else {
					f = min(CR_list[i], CR_list[j]) / max(CR_list[i], CR_list[j]);
					phi = 1;
				}

				K += rho_ * WS_list[i] * WS_list[j] * phi * f;

			}
		}
	}

	return sqrt(K);
}
double K_Delta(string risk_class, vector<double> WS_list, vector<double> CR_list, int bucket, vector<string> tenor, vector<string> index) {

	vector<double> WS_sq;
	for (auto w : WS_list) {
		WS_sq.push_back(w*w);
	}
	auto K = sum(WS_sq);
	int n = WS_list.size();
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (i == j) {
				continue;
			}
			else {
				double phi;
				double rho_;
				double f;

				//# Rates
				if (risk_class == "Rates") {
					if (index[i] == index[j]) {
						phi = 1;
					}
					else if (index[i] == "XCcy" || index[j] == "XCcy") {
						phi = to_double(wnc_08_IR_Corr[2]);
					}
					else if (index[i] == "Inf" || index[j] == "Inf") {
						phi = to_double(wnc_08_IR_Corr[1]);
					}
					else {
						phi = to_double(wnc_08_IR_Corr[0]);
					}

					vector<string> x({ "Inf", "XCcy" });

					if (!isin(index[i], x) && !isin(index[j], x)) {
						rho_ = _rho("Risk_IRCurve", tenor[i], tenor[j], -1);
					}
					else {
						rho_ = 1;
					}
				}
				//# Credit
				else if (isin(risk_class, append(gv_CreditQ_list, gv_CreditNonQ_list))) {
					rho_ = _rho(risk_class, index[i], index[j], -1);
				}
				//# Equity, Commodity, FX
				else {
					if (isin(risk_class, append(gv_Equity_list, gv_Commodity_list))) {
						rho_ = _rho(risk_class, "", "", bucket);
					}
					else if (isin(risk_class, gv_FX_list)) {
						cout << "UNREACHABLE" << endl;
					}
				}

				if (risk_class == "Rates") {
					f = 1;
				}
				else {
					f = min(CR_list[i], CR_list[j]) / max(CR_list[i], CR_list[j]);
					phi = 1;
				}

				K += rho_ * WS_list[i] * WS_list[j] * phi * f;

			}
		}
	}

	return sqrt(K);
}

double K_Vega(string risk_class, vector<double> VR, vector<double> VCR, int bucket, vector<string> index) {
	//# index�� ''�̸� �ؿ� ���� �ȵ��� ������, '' x len���� ���� ����
	if (index.size() == 0) {
		for (auto& x : VR) {
			index.push_back("");
		}
	}
	vector<double> VR_sq;
	for (auto v : VR) {
		VR_sq.push_back(v*v);
	}
	double K = sum(VR_sq);
	int n = VR.size();

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {


			if (i == j) {
				continue;
			}
			else {
				double rho;
				if (risk_class == "Rates") {
					if (index[i] == "Inf" && index[j] == "Inf") {
						rho = 1;
					}
					else if (index[i] == "Inf" || index[j] == "Inf") {
						rho = to_double(wnc_08_IR_Corr[1]);
					}
					else {
						rho = _rho("Risk_IRVol", index[i], index[j], -1);
					}
				}
				else if (isin(risk_class, append(gv_Equity_list, gv_Commodity_list))) {
					rho = _rho(risk_class, "", "", bucket);
				}
				else if (isin(risk_class, gv_FX_list)) {
					rho = to_double(wnc_24_FX_Corr[0]);
				}
				else if (isin(risk_class, vector<string>({ "Risk_CreditVol", "Risk_CreditVolNonQ" }))) {
					rho = _rho(risk_class, index[i], index[j], -1);
				}

				double f;

				if (risk_class == "Rates") {
					f = 1;
				}
				else {
					f = min(VCR[i], VCR[j]) / max(VCR[i], VCR[j]);
				}

				K += f * rho * VR[i] * VR[j];
			}
		}
	}

	return sqrt(K);
}

double K_Curvature(string risk_class, vector<double> CVR_list, int bucket, vector<string> index) {

	vector<double> K_sq;
	for (auto x : CVR_list) {
		K_sq.push_back(x*x);
	}
	double K = sum(K_sq);
	int n = CVR_list.size();
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (i == j) {
				continue;
			}
			else {
				double rho;
				if (risk_class == "Rates") {
					if (index[i] == "Inf" && index[j] == "Inf") {
						rho = 1;
					}
					else if (index[i] == "Inf" || index[j] == "Inf") {
						rho = to_double(wnc_08_IR_Corr[1]);
					}
					else {
						rho = _rho("Risk_IRVol", index[i], index[j], -1);
					}
				}
				else if (isin(risk_class, append(gv_Equity_list, gv_Commodity_list))) {
					rho = _rho(risk_class, "", "", bucket);
				}
				else if (isin(risk_class, gv_FX_list)) {
					rho = to_double(wnc_24_FX_Corr[0]);
				}
				else if (isin(risk_class, vector<string>({ "Risk_CreditVol", "Risk_CreditVolNonQ" }))) {
					rho = _rho(risk_class, index[i], index[j], -1);
				}


				K += rho * rho * CVR_list[i] * CVR_list[j];
			}
		}
	}


	return sqrt(K);
}
