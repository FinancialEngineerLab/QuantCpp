#pragma once
#include "common.h"
#include "csv.h"
#include "Weights_Corr_Param.h"


//# Concentration Threshold �� �ش� bucket ����
vector<int> bucket_list_CT(vector<vector<string>>& df, int i) {

	vector<string> a = sel_column(df, i);
	vector<int> b;

	for (string x : a) {
		if (x != "") {
			b.push_back(to_int(x));
		}
	}

	return b;
}

double _RW(string risk_class, string currency, string tenor, int bucket) {
	if (isin(risk_class, gv_Rates_list)) {
		//#Regular Volatility
		if (isin(currency, wnc_01_RegVol_Currency_Bucket)) {
			auto& rw = wnc_03_IR_RW_Regular;
			auto idx = loc(tenor, rw[0]);
			return to_double(rw[1][idx]);
		}
		//#Low Volatility
		else if (isin(currency, wnc_02_LowVol_Currency_Bucket)) {
			auto& rw = wnc_04_IR_RW_LowVol;
			auto idx = loc(tenor, rw[0]);
			return to_double(rw[1][idx]);
		}
		//#High Volatility
		else {
			auto& rw = wnc_05_IR_RW_HighVol;
			auto idx = loc(tenor, rw[0]);
			return to_double(rw[1][idx]);
		}
	}
	else if (isin(risk_class, gv_CreditQ_list)) {
		auto& rw = wnc_09_CreditQ_RW;
		return to_double(rw[1][bucket]);
	}
	else if (isin(risk_class, gv_CreditNonQ_list)) {
		auto& rw = wnc_13_CreditNonQ_RW;
		return to_double(rw[1][bucket]);
	}
	else if (isin(risk_class, gv_Equity_list)) {
		auto& rw = wnc_15_Equity_RW;
		return to_double(rw[1][bucket]);
	}
	else if (isin(risk_class, gv_Commodity_list)) {
		auto& rw = wnc_19_Commodity_RW;
		return to_double(rw[1][bucket - 1]);
	}
	/* type mismatch, moved to RW_FX
	else if (isin(risk_class, gv_FX_list)) {
		auto& rw = wnc_23_FX_RW;
		return to_double(rw);
	}
	*/
	else {
		cout << "UNREACHABLE" << endl;
		exit(1);
	}
}
vector<double> _RW_FX(string risk_class, string currency, string tenor, int bucket) {
	if (isin(risk_class, gv_FX_list)) {
		auto& rw = wnc_23_FX_RW;
		return to_double(rw);
	}
	else {
		cout << "UNREACHABLE" << endl;
		exit(1);
	}
}

double _rho(string risk_class, string index1, string index2, int bucket) {

	if (isin(risk_class, gv_Rates_list)) {
		auto df_rho = to_double(wnc_07_IR_rho);

		int idx1 = loc(index1, gv_tenor_list);
		int idx2 = loc(index2, gv_tenor_list);

		return df_rho[idx1][idx2];
	}
	else if (isin(risk_class, gv_CreditQ_list)) {
		vector<double> rho_list = to_double(wnc_11_CreditQ_rho);

		if (risk_class == "Risk_BaseCorr") {
			return rho_list[3];
		}
		else if (index1 == "Res" || index2 == "Res") {
			return rho_list[2];
		}
		else if (index1 == index2) {
			return rho_list[0];
		}
		else {
			return rho_list[1];
		}
	}
	else if (isin(risk_class, gv_CreditNonQ_list)) {
		vector<double> rho_list = to_double(wnc_14_CreditNonQ_Corr);
		if (index1 == "Res" || index2 == "Res") {
			return rho_list[3];
		}
		else if (index1 == index2) {
			return rho_list[1];
		}
		else {
			return rho_list[2];
		}
	}
	else if (isin(risk_class, gv_Equity_list)) {
		vector<double> rho_list = to_double(wnc_17_Equity_rho);
		return rho_list[bucket];
	}
	else if (isin(risk_class, gv_Commodity_list)) {
		vector<double> rho_list = to_double(wnc_21_Commodity_rho);
		return rho_list[bucket - 1];
	}

	//not reachable
	cout << "unreachable code : rho" << endl;
	exit(1);

}


double _gamma(string risk_class, int bucket1, int bucket2) {
	if (isin(risk_class, gv_CreditQ_list)) {
		return to_double(wnc_12_CreditQ_gamma[bucket1 - 1][bucket2 - 1]);
	}
	else if (isin(risk_class, gv_CreditNonQ_list)) {
		return to_double(wnc_14_CreditNonQ_Corr[4]);
	}
	else if (isin(risk_class, gv_Equity_list)) {
		return to_double(wnc_18_Equity_gamma[bucket1 - 1][bucket2 - 1]);
	}
	else if (isin(risk_class, gv_Commodity_list)) {
		return to_double(wnc_22_Commodity_gamma[bucket1 - 1][bucket2 - 1]);
	}
	else {
		cout << "UNREACHABLE" << endl;
		exit(1);
	}
}

double _T(string risk_class, string currency, int bucket, string greek, double Exchange_Rate) {
	double T = 0.0;

	if (greek == "Delta") {
		if (risk_class == "Rates") {

			vector<vector<string>> IR_Delta_CT = wnc_25_IR_Delta_CT;

			//# Concentration Thresholds List
			//# 6.9, 230, 30, 150
			vector<double> CT_list = to_double(IR_Delta_CT[0]);

			//# USD, EUR, GBP
			vector<string> regVol_well = sel_column(IR_Delta_CT, 1);
			//# AUD, CAD, CHF, ...
			vector<string> regVol_less = sel_column(IR_Delta_CT, 2);
			//# JPY
			vector<string> lowVol = sel_column(IR_Delta_CT, 3);

			//#Low Volatility
			if (isin(currency, regVol_well)) {
				T = CT_list[1];
			}
			//#Regular Volatility, less well-traded
			else if (isin(currency, regVol_less)) {
				T = CT_list[2];
			}
			//#Regular volatility, well-traded
			else if (isin(currency, lowVol)) {
				T = CT_list[3];
			}
			//#High Volatility
			else {
				T = CT_list[0];
			}
		}
		else if (isin(risk_class, gv_CreditQ_list)) {
			vector<vector<string>> CR_Delta_CT = wnc_26_CR_Delta_CT;
			vector<string> CT_list = vector<string>(CR_Delta_CT[0].begin(), CR_Delta_CT[0].begin() + 3);

			auto sovereign_ctrBanks = bucket_list_CT(CR_Delta_CT, 0);
			auto corp_entities = bucket_list_CT(CR_Delta_CT, 1);
			auto residuals = bucket_list_CT(CR_Delta_CT, 2);

			if (isin(bucket, sovereign_ctrBanks)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, corp_entities)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, residuals)) {
				T = to_double(CT_list[2]);
			}


		}
		else if (isin(risk_class, gv_CreditNonQ_list)) {
			vector<vector<string>> CR_Delta_CT = wnc_26_CR_Delta_CT;
			vector<string> CT_list = vector<string>(CR_Delta_CT[0].begin() + 3, CR_Delta_CT[0].end());

			auto IG = bucket_list_CT(CR_Delta_CT, 3);
			auto HY_NonRated = bucket_list_CT(CR_Delta_CT, 4);
			auto residuals = bucket_list_CT(CR_Delta_CT, 5);


			if (isin(bucket, IG)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, HY_NonRated)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, residuals)) {
				T = to_double(CT_list[2]);
			}
		}
		else if (isin(risk_class, gv_Equity_list)) {
			auto EQ_Delta_CT = wnc_27_EQ_Delta_CT;
			auto CT_list = EQ_Delta_CT[0];

			auto emerging_large = bucket_list_CT(EQ_Delta_CT, 0);
			auto developed_large = bucket_list_CT(EQ_Delta_CT, 1);
			auto emerging_small = bucket_list_CT(EQ_Delta_CT, 2);
			auto developed_small = bucket_list_CT(EQ_Delta_CT, 3);
			auto index_funds = bucket_list_CT(EQ_Delta_CT, 4);
			auto residuals = bucket_list_CT(EQ_Delta_CT, 5);

			if (isin(bucket, emerging_large)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, developed_large)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, emerging_small)) {
				T = to_double(CT_list[2]);
			}
			else if (isin(bucket, developed_small)) {
				T = to_double(CT_list[3]);
			}
			else if (isin(bucket, index_funds)) {
				T = to_double(CT_list[4]);
			}
			else if (isin(bucket, residuals)) {
				T = to_double(CT_list[5]);
			}

		}
		else if (isin(risk_class, gv_Commodity_list)) {
			auto CO_Delta_CT = wnc_28_CO_Delta_CT;
			auto CT_list = CO_Delta_CT[0];


			auto coal = bucket_list_CT(CO_Delta_CT, 0);
			auto crude_oil = bucket_list_CT(CO_Delta_CT, 1);
			auto oil_fractions = bucket_list_CT(CO_Delta_CT, 2);
			auto natural_gas = bucket_list_CT(CO_Delta_CT, 3);
			auto power = bucket_list_CT(CO_Delta_CT, 4);
			auto freight = bucket_list_CT(CO_Delta_CT, 5);
			auto base_metals = bucket_list_CT(CO_Delta_CT, 6);
			auto precious_metals = bucket_list_CT(CO_Delta_CT, 7);
			auto agricultural = bucket_list_CT(CO_Delta_CT, 8);
			auto other = bucket_list_CT(CO_Delta_CT, 9);
			auto indices = bucket_list_CT(CO_Delta_CT, 10);

			if (isin(bucket, coal)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, crude_oil)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, oil_fractions)) {
				T = to_double(CT_list[2]);
			}
			else if (isin(bucket, natural_gas)) {
				T = to_double(CT_list[3]);
			}
			else if (isin(bucket, power)) {
				T = to_double(CT_list[4]);
			}
			else if (isin(bucket, freight)) {
				T = to_double(CT_list[5]);
			}
			else if (isin(bucket, base_metals)) {
				T = to_double(CT_list[6]);
			}
			else if (isin(bucket, precious_metals)) {
				T = to_double(CT_list[7]);
			}
			else if (isin(bucket, agricultural)) {
				T = to_double(CT_list[8]);
			}
			else if (isin(bucket, other)) {
				T = to_double(CT_list[9]);
			}
			else if (isin(bucket, indices)) {
				T = to_double(CT_list[10]);
			}
		}
		else if (isin(risk_class, gv_FX_list)) {
			auto FX_Delta_CT = wnc_29_FX_Delta_CT;
			auto CT_list = FX_Delta_CT[0];

			auto category1 = sel_column(FX_Delta_CT, 0);
			auto category2 = sel_column(FX_Delta_CT, 1);

			if (isin(currency, category1)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(currency, category2)) {
				T = to_double(CT_list[1]);
			}
			else {
				T = to_double(CT_list[2]);
			}

		}
	}
	else if (greek == "Vega") {
		if (risk_class == "Rates") {
			vector<vector<string>> IR_Vega_CT = wnc_30_IR_Vega_CT;

			vector<double> CT_list = to_double(IR_Vega_CT[0]);


			vector<string> regVol_well = sel_column(IR_Vega_CT, 1);
			vector<string> regVol_less = sel_column(IR_Vega_CT, 2);
			vector<string> lowVol = sel_column(IR_Vega_CT, 3);

			if (isin(currency, regVol_well)) {
				T = CT_list[1];
			}
			else if (isin(currency, regVol_less)) {
				T = CT_list[2];
			}
			else if (isin(currency, lowVol)) {
				T = CT_list[3];
			}
			else {
				T = CT_list[0];
			}
		}
		else if (isin(risk_class, gv_CreditQ_list)) {
			auto CR_Vega_CT = wnc_31_CR_Vega_CT;
			T = to_double(CR_Vega_CT[0]);

		}
		else if (isin(risk_class, gv_CreditNonQ_list)) {
			auto CR_Vega_CT = wnc_31_CR_Vega_CT;
			T = to_double(CR_Vega_CT[1]);
		}
		else if (isin(risk_class, gv_Equity_list)) {
			auto EQ_Vega_CT = wnc_32_EQ_Vega_CT;
			auto CT_list = EQ_Vega_CT[0];

			auto emerging_large = bucket_list_CT(EQ_Vega_CT, 0);
			auto developed_large = bucket_list_CT(EQ_Vega_CT, 1);
			auto emerging_small = bucket_list_CT(EQ_Vega_CT, 2);
			auto developed_small = bucket_list_CT(EQ_Vega_CT, 3);
			auto index_funds = bucket_list_CT(EQ_Vega_CT, 4);
			auto residuals = bucket_list_CT(EQ_Vega_CT, 5);

			if (isin(bucket, emerging_large)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, developed_large)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, emerging_small)) {
				T = to_double(CT_list[2]);
			}
			else if (isin(bucket, developed_small)) {
				T = to_double(CT_list[3]);
			}
			else if (isin(bucket, index_funds)) {
				T = to_double(CT_list[4]);
			}
			else if (isin(bucket, residuals)) {
				T = to_double(CT_list[5]);
			}
		}
		else if (isin(risk_class, gv_Commodity_list)) {
			auto CO_Vega_CT = wnc_33_CO_Vega_CT;
			auto CT_list = CO_Vega_CT[0];


			auto coal = bucket_list_CT(CO_Vega_CT, 0);
			auto crude_oil = bucket_list_CT(CO_Vega_CT, 1);
			auto oil_fractions = bucket_list_CT(CO_Vega_CT, 2);
			auto natural_gas = bucket_list_CT(CO_Vega_CT, 3);
			auto power = bucket_list_CT(CO_Vega_CT, 4);
			auto freight = bucket_list_CT(CO_Vega_CT, 5);
			auto base_metals = bucket_list_CT(CO_Vega_CT, 6);
			auto precious_metals = bucket_list_CT(CO_Vega_CT, 7);
			auto agricultural = bucket_list_CT(CO_Vega_CT, 8);
			auto other = bucket_list_CT(CO_Vega_CT, 9);
			auto indices = bucket_list_CT(CO_Vega_CT, 10);

			if (isin(bucket, coal)) {
				T = to_double(CT_list[0]);
			}
			else if (isin(bucket, crude_oil)) {
				T = to_double(CT_list[1]);
			}
			else if (isin(bucket, oil_fractions)) {
				T = to_double(CT_list[2]);
			}
			else if (isin(bucket, natural_gas)) {
				T = to_double(CT_list[3]);
			}
			else if (isin(bucket, power)) {
				T = to_double(CT_list[4]);
			}
			else if (isin(bucket, freight)) {
				T = to_double(CT_list[5]);
			}
			else if (isin(bucket, base_metals)) {
				T = to_double(CT_list[6]);
			}
			else if (isin(bucket, precious_metals)) {
				T = to_double(CT_list[7]);
			}
			else if (isin(bucket, agricultural)) {
				T = to_double(CT_list[8]);
			}
			else if (isin(bucket, other)) {
				T = to_double(CT_list[9]);
			}
			else if (isin(bucket, indices)) {
				T = to_double(CT_list[10]);
			}
		}
		else if (isin(risk_class, gv_FX_list)) {
			string cur1 = currency.substr(0, 3);
			string cur2 = currency.substr(3, 3);


			auto FX_Delta_CT = wnc_29_FX_Delta_CT;
			auto Delta_CT_list = FX_Delta_CT[0];
			auto CT_list = wnc_34_FX_Vega_CT;


			auto cat1 = sel_column(FX_Delta_CT, 0);
			auto cat2 = sel_column(FX_Delta_CT, 1);
			auto cat = append(cat1, cat2);

			if (isin(cur1, cat1) && isin(cur2, cat1)) {
				T = to_double(CT_list[0]);
			}
			else if ((isin(cur1, cat1) && isin(cur2, cat2)) || (isin(cur1, cat2) && isin(cur2, cat1))) {
				T = to_double(CT_list[1]);
			}
			else if ((isin(cur1, cat1) && !isin(cur2, cat)) || (!isin(cur1, cat) && isin(cur2, cat1))) {
				T = to_double(CT_list[2]);
			}
			else if (isin(cur1, cat2) && isin(cur2, cat2)) {
				T = to_double(CT_list[3]);
			}
			else if ((isin(cur1, cat2) && !isin(cur2, cat)) || (!isin(cur1, cat) && isin(cur2, cat2))) {
				T = to_double(CT_list[4]);
			}
			else if (!isin(cur1, cat) && !isin(cur2, cat)) {
				T = to_double(CT_list[5]);
			}
			else {
				cout << "UNREACHABLE" << endl;
			}


		}
	}
	// ���� T�� USD �����̹Ƿ� ȯ���� ������ Threshold ����
	return T * 1000000 * Exchange_Rate;
}


double _psi(string risk_class1, string risk_class2) {
	vector<string> risk_class_list_file = { "Rates", "CreditQ", "CreditNonQ", "Equity", "Commodity", "FX" };



	int idx1 = loc(risk_class1, risk_class_list_file);
	int idx2 = loc(risk_class2, risk_class_list_file);



	auto w = to_double(wnc_35_RiskClasses_Corr);
	return w[idx1][idx2];
}




