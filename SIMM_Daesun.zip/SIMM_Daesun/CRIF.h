#pragma once
#include "common.h"

struct CRIFRow {
	string PortfolioID;
	string TradeID;
	string CollectRegulations;
	string ProductClass;
	string RiskType;
	string Qualifier;
	string Bucket;
	string Label1;
	string Label2;
	double Amount;
	string AmountCurrency;
	double AmountUSD;

	//@ output1
	double IM = 0.0;
	double Impact = 0.0;
};

class CRIFTable
{
public:
	vector<CRIFRow> crif_table;
	//@ ��ǲ �÷��� ������ �ٲ�ų� �÷��� �߰��Ǿ �������� idx �ν�
	int idx_PortfolioID;
	int idx_TradeID;
	int idx_CollectRegulations;
	int idx_ProductClass;
	int idx_RiskType;
	int idx_Qualifier;
	int idx_Bucket;
	int idx_Label1;
	int idx_Label2;
	int idx_Amount;
	int idx_AmountCurrency;
	int idx_AmountUSD;

	//@ output1
	vector<vector<string>> export_string() {
		vector<vector<string>> ret;

		vector<string> head = {
			"PortfolioID",
			"TradeID",
			"CollectRegulations",
			"ProductClass",
			"RiskType",
			"Qualifier",
			"Bucket",
			"Label1",
			"Label2",
			"Amount",
			"AmountCurrency",
			"AmountUSD",
			"IM",
			"Impact",
		};
		ret.push_back(head);

		for (auto r : crif_table) {

			vector<string> a = {
				r.PortfolioID,
				r.TradeID,
				r.CollectRegulations,
				r.ProductClass,
				r.RiskType,
				r.Qualifier,
				r.Bucket,
				r.Label1,
				r.Label2,
				to_string(r.Amount),
				r.AmountCurrency,
				to_string(r.AmountUSD),
				to_string(r.IM),
				to_string(r.Impact),
			};


			ret.push_back(a);
		}


		return ret;
	}

	void input_data_S(vector<vector<string>>& crif_raw) {
		bool first_row = true;

		int row = crif_raw.size();
		int col = crif_raw[0].size();

		for (int i = 0; i < row; i++) {
			CRIFRow crif_row;
			for (int j = 0; j < col; j++) {
				string cell = crif_raw[i][j];

				if (first_row) {
					if (cell == "PortfolioID")
						idx_PortfolioID = j;
					else if(cell == "TradeID")
						idx_TradeID = j;
					else if (cell == "CollectRegulations")
						idx_CollectRegulations = j;
					else if (cell == "ProductClass")
						idx_ProductClass = j;
					else if (cell == "RiskType")
						idx_RiskType = j;
					else if (cell == "Qualifier")
						idx_Qualifier = j;
					else if (cell == "Bucket")
						idx_Bucket = j;
					else if (cell == "Label1")
						idx_Label1 = j;
					else if (cell == "Label2")
						idx_Label2 = j;
					else if (cell == "Amount")
						idx_Amount = j;
					else if (cell == "AmountCurrency")
						idx_AmountCurrency = j;
					else if (cell == "AmountUSD")
						idx_AmountUSD = j;
				}
				else {
					if (j == idx_PortfolioID)
						crif_row.PortfolioID = cell;
					else if (j == idx_TradeID)
						crif_row.TradeID = cell;
					else if (j == idx_CollectRegulations)
						crif_row.CollectRegulations = cell;
					else if (j == idx_ProductClass)
						crif_row.ProductClass = cell;
					else if (j == idx_RiskType)
						crif_row.RiskType = cell;
					else if (j == idx_Qualifier)
						crif_row.Qualifier = cell;
					else if (j == idx_Bucket)
						crif_row.Bucket = cell;
					else if (j == idx_Label1)
						crif_row.Label1 = cell;
					else if (j == idx_Label2)
						crif_row.Label2 = cell;
					else if (j == idx_Amount)
						crif_row.Amount = to_double(cell);
					else if (j == idx_AmountCurrency)
						crif_row.AmountCurrency = cell;
					else if (j == idx_AmountUSD)
						crif_row.AmountUSD = to_double(cell);

					
				}
			}
			

			if (first_row) {
				first_row = false;
			}
			else {
				this->crif_table.push_back(crif_row);
			}
		}


	}
	// Pledgor Role ����� ���� Amount, AmountUSD�� ��ȣ�� �ٲ�
	void input_data_P(vector<vector<string>>& crif_raw) {
		bool first_row = true;

		int row = crif_raw.size();
		int col = crif_raw[0].size();

		for (int i = 0; i < row; i++) {
			CRIFRow crif_row;
			for (int j = 0; j < col; j++) {
				string cell = crif_raw[i][j];

				if (first_row) {
					if (cell == "PortfolioID")
						idx_PortfolioID = j;
					else if (cell == "TradeID")
						idx_TradeID = j;
					else if (cell == "CollectRegulations")
						idx_CollectRegulations = j;
					else if (cell == "ProductClass")
						idx_ProductClass = j;
					else if (cell == "RiskType")
						idx_RiskType = j;
					else if (cell == "Qualifier")
						idx_Qualifier = j;
					else if (cell == "Bucket")
						idx_Bucket = j;
					else if (cell == "Label1")
						idx_Label1 = j;
					else if (cell == "Label2")
						idx_Label2 = j;
					else if (cell == "Amount")
						idx_Amount = j;
					else if (cell == "AmountCurrency")
						idx_AmountCurrency = j;
					else if (cell == "AmountUSD")
						idx_AmountUSD = j;
				}
				else {
					if (j == idx_PortfolioID)
						crif_row.PortfolioID = cell;
					else if (j == idx_TradeID)
						crif_row.TradeID = cell;
					else if (j == idx_CollectRegulations)
						crif_row.CollectRegulations = cell;
					else if (j == idx_ProductClass)
						crif_row.ProductClass = cell;
					else if (j == idx_RiskType)
						crif_row.RiskType = cell;
					else if (j == idx_Qualifier)
						crif_row.Qualifier = cell;
					else if (j == idx_Bucket)
						crif_row.Bucket = cell;
					else if (j == idx_Label1)
						crif_row.Label1 = cell;
					else if (j == idx_Label2)
						crif_row.Label2 = cell;
					else if (j == idx_Amount)
						crif_row.Amount = -1 * to_double(cell);
					else if (j == idx_AmountCurrency)
						crif_row.AmountCurrency = cell;
					else if (j == idx_AmountUSD)
						crif_row.AmountUSD = -1 * to_double(cell);


				}
			}


			if (first_row) {
				first_row = false;
			}
			else {
				this->crif_table.push_back(crif_row);
			}
		}


	}

	vector<double> get_Amount() {
		vector<double> col_Amount;

		for (auto row : crif_table) {
			col_Amount.push_back(row.Amount);
		}

		return col_Amount;
	}

	vector<double> get_AmountUSD() {
		vector<double> col_AmountUSD;

		for (auto row : crif_table) {
			col_AmountUSD.push_back(row.AmountUSD);
		}
		
		return col_AmountUSD;
	}

	vector<string> get_Label1() {
		vector<string> col_Label1;

		for (auto row : crif_table) {
			col_Label1.push_back(row.Label1);
		}

		return col_Label1;
	}

	vector<string> get_Label2() {
		vector<string> col;

		for (auto row : crif_table) {
			col.push_back(row.Label2);
		}

		return col;
	}


	vector<string> get_RiskType() {
		vector<string> col_RiskType;

		for (auto row : crif_table) {
			col_RiskType.push_back(row.RiskType);
		}

		return col_RiskType;
	}

	vector<string> get_Qualifier() {
		vector<string> col_Qualifier;

		for (auto row : crif_table) {
			col_Qualifier.push_back(row.Qualifier);
		}

		return col_Qualifier;
	}

	vector<string> get_ProductClass() {
		vector<string> col_ProductClass;

		for (auto row : crif_table) {
			col_ProductClass.push_back(row.ProductClass);
		}

		return col_ProductClass;
	}

	vector<string> get_Bucket() {
		vector<string> col_Bucket;

		for (auto row : crif_table) {
			col_Bucket.push_back(row.Bucket);
		}

		return col_Bucket;
	}

	

	CRIFTable sel_ProductClass(string product_class) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.ProductClass == product_class) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}
	CRIFTable sel_not_ProductClass(string product_class) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.ProductClass != product_class) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}


	CRIFTable sel_RiskType(string risk_type) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.RiskType == risk_type) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}
	CRIFTable sel_RiskType(string risk_type1, string risk_type2) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.RiskType == risk_type1 || row.RiskType == risk_type2) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}
	CRIFTable sel_RiskType(string risk_type1, string risk_type2, string risk_type3) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.RiskType == risk_type1 || row.RiskType == risk_type2 || row.RiskType == risk_type3) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}

	CRIFTable sel_not_RiskType(string risk_type) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.RiskType != risk_type) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}

	CRIFTable sel_Bucket(int bucket) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (bucket == 0) {
				if (row.Bucket == "Residual") {
					crif_sel.crif_table.push_back(row);
				}
			}
			else {
				if (row.Bucket == to_string(bucket)) {
					crif_sel.crif_table.push_back(row);
				}
			}
			
		}
		return crif_sel;
	}
	CRIFTable sel_not_Bucket(int bucket) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (bucket == 0) {
				if (row.Bucket != "Residual") {
					crif_sel.crif_table.push_back(row);
				}
			}
			else {
				if (row.Bucket != to_string(bucket)) {
					crif_sel.crif_table.push_back(row);
				}
			}

		}
		return crif_sel;
	}


	CRIFTable sel_Qualifier(string qual) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.Qualifier == qual) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}
	CRIFTable sel_not_Qualifier(string qual) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.Qualifier != qual) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}

	CRIFTable sel_Label1(string s) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.Label1 == s) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}

	CRIFTable sel_Label2(string s) {
		CRIFTable crif_sel;

		for (auto row : this->crif_table) {
			if (row.Label2 == s) {
				crif_sel.crif_table.push_back(row);
			}
		}
		return crif_sel;
	}

	CRIFTable drop_RiskType(string risk_type) {
		CRIFTable crif_;


		for (auto row : this->crif_table) {
			if (row.RiskType != risk_type) {
				crif_.crif_table.push_back(row);
			}
		}


		return crif_;
	}

};