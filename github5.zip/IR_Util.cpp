
#include "stdafx.h"
#include <math.h>
#include <stdlib.h>
#include "TransDate.h"

// Day Count Factrion���� Continuous Discount Factor�� ����ϴ� �Լ�
double Calc_DiscountFactor(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *DiscntCrvTerm,		// IN:  Discount Curve Term
	double *DiscntCrvRate,		// IN:  Discount Curve Rate
	long NDiscntCrvTerm,		// IN:  Discount Curve Term ����
	long DayCountType,			// IN:  Discount Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long TargetDate				// IN:  ���� ��� ����(YYYYMMDD)
)
{
	long i;
	double DayCntFraction = DayCountFraction(PriceDate, TargetDate, DayCountType);

	if (DayCntFraction<=DiscntCrvTerm[0]) return exp(-DiscntCrvRate[0]*DayCntFraction);
	else if (DayCntFraction>=DiscntCrvTerm[NDiscntCrvTerm-1]) return exp(-DiscntCrvRate[NDiscntCrvTerm-1]*DayCntFraction);
	else {
		for (i=0;i<NDiscntCrvTerm-1;i++) {
			if (DayCntFraction>=DiscntCrvTerm[i] && DayCntFraction<DiscntCrvTerm[i+1]) break;
		}
		return exp(-DayCntFraction * 
			((DiscntCrvRate[i+1]-DiscntCrvRate[i])/(DiscntCrvTerm[i+1]-DiscntCrvTerm[i])
			* (DayCntFraction-DiscntCrvTerm[i])	
			+DiscntCrvRate[i]));	// ��������
	}
}

double Linear_Interpolation_1D(double *Term, double *TermValue, long NTerm, double Time ) 
{
	long i = 0;
	double Interp_Vol = 0.0;

	if(Time <= Term[0])
	{
		Interp_Vol = TermValue[0];
	}
	else if(Time >= Term[NTerm-1]) 
	{
		Interp_Vol = TermValue[NTerm-1];
	}
	else
	{
		for(i=1;i<NTerm;i++)
		{
			if(Time<Term[i]) 
			{
				Interp_Vol = (TermValue[i] - TermValue[i-1])/(Term[i] - Term[i-1]) * (Time - Term[i-1]) + TermValue[i-1];
				break;
			}
		}
	}

	return Interp_Vol;
	
}

// ������ ��������
double Linear_Interpolation_1D_Square(double *Term, double *TermValue, long NTerm, double Time )
{
	long i = 0;
	double Interp_Vol = 0.0;
	double EPS = 1E-10;

	if(Time <= Term[0])
	{
		Interp_Vol = TermValue[0];
	}
	else if(Time >= Term[NTerm-1]) 
	{
		Interp_Vol = TermValue[NTerm-1];
	}
	else
	{
		for(i=1;i<NTerm;i++)
		{
			if(Time<Term[i]) 
			{
				Interp_Vol = (TermValue[i]*TermValue[i] - TermValue[i-1]*TermValue[i-1])/(Term[i] - Term[i-1]) * (Time - Term[i-1]) + TermValue[i-1]*TermValue[i-1];
				if(Interp_Vol<0) Interp_Vol = EPS;
				Interp_Vol = sqrt(Interp_Vol);
				break;
			}
		}
	}
	return Interp_Vol;
}



// Forward Rate ���
double Calc_ForwardRate(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *RefCrvTerm,			// IN:  Reference Curve Term
	double *RefCrvRate,			// IN:  Reference Curve Rate
	long NRefCrvTerm,			// IN:  Reference Curve Term ����
	long DayCountType,			// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ForwardFormDate,		// IN:  Forwrad���� ������
	long ForwardToDate			// IN:  Forward���� ������
)
{
	double FromDiscntFactor;
	double ToDiscntFactor;
	double ForwardInterval;
	double ForwardDF;

	if(ForwardFormDate>PriceDate)
		FromDiscntFactor = Calc_DiscountFactor(PriceDate, RefCrvTerm, RefCrvRate, NRefCrvTerm, DayCountType, ForwardFormDate);
	else
		FromDiscntFactor = 1.0;

	if(ForwardToDate>PriceDate)
		ToDiscntFactor = Calc_DiscountFactor(PriceDate, RefCrvTerm, RefCrvRate, NRefCrvTerm, DayCountType, ForwardToDate);
	else
		ToDiscntFactor = 1.0;

	ForwardInterval = DayCountFraction(ForwardFormDate, ForwardToDate, DayCountType);
	ForwardDF = FromDiscntFactor/ToDiscntFactor;

	return (ForwardDF-1.0) / ForwardInterval;
}

double Calc_ForwardRate_Year(
	double *RefCrvTerm,				// IN:  Reference Curve Term
	double *RefCrvRate,				// IN:  Reference Curve Rate
	long NRefCrvTerm,				// IN:  Reference Curve Term ����
	long DayCountType,				// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double ForwardFormDate_Year,	// IN:  Forwrad���� ������ (��)
	double ForwardToDate_Year		// IN:  Forward���� ������ (��)
)
{
	double FromDiscntFactor;
	double ToDiscntFactor;
	double ForwardInterval;
	double ForwardDF;

	FromDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, ForwardFormDate_Year) * ForwardFormDate_Year );
	ToDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, ForwardToDate_Year) * ForwardToDate_Year );

	ForwardInterval = ForwardToDate_Year-ForwardFormDate_Year;
	ForwardDF = FromDiscntFactor/ToDiscntFactor;

	return (ForwardDF-1) / ForwardInterval;
}


// Forward Rate ��� ( Continuous Compounding Interest Rate )
double Calc_ForwardRate_CCIR(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *RefCrvTerm,			// IN:  Reference Curve Term
	double *RefCrvRate,			// IN:  Reference Curve Rate
	long NRefCrvTerm,			// IN:  Reference Curve Term ����
	long DayCountType,			// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ForwardStartDate,		// IN:  Forwrad���� ������
	long ForwardEndDate			// IN:  Forward���� ������
)
{
	double ForwardStartDate_Year;
	double ForwardEndDate_Year;
	double ForwardStartRate;
	double ForwardEndRate;
	double ForwardRate;

	ForwardStartDate_Year = DayCountFraction(PriceDate, ForwardStartDate, DayCountType);
	ForwardEndDate_Year = DayCountFraction(PriceDate, ForwardEndDate, DayCountType);

	ForwardStartRate = Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, ForwardStartDate_Year);
	ForwardEndRate = Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, ForwardEndDate_Year);

	ForwardRate = (ForwardEndRate*ForwardEndDate_Year - ForwardStartRate*ForwardStartDate_Year) / (ForwardEndDate_Year - ForwardStartDate_Year);

	return ForwardRate;
}

// Forward Swap Rate ���, ���� ��¥�� �����ϰ� ó��
double Calc_ForwardSwapRate(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *RefCrvTerm,			// IN:  Reference Curve Term
	double *RefCrvRate,			// IN:  Reference Curve Rate
	long NRefCrvTerm,			// IN:  Reference Curve Term ����
	long DayCountType,			// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ForwardFormDate,		// IN:  Forwrad���� ������
	double SwapRateFixPeriod,	// IN:  Swap Rate Fixed Leg Coupon �����ֱ�
	long SwapRateFixNCpn		// IN:  Swap Rate Fixed Leg Coupon ���� Ƚ�� ( �����ֱⰡ 0.25�� 5Y�ݸ���� ����Ƚ���� 5/0.25 = 20 )
)
{
	long i;
	double T1;
	double T2;
	double Time;
	double FromDiscntFactor; // nearDF
	double ToDiscntFactor; // farDF
	double ForwardDF = 0.0; // sumDF

	T1 = DayCountFraction(PriceDate, ForwardFormDate, DayCountType);
	T2 = T1 + (double)SwapRateFixNCpn*SwapRateFixPeriod;

	FromDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, T1) * T1 );
	ToDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, T2) * T2 );

	for(i=0;i<SwapRateFixNCpn;i++)
	{
		Time = T1+(i+1)*SwapRateFixPeriod;
		ForwardDF += exp(-Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, Time) * Time);
	}

	return (FromDiscntFactor - ToDiscntFactor) / (ForwardDF * SwapRateFixPeriod);
}

double Calc_ForwardSwapRate_Year(
	double *RefCrvTerm,				// IN:  Reference Curve Term
	double *RefCrvRate,				// IN:  Reference Curve Rate
	long NRefCrvTerm,				// IN:  Reference Curve Term ����
	long DayCountType,				// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	double ForwardFormDate_Year,	// IN:  Forwrad���� ������(��)
	double SwapRateFixPeriod,		// IN:  Swap Rate Fixed Leg Coupon �����ֱ�
	long SwapRateFixNCpn			// IN:  Swap Rate Fixed Leg Coupon ���� Ƚ�� ( �����ֱⰡ 0.25�� 5Y�ݸ���� ����Ƚ���� 5/0.25 = 20 )
)
{
	long i;
	double T1;
	double T2;
	double Time;
	double FromDiscntFactor; // nearDF
	double ToDiscntFactor; // farDF
	double ForwardDF = 0.0; // sumDF

	T1 = ForwardFormDate_Year;
	T2 = T1 + (double)SwapRateFixNCpn*SwapRateFixPeriod;

	FromDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, T1) * T1 );
	ToDiscntFactor = exp( -Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, T2) * T2 );

	for(i=0;i<SwapRateFixNCpn;i++)
	{
		Time = T1+(i+1)*SwapRateFixPeriod;
		ForwardDF += exp(-Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, Time) * Time);
	}

	return (FromDiscntFactor - ToDiscntFactor) / (ForwardDF * SwapRateFixPeriod);
}


// N(x)
double CND(double x)
{
	double y, Exponential, SumA, SumB, val;
    
    y = fabs(x);
    if (y > 37) val = 0;
	else {
        Exponential = exp(-y*y / 2);
		if (y < 7.07106781186547) {
            SumA = 3.52624965998911E-02 * y + 0.700383064443688;
            SumA = SumA * y + 6.37396220353165;
            SumA = SumA * y + 33.912866078383;
            SumA = SumA * y + 112.079291497871;
            SumA = SumA * y + 221.213596169931;
            SumA = SumA * y + 220.206867912376;
            SumB = 8.83883476483184E-02 * y + 1.75566716318264;
            SumB = SumB * y + 16.064177579207;
            SumB = SumB * y + 86.7807322029461;
            SumB = SumB * y + 296.564248779674;
            SumB = SumB * y + 637.333633378831;
            SumB = SumB * y + 793.826512519948;
            SumB = SumB * y + 440.413735824752;
            val = Exponential * SumA / SumB;
		}
        else {
            SumA = y + 0.65;
            SumA = y + 4 / SumA;
            SumA = y + 3 / SumA;
            SumA = y + 2 / SumA;
            SumA = y + 1 / SumA;
            val = Exponential / (SumA * 2.506628274631);
        }
	}
  
	if (x > 0) val = 1 - val;

	return val;
}

// IRS(������ȭ��ȯ), In Advanced  and ����, ����<->���� ��ȯ�� Swap�� �����Ѵ�.
double Calc_ForwardSwapRate_Schedule(
	long PriceDate,					// IN:  ����� (YYYYMMDD)
	long Flt_NDisCrvTerm,			// IN:  Floating Leg Discount Curve Term ����
	double *Flt_DisCrvTerm,			// IN:  Floating Leg Discount Curve Term (��)
	double *Flt_DisCrvRate,			// IN:  Floating Leg Discount Curve Rate
	long Flt_DisCrvDayCntType,		// IN:  Floating Leg Discount Curve Type
	long Flt_NRefCrvTerm,			// IN:  Floating Curve Term ����
	double *Flt_RefCrvTerm,			// IN:  Floating Curve Term (��)
	double *Flt_RefCrvRate,			// IN:  Floating Curve Rate
	long Flt_RefCrvDayCntType,		// IN:  Floating Curve Type
	long Fix_NDisCrvTerm,			// IN:  Fixed Leg Discount Curve Term ����
	double *Fix_DisCrvTerm,			// IN:  Fixed Leg Discount Curve Term (��)
	double *Fix_DisCrvRate,			// IN:  Fixed Leg Discount Curve Rate
	long Fix_DisCrvDayCntType,		// IN:  Fixed Leg Discount Curve Type
	long Flt_NCpnCashFlow,			// IN:  Floating Leg Coupon ����
	long Flt_CpnDayCntType,			// IN:  Floating Leg Coupon DayCount Convention 
	long *DesignateResetFlag,		// IN:  ������ �Է� Flag ( 0 : �����, �⸻�Ϸ� ����, 1 : �ݸ����� ������, ������ ������� ��� )
	long *Flt_ForwardStartDate,		// IN:  Floating Leg ���� ���� ������ (YYYYMMDD)
	long *Flt_ForwardEndDate,		// IN:  Floating Leg ���� ���� ������ (YYYYMMDD)
	long *Flt_CpnFromDate,			// IN:  Floating Leg ����� (YYYYMMDD)
	long *Flt_CpnToDate,			// IN:  Floating Leg �⸻�� (YYYYMMDD)
	long *Flt_CpnSettleDate,		// IN:  Floating Leg ������ (YYYYMMDD)
	long Fix_NCpnCashFlow,			// IN:  Fixed Leg Coupon ����
	long Fix_CpnDayCntType,			// IN:  Fixed Leg Coupon Day Count Convention 
	long *Fix_CpnFromDate,			// IN:  Fixed Leg ����� (YYYYMMDD)
	long *Fix_CpnToDate,			// IN:  Fixed Leg �⸻�� (YYYYMMDD)
	long *Fix_CpnSettleDate			// IN:  Fixed Leg ������ (YYYYMMDD)
)
{
	long i;

	double Forward_SwapRate = 0.0;
	double Forward_Rate = 0.0;

	double FloatingLeg_Value = 0.0;
	double FixedLeg_Value = 0.0;


	for(i=0;i<Flt_NCpnCashFlow;i++)
	{
		if(DesignateResetFlag[i]==0)
			Forward_Rate = Calc_ForwardRate(PriceDate, Flt_RefCrvTerm, Flt_RefCrvRate, Flt_NRefCrvTerm, Flt_RefCrvDayCntType, Flt_CpnFromDate[i], Flt_CpnToDate[i]);
		else
			Forward_Rate = Calc_ForwardRate(PriceDate, Flt_RefCrvTerm, Flt_RefCrvRate, Flt_NRefCrvTerm, Flt_RefCrvDayCntType, Flt_ForwardStartDate[i], Flt_ForwardEndDate[i]);

		FloatingLeg_Value =	Forward_Rate
							*	DayCountFraction(Flt_CpnFromDate[i], Flt_CpnToDate[i], Flt_CpnDayCntType)
							*	Calc_DiscountFactor(PriceDate, Flt_DisCrvTerm, Flt_DisCrvRate, Flt_NDisCrvTerm, Flt_DisCrvDayCntType, Flt_CpnSettleDate[i]);
	}

	for(i=0;i<Fix_NCpnCashFlow;i++)
	{
		FixedLeg_Value = 	DayCountFraction(Fix_CpnFromDate[i], Fix_CpnToDate[i], Fix_CpnDayCntType)
						*	Calc_DiscountFactor(PriceDate, Fix_DisCrvTerm, Fix_DisCrvRate, Fix_NDisCrvTerm, Fix_DisCrvDayCntType, Fix_CpnSettleDate[i]);
	}

	Forward_SwapRate = FloatingLeg_Value / FixedLeg_Value;

	return Forward_SwapRate;
}


double Linear_interpolation_2D(
	double RowValue, 
	double ColumnValue,
	long NRowTerm,
	long NColumnTerm,
	double *RowTerm,
	double *ColumnTerm,
	double *MatrixData
)
{
	int i;
	int RowPos1=0;
	int RowPos2=0;
	int ColumnPos1=0;
	int ColumnPos2=0;
	double InterpValue = 0;
	double Alpha1=0, Alpha2=0;

	// ����ġ Ȯ��
	if(RowValue <  RowTerm[0] || NRowTerm == 1)
	{
		RowPos1 = 0;
		RowPos2 = 0;
	}
	else if(RowValue >= RowTerm[NRowTerm-1])
	{
		RowPos1 = NRowTerm-1;
		RowPos2 = NRowTerm-1;
	}
	else 
	{
		for(i=1;i<NRowTerm;i++)
		{
			if(RowValue<RowTerm[i])
			{
				RowPos1 = i-1;
				RowPos2 = i;
				break;
			}
		}
	}

	// ����ġ Ȯ��
	if(ColumnValue <  ColumnTerm[0] || NColumnTerm == 1)
	{
		ColumnPos1 = 0;
		ColumnPos2 = 0;
	}
	else if(ColumnValue >= ColumnTerm[NColumnTerm-1])
	{
		ColumnPos1 = NColumnTerm-1;
		ColumnPos2 = NColumnTerm-1;
	}
	else 
	{
		for(i=1;i<NColumnTerm;i++)
		{
			if(ColumnValue<ColumnTerm[i])
			{
				ColumnPos1 = i-1;
				ColumnPos2 = i;
				break;
			}
		}
	}

	
	if(RowPos1 != RowPos2)
		Alpha1 = (RowValue-RowTerm[RowPos1])/(RowTerm[RowPos2]-RowTerm[RowPos1]);
	else 
		Alpha1 = 1;

	if(ColumnPos1 != ColumnPos2)
		Alpha2 = (ColumnValue-ColumnTerm[ColumnPos1])/(ColumnTerm[ColumnPos2]-ColumnTerm[ColumnPos1]);
	else 
		Alpha2 = 1;
	MatrixData[RowPos1*NColumnTerm+ColumnPos1];

	InterpValue =		(1-Alpha1)*(1-Alpha2)*MatrixData[RowPos1*NColumnTerm+ColumnPos1]
					+	(1-Alpha1)*Alpha2*MatrixData[RowPos1*NColumnTerm+ColumnPos2]
					+	Alpha1*(1-Alpha2)*MatrixData[RowPos2*NColumnTerm+ColumnPos1]
					+	Alpha1*Alpha2*MatrixData[RowPos2*NColumnTerm+ColumnPos2];

	return InterpValue;

}


// �����ϰ� Cap���� ���
// ���ý������� ��ǰ�� ���۵ȴٰ� ����,
// ������ = ���ú��� �� Caplet Term
// ������ = �� Caplet Term
// ���ұݸ�ĸ�� ����
double Calc_SimpleCaplet(
	double NotionalAmount,		// IN:  �׸�ݾ�
	long NDisCrvTerm,			// IN:  ���� �ݸ� �Ⱓ���� ����
	double *DisCrvTerm,			// IN:  ���� �ݸ� �Ⱓ����(��) (ũ�� : NDisCrvTerm)
	double *DisCrvRate,			// IN:  ���� �ݸ� (ũ�� : NDisCrvTerm)
	long DisCrvDayCntConv,		// IN:  ���� �ݸ� Day Count Convention
	long NRefCrvTerm,			// IN:  ����Ŀ�� �Ⱓ���� ����
	double *RefCrvTerm,			// IN:  ����Ŀ�� �Ⱓ����(��) (ũ�� : NRefCrvTerm)
	double *RefCrvRate,			// IN:  ����Ŀ�� �ݸ� (ũ�� : NRefCrvTerm)
	long RefCrvDayCntConv,		// IN:  ����Ŀ�� Day Count Convention
	double RefCrvPeriod,		// IN:  ����Ŀ�� �ݸ� �����ֱ�(��)
	double StrikeRate,			// IN:  ���ݸ�
	long CapletTermCnt,			// IN:  Caplet Term Count
	double *CapletTerm,			// IN:  Caplet Term 
	double *CapletVol,			// IN:  Caplet Vol ������
	long CalcStartCapletIdx		// IN:  ������ Caplet Vol ���� (0�� ó��)
)
{

	long i;

	double d1, d2;
	double Value = 0;

	double *FixRate = (double *)malloc(CapletTermCnt*sizeof(double));

	for(i=CalcStartCapletIdx;i<CapletTermCnt;i++)
	{
		if(i==0)
			FixRate[i] = Linear_Interpolation_1D(RefCrvTerm, RefCrvRate, NRefCrvTerm, CapletTerm[i]);
		else
			FixRate[i] = Calc_ForwardRate_Year(RefCrvTerm, RefCrvRate, NRefCrvTerm, RefCrvDayCntConv, CapletTerm[i-1], CapletTerm[i]);

		d1 = (log(FixRate[i]/StrikeRate) + (0.5*CapletVol[i]*CapletVol[i])*CapletTerm[i]) / (CapletVol[i]*sqrt(CapletTerm[i]));
		d2 = d1 - CapletVol[i]*sqrt(CapletTerm[i]);

		if(i==0)
		{
			Value += NotionalAmount * CapletTerm[0]
							* (FixRate[i]*CND(d1) - StrikeRate*CND(d2))
							* exp(-Linear_Interpolation_1D(DisCrvTerm, DisCrvRate, NDisCrvTerm, CapletTerm[0])*CapletTerm[0]);
		}
		else
		{
			Value += NotionalAmount	* (CapletTerm[i]-CapletTerm[i-1])
							* (FixRate[i]*CND(d1) - StrikeRate*CND(d2))
							* exp(-Linear_Interpolation_1D(DisCrvTerm, DisCrvRate, NDisCrvTerm, CapletTerm[i])*CapletTerm[i]);
		}
	}

	if(FixRate) free(FixRate);

	return Value;
}


// Caplet Vol ���, 
// ���ο��� ��ü ����(�����ϰ�) ������ Caplet ���ڴ�� Interpolation �Ͽ� ����
// �⺻�� ResetFix =  Forward Start = CouponForm, ForwardEnd = CouponTo = Settlement
// ����Ŀ�� �����ֱ�� ���ұݸ� �����ֱ�� �����ϰ�, �ش絥���Ͱ� �ִٰ� �����Ѵ�.
// Caplet DayCount Convention�� Ref Curve DayCount Convention�� ���󰣴�.
// CapVol�� Linear�ϴٴ� ������ ���� �ʰ�, CapletVol�� Linear�ϴٰ� �����ϹǷ� Caplet Vol�� ����Ѵ�.
long Calc_CapletForwardVol(
	long PriceDate,				// IN:  Caplet Vol ������� (YYYYMMDD)
	long NDisCrvTerm,			// IN:  ���� �ݸ� �Ⱓ���� ����
	double *DisCrvTerm,			// IN:  ���� �ݸ� �Ⱓ����(��) (ũ�� : NDisCrvTerm)
	double *DisCrvRate,			// IN:  ���� �ݸ� (ũ�� : NDisCrvTerm)
	long DisCrvDayCntConv,		// IN:  ���� �ݸ� Day Count Convention
	long NRefCrvTerm,			// IN:  ����Ŀ�� �Ⱓ���� ����
	double *RefCrvTerm,			// IN:  ����Ŀ�� �Ⱓ����(��) (ũ�� : NRefCrvTerm)
	double *RefCrvRate,			// IN:  ����Ŀ�� �ݸ� (ũ�� : NRefCrvTerm)
	long RefCrvDayCntConv,		// IN:  ����Ŀ�� Day Count Convention
	double RefCrvPeriod,		// IN:  ����Ŀ�� �ݸ� �����ֱ�(��)
	long NCapVolTerm,			// IN:  Cap Vol �Ⱓ���� ����
	double *CapVolTerm,			// IN:  Cap Vol �Ⱓ����(��) (ũ�� : NCapVolTerm)
	double *CapVol,				// IN:  Cap Vol (ũ�� : NCapVolTerm)
	long MaturityDate,			// IN:  ������ (YYYYMMDD)
	long MethodType,			// IN:  ����� ( 1 : Bisection, 2 : Newton-Raphson )
	long *NCapletTerm,			// IN/OUT: �Է½� �Ⱓ�����ִ밪/�Ⱓ��������+1�� �Է�, ��½� ���� Caplet Vol���� ���
	double *CapletTerm,			// OUT: Caplet Vol ����(��) [�⺻�� �迭�� ������ �Ⱓ�����ִ밪/�Ⱓ��������+1 �� �̻����� �Ѵ�]
	double *CapletVol			// OUT: ���� CapletVol [�⺻�� �迭�� ������ �Ⱓ�����ִ밪/�Ⱓ��������+1 �� �̻����� �Ѵ�]
)
{
	double MAX_TERM_EPS = 0.25;
	double MAX_PRICE_EPS = 1.0e-6;
	long MAX_LOOP = 100000;
	double NEWTON_METHOD_H = 0.01;

	///////  ErrorCode  ////////////////////////////////////////////////////

	// ����
	// �����Ϻ��� ū ĸ�� �Ⱓ������ ���� ��� 
	// ĸ�� �Ⱓ������ �����ֱ⸦ ũ�� ����� ��찡 �ִ� ���(�Ⱓ����/�����ֱ� �� �������� �����ֱ�*0.25 �̻��� ��쿡��)

	////////////////////////////////////////////////////////////////////////

	long i, j, k;
	double NotionalAmount = 10000.0;
	
	long *TenorCount;
	long TenorCount_Sum = 0;
	long CapletTermCount = 0;

	double MaturityDate_Year = 0;
	long CapVolTerm_EndIdx = -1;

	double *CapletVol_Up;
	double *CapletVol_Dn;
	double *CapletVol_Md;
	double *CapletVol_Flat;

	double TargetPrice = 0.0;
	double TargetPrice_Up = 0.0;
	double TargetPrice_Dn = 0.0;
	double TargetPrice_Md = 0.0;

	double UpPos = 0.0;
	double DnPos = 0.0;

	double Default_BisectionPos = 0.0; // Pos ���ݼ���

	double ATM_SwapRate = 0.0;
	double CapletVolSlope = 0.0;

	// ������� ��ȯ��
	MaturityDate_Year = DayCountFraction(PriceDate,MaturityDate,RefCrvDayCntConv);

	// �� ���������� Term ����
	TenorCount = (long *)malloc(NCapVolTerm*sizeof(long));

	// ��� CapVolTerm�� RefCrvPeriod�� ������ ���������ϰ�(�����°���) 
	for(i=0;i<NCapVolTerm;i++)
	{
		TenorCount[i] = 0;
		for(j=0;j<(long)(CapVolTerm[i]/RefCrvPeriod);j++) // ���ѷ�����������
		{
			CapletTerm[j+TenorCount_Sum] = (double)((j+1)+TenorCount_Sum)*RefCrvPeriod;
			TenorCount[i] += 1;
			if(abs(CapletTerm[j+TenorCount_Sum]-CapVolTerm[i])<MAX_TERM_EPS*RefCrvPeriod) // �̷��� Term�� ���ٸ� �Լ� ���ο��� �������
			{
				CapletTerm[j+TenorCount_Sum] = CapVolTerm[i];
				break;
			}
		}
		TenorCount_Sum += TenorCount[i];
		if(MaturityDate_Year<=CapVolTerm[i]) // ��� ������ ���� ����
		{
			CapVolTerm_EndIdx = i;
			break;
		}
	}
	if(CapVolTerm_EndIdx<0) CapVolTerm_EndIdx = NCapVolTerm-1;

	// ����� Term���� �Ѱ��ֱ�
	if(*NCapletTerm<TenorCount_Sum)
	{
		if(TenorCount) free(TenorCount);
		return *NCapletTerm;
	}
	else
	{
		*NCapletTerm = TenorCount_Sum;
	}

	CapletVol_Up = (double *)malloc(TenorCount_Sum*sizeof(double));
	CapletVol_Dn = (double *)malloc(TenorCount_Sum*sizeof(double));
	CapletVol_Md = (double *)malloc(TenorCount_Sum*sizeof(double));
	CapletVol_Flat = (double *)malloc(TenorCount_Sum*sizeof(double));

	for(i=0;i<TenorCount_Sum;i++)
	{
		CapletVol_Up[i] = 0.0;
		CapletVol_Dn[i] = 0.0;
		CapletVol_Md[i] = 0.0;
		CapletVol_Flat[i] = 0.0;
	}

	//
	TenorCount_Sum = 0;
	for(i=0;i<=CapVolTerm_EndIdx;i++)
	{
		if(MethodType==1) // Bisection
		{
			if(i==0)
			{	// ù������ CapletVol�� Flat
				for(j=0;j<TenorCount[i];j++)
				{
					CapletVol[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Up[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Dn[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Md[j+TenorCount_Sum] = CapVol[0];
				}
			}
			else
			{
				// ATM Swap�ݸ��� ��簡������ ����
				ATM_SwapRate = Calc_ForwardSwapRate_Year(RefCrvTerm, RefCrvRate, NRefCrvTerm, RefCrvDayCntConv, 0, RefCrvPeriod, TenorCount_Sum+TenorCount[i]);

				for(k=0;k<TenorCount_Sum+TenorCount[i];k++) CapletVol_Flat[k] = CapVol[i];

				// CapVolTerm[i]������ Cap����
				TargetPrice = Calc_SimpleCaplet(NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
												NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
												ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Flat,				0)

							- Calc_SimpleCaplet(NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
												NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
												ATM_SwapRate,	TenorCount_Sum,	CapletTerm,		CapletVol,			0);

				// �ʱⰪ ����			
				CapletVolSlope = (CapVol[i]-CapletVol[TenorCount_Sum-1])/(CapVolTerm[i]-CapVolTerm[i-1]);
				Default_BisectionPos = (1.0-CapletVol[TenorCount_Sum-1])/(CapVolTerm[i]-CapVolTerm[i-1])/4.0;
				UpPos = Default_BisectionPos;
				DnPos = -Default_BisectionPos;

				for(j=0;j<MAX_LOOP;j++) // ���ѷ��� ����
				{
					for(k=0;k<TenorCount[i];k++)
					{
						CapletVol_Up[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope + UpPos ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
						CapletVol_Dn[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope + DnPos ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
					}

					TargetPrice_Up = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
														NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
														ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Up,		TenorCount_Sum);

					TargetPrice_Dn = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
														NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
														ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Dn,		TenorCount_Sum);

					// ��� ���ʹ����� ���� ��ǥ�ϴ� ���� �����ϸ� Loop����
					if( abs(TargetPrice - TargetPrice_Up) < MAX_PRICE_EPS )
					{
						for(k=0;k<TenorCount[i];k++)
						{
							CapletVol[k+TenorCount_Sum] = CapletVol_Up[k+TenorCount_Sum];
							CapletVol_Dn[k+TenorCount_Sum] = CapletVol_Up[k+TenorCount_Sum];
							CapletVol_Md[k+TenorCount_Sum] = CapletVol_Up[k+TenorCount_Sum];
						}
						break;
					}
					else if( abs(TargetPrice - TargetPrice_Dn) < MAX_PRICE_EPS )
					{
						for(k=0;k<TenorCount[i];k++)
						{
							CapletVol[k+TenorCount_Sum] = CapletVol_Dn[k+TenorCount_Sum];
							CapletVol_Up[k+TenorCount_Sum] = CapletVol_Dn[k+TenorCount_Sum];
							CapletVol_Md[k+TenorCount_Sum] = CapletVol_Dn[k+TenorCount_Sum];
						}
						break;
					}
					
					// TargetPrice_Up�� TargetPrice_Dn���̿� ���� ������� ���
					// �Ÿ��������� TargetPrice_Up�� TargetPrice_Dn�� �Ÿ��� �������κ��� TargetPrice�� �Ÿ��� �հ� ���ٸ� TargetPrice�� TargetPrice_Up�� TargetPrice_Dn�� �߰��� �����Ѵ�.
					if( abs(abs(TargetPrice_Up-TargetPrice_Dn) - abs(TargetPrice_Up-TargetPrice) - abs(TargetPrice-TargetPrice_Dn)) < MAX_PRICE_EPS )
					{
						for(k=0;k<TenorCount[i];k++)
						{
							CapletVol_Md[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope + (UpPos+DnPos)/2 ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
						}

						TargetPrice_Md = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
															NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
															ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Md,		TenorCount_Sum);

						if(abs(abs(TargetPrice_Up-TargetPrice_Md) - abs(TargetPrice_Up-TargetPrice) - abs(TargetPrice-TargetPrice_Md)) < MAX_PRICE_EPS)
						{
							DnPos = (UpPos+DnPos)/2.0;
						}
						else
						{
							UpPos = (UpPos+DnPos)/2.0;
						}
					}
					else
					{
						UpPos += Default_BisectionPos;
						DnPos -= Default_BisectionPos;
					}
				}
			}
			TenorCount_Sum += TenorCount[i];
		}
		else // Newton
		{
			if(i==0)
			{	// ù������ CapletVol�� Flat
				for(j=0;j<TenorCount[i];j++)
				{
					CapletVol[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Up[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Dn[j+TenorCount_Sum] = CapVol[0];
					CapletVol_Md[j+TenorCount_Sum] = CapVol[0];
				}
			}
			else
			{
				// ATM Swap�ݸ��� ��簡������ ����
				ATM_SwapRate = Calc_ForwardSwapRate_Year(RefCrvTerm, RefCrvRate, NRefCrvTerm, RefCrvDayCntConv, 0, RefCrvPeriod, TenorCount_Sum+TenorCount[i]);

				for(k=0;k<TenorCount_Sum+TenorCount[i];k++) CapletVol_Flat[k] = CapVol[i];

				// CapVolTerm[i]������ Cap����
				TargetPrice = Calc_SimpleCaplet(NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
												NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
												ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Flat,				0)

							- Calc_SimpleCaplet(NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
												NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
												ATM_SwapRate,	TenorCount_Sum,	CapletTerm,		CapletVol,			0);

				// �ʱⰪ ����			
				CapletVolSlope = (CapVol[i]-CapletVol[TenorCount_Sum-1])/(CapVolTerm[i]-CapVolTerm[i-1]);

				for(j=0;j<MAX_LOOP;j++) // ���ѷ��� ����
				{
					for(k=0;k<TenorCount[i];k++)
					{
						CapletVol_Md[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
						CapletVol_Up[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope + NEWTON_METHOD_H ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
						CapletVol_Dn[k+TenorCount_Sum] = max(1.0e-8, CapletVol[TenorCount_Sum-1] + ( CapletVolSlope - NEWTON_METHOD_H ) * (CapletTerm[TenorCount_Sum+k]-CapletTerm[TenorCount_Sum-1]) );
					}

					TargetPrice_Md = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
														NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
														ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Md,		TenorCount_Sum);

					if( abs(TargetPrice - TargetPrice_Md) < MAX_PRICE_EPS )
					{
						for(k=0;k<TenorCount[i];k++)
						{
							CapletVol[k+TenorCount_Sum] = CapletVol_Md[k+TenorCount_Sum];
							CapletVol_Up[k+TenorCount_Sum] = CapletVol_Md[k+TenorCount_Sum];
							CapletVol_Dn[k+TenorCount_Sum] = CapletVol_Md[k+TenorCount_Sum];
						}
						break;
					}

					TargetPrice_Up = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
														NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
														ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Up,		TenorCount_Sum);

					TargetPrice_Dn = Calc_SimpleCaplet(	NotionalAmount, NDisCrvTerm,	DisCrvTerm,		DisCrvRate,			DisCrvDayCntConv,
														NRefCrvTerm,	RefCrvTerm,		RefCrvRate,		RefCrvDayCntConv,	RefCrvPeriod,
														ATM_SwapRate,	TenorCount_Sum+TenorCount[i],	CapletTerm,			CapletVol_Dn,		TenorCount_Sum);

					// �̺а��� �ٻ�� ����
					CapletVolSlope = CapletVolSlope - (TargetPrice_Md - TargetPrice) / ( ( TargetPrice_Up - TargetPrice_Dn ) / ( 2 * NEWTON_METHOD_H) );
				}
			}
			TenorCount_Sum += TenorCount[i];
		}
	}

	if(CapletVol_Up) free(CapletVol_Up);
	if(CapletVol_Dn) free(CapletVol_Dn);
	if(CapletVol_Md) free(CapletVol_Md);
	if(CapletVol_Flat) free(CapletVol_Flat);
	
	if(TenorCount) free(TenorCount);

	return TenorCount_Sum;
}

/////////////////
// CubicSplie CalcC (X^2 params)
/////////////////
void Calc_C(long nRate, double* Term, double* Rate, double* CArray)
{
	long i, n;
	double h1, h0;
	long Length = nRate - 2;

	CArray[0] = 0.0;
	CArray[nRate - 1] = 0.0;

	double* RHS = CArray + 1;
	double* Alpha = (double*)malloc(sizeof(double) * (nRate - 2));
	double* Beta = (double*)malloc(sizeof(double) * (nRate - 2));
	double* Gamma = (double*)malloc(sizeof(double) * (nRate - 2));

	n = 0;
	for (i = 1; i < nRate - 1; i++)
	{
		h1 = Term[i + 1] - Term[i];
		h0 = Term[i] - Term[i - 1];
		if (n == 0)
		{
			Alpha[n] = 0.0;
			Beta[n] = 2.0 * (h0 + h1);
			Gamma[n] = h1;
		}
		else if (n == nRate - 2)
		{
			Gamma[n] = 0.0;
			Beta[n] = 2.0 * (h0 + h1);
			Gamma[n] = h1;
		}
		else {
			Alpha[n] = h0;
			Beta[n] = 2.0 * (h0 + h1);
			Gamma[n] = h1;
		}
		RHS[i - 1] = 3.0 * ((Rate[i + 1] - Rate[i]) / h1 - (Rate[i] - Rate[i - 1]) / h0);
		n++;
	}

	for (i = 1; i <= Length - 1; i++) {
		Alpha[i] /= Beta[i - 1];
		Beta[i] -= Alpha[i] * Gamma[i - 1];
		RHS[i] -= Alpha[i] * RHS[i - 1];
	}
	RHS[Length - 1] /= Beta[Length - 1];

	for (i = Length - 2; i >= 0; i--) RHS[i] = (RHS[i] - Gamma[i] * RHS[i + 1]) / Beta[i];

	free(Alpha);
	free(Beta);
	free(Gamma);
}

long Calibration_CubicSpline_Params(
	long nRate, 
	double* Term, 
	double* Rate, 
	double* C_Array	// Out: 2�� ��� Param
	)
{
	long ResultCode = 1;

	if (nRate < 4) 
	{
		ResultCode = -1;
		return ResultCode;
	}

	Calc_C(nRate, Term, Rate, C_Array);
	return ResultCode;
}

double CubicInterpolation(long nRate, double* Term, double* Rate, double* C_Array, double TargetTerm)
{
	long i;
	double a, b, d, y, hi, xp;

	if (nRate < 4) return Linear_Interpolation_1D(Term, Rate, nRate, TargetTerm);

	if (Term[0] >= TargetTerm)
	{
		// Extrapolation
		//hi = Term[1] - Term[0];
		//xp = TargetTerm - Term[0];
		//a = Rate[0];
		//b = (Rate[1] - Rate[0])/ hi - hi * (2.0 * C_Array[0] + C_Array[1]) / 3.0;
		//d = (C_Array[1] - C_Array[0]) / (3.0 * hi);
		//y = a + b * xp + C_Array[0] * xp * xp + d * xp * xp * xp;
		y = Rate[0];
	}
	else if (Term[nRate - 1] <= TargetTerm)
	{
		// Extrapolation
		//hi = Term[nRate - 1] - Term[nRate - 2];
		//xp = TargetTerm - Term[nRate - 2];
		//a = Rate[nRate - 2];
		//b = (Rate[nRate - 1] - Rate[nRate - 2]) / hi - hi * (2.0 * C_Array[nRate - 2] + C_Array[nRate - 1]) / 3.0;
		//d = (C_Array[nRate - 1] - C_Array[nRate - 2]) / (3.0 * hi);
		//y = a + b * xp + C_Array[nRate - 2] * xp * xp + d * xp * xp * xp;
		y = Rate[nRate - 1];
	}
	else
	{
		for (i = 1; i < nRate; i++)
		{
			if (Term[i] > TargetTerm) {
				hi = Term[i] - Term[i - 1];
				xp = TargetTerm - Term[i - 1];
				a = Rate[i - 1];
				b = (Rate[i] - Rate[i - 1]) / hi - hi * (2.0 * C_Array[i - 1] + C_Array[i]) / 3.0;
				d = (C_Array[i] - C_Array[i - 1]) / (3.0 * hi);
				y = a + b * xp + C_Array[i - 1] * xp * xp + d * xp * xp * xp;
				break;
			}
		}
	}
	return y;
}

// Day Count Factrion���� Continuous Discount Factor�� ����ϴ� �Լ�
double Calc_DiscountFactor_Cubic(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *DiscntCrvTerm,		// IN:  Discount Curve Term
	double *DiscntCrvRate,		// IN:  Discount Curve Rate
	double *C_Array,			// IN:  Cubic �Ķ���� 2�� ���
	long NDiscntCrvTerm,		// IN:  Discount Curve Term ����
	long DayCountType,			// IN:  Discount Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long TargetDate				// IN:  ���� ��� ����(YYYYMMDD)
)
{
	double DayCntFraction = DayCountFraction(PriceDate, TargetDate, DayCountType);
	double Rate = CubicInterpolation(NDiscntCrvTerm, DiscntCrvTerm, DiscntCrvRate, C_Array, DayCntFraction);

	return exp(-Rate * DayCntFraction);
}

// Forward Rate ���
double Calc_ForwardRate_Cubic(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *RefCrvTerm,			// IN:  Reference Curve Term
	double *RefCrvRate,			// IN:  Reference Curve Rate
	double *C_Array,			// IN:  Cubic �Ķ���� 2�� ���
	long NRefCrvTerm,			// IN:  Reference Curve Term ����
	long DayCountType,			// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ForwardFormDate,		// IN:  Forwrad���� ������
	long ForwardToDate			// IN:  Forward���� ������
)
{
	double FromDiscntFactor;
	double ToDiscntFactor;
	double ForwardInterval;
	double ForwardDF;

	if(ForwardFormDate>PriceDate)
		FromDiscntFactor = Calc_DiscountFactor_Cubic(PriceDate, RefCrvTerm, RefCrvRate,C_Array, NRefCrvTerm, DayCountType, ForwardFormDate);
	else
		FromDiscntFactor = 1.0;

	if(ForwardToDate>PriceDate)
		ToDiscntFactor = Calc_DiscountFactor_Cubic(PriceDate, RefCrvTerm, RefCrvRate,C_Array, NRefCrvTerm, DayCountType, ForwardToDate);
	else
		ToDiscntFactor = 1.0;

	ForwardInterval = DayCountFraction(ForwardFormDate, ForwardToDate, DayCountType);
	ForwardDF = FromDiscntFactor/ToDiscntFactor;

	return (ForwardDF-1.0) / ForwardInterval;
}

// Forward Swap Rate ���, ���� ��¥�� �����ϰ� ó��
double Calc_ForwardSwapRate_Cubic(
	long PriceDate,				// IN:  ����� (�������, YYYYMMDD)
	double *RefCrvTerm,			// IN:  Reference Curve Term
	double *RefCrvRate,			// IN:  Reference Curve Rate
	double *C_Array,			// IN:  Cubic �Ķ���� 2�� ���
	long NRefCrvTerm,			// IN:  Reference Curve Term ����
	long DayCountType,			// IN:  Reference Curve Day Count Type (1:ACT/ACT, 2:ACT/360, 3:ACT/365, 4:30/ACT, 5:30/360, 6:30/365, 7:NL/ACT, 8:NL/360, 9:NL/365, 10:E30/ACT, 11:E30/360, 12:E30/365)
	long ForwardFormDate,		// IN:  Forwrad���� ������
	double SwapRateFixPeriod,	// IN:  Swap Rate Fixed Leg Coupon �����ֱ�
	long SwapRateFixNCpn		// IN:  Swap Rate Fixed Leg Coupon ���� Ƚ�� ( �����ֱⰡ 0.25�� 5Y�ݸ���� ����Ƚ���� 5/0.25 = 20 )
)
{
	long i;
	double T1;
	double T2;
	double Time;
	double FromDiscntFactor; // nearDF
	double ToDiscntFactor; // farDF
	double ForwardDF = 0.0; // sumDF

	T1 = DayCountFraction(PriceDate, ForwardFormDate, DayCountType);
	T2 = T1 + (double)SwapRateFixNCpn*SwapRateFixPeriod;

	FromDiscntFactor = exp( -CubicInterpolation(NRefCrvTerm, RefCrvTerm, RefCrvRate, C_Array, T1) * T1);
	ToDiscntFactor = exp( -CubicInterpolation(NRefCrvTerm, RefCrvTerm, RefCrvRate, C_Array, T2) * T2 );

	for(i=0;i<SwapRateFixNCpn;i++)
	{
		Time = T1+(i+1)*SwapRateFixPeriod;
		ForwardDF += exp(-CubicInterpolation(NRefCrvTerm, RefCrvTerm, RefCrvRate, C_Array, Time) * Time);
	}

	return (FromDiscntFactor - ToDiscntFactor) / (ForwardDF * SwapRateFixPeriod);
}