#include"ExpiryDate.h"

namespace KISQuantLib {
	long ExpiryDate::getToday() {
		time_t curTime = time(NULL);
		struct tm *pLocal = localtime(&curTime);
		long Cur = (pLocal->tm_year+1900)*10000 + pLocal->tm_mon * 100 + pLocal->tm_mday;

		return Cur;
	}

	ExpiryDate::~ExpiryDate() 
	{
		delete expirydate;
	}

	long ExpiryDate::getAVAIL() {
		return AVAIL;
	}
}