#include <windows.h>
#include <stdio.h>
#include "Logging_Util.h"
#include <string.h>
#include "HDDSerialCheck.h"

#define LOGGING_VALUE_LENGTH			100

int check_serial(HDD_INFO* HDD_Nth)
{
	// ���� 5���� �ø��� ����ڱ����� ����Ѵ�.
	char Available_Serial1[] = "00000000000000018CE38E03000E156B"; // 00000000000000018CE38E03000E156B �Ӵ뼱
	char Available_Serial2[] = "ZN164T3Y"; // ZN164T3Y �Ӵ뼱
	char Available_Serial3[] = "ZN179DMG"; // ZN179DMG ������
	char Available_Serial4[] = "343433304D3016370025384100000001"; // 343433304D3016370025384100000001 ������
	char Available_Serial5[] = "000000000000001000080D0500151128"; // 000000000000001000080D0500151128 ��켮
	
	long check1, check2, check3, check4, check5;
	check1 = CharA_In_CharB(HDD_Nth->HDD_Serial, HDD_Nth->length_HDD_Serial, Available_Serial1, strlen(Available_Serial1));
	check2 = CharA_In_CharB(HDD_Nth->HDD_Serial, HDD_Nth->length_HDD_Serial, Available_Serial2, strlen(Available_Serial2));
	check3 = CharA_In_CharB(HDD_Nth->HDD_Serial, HDD_Nth->length_HDD_Serial, Available_Serial3, strlen(Available_Serial3));
	check4 = CharA_In_CharB(HDD_Nth->HDD_Serial, HDD_Nth->length_HDD_Serial, Available_Serial4, strlen(Available_Serial4));
	check5 = CharA_In_CharB(HDD_Nth->HDD_Serial, HDD_Nth->length_HDD_Serial, Available_Serial5, strlen(Available_Serial5));

	return max(max(max(max(check1,check2),check3),check4),check5);
}

void LoggingDataCharPointer(char *lpszFolder, char *filename, char *lpszTitle, short nSize, char *nValue)
{
	char *lpszBuffer = (char *)malloc( (LOGGING_VALUE_LENGTH*nSize+50)*sizeof(char) );
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[LOGGING_VALUE_LENGTH];
		sprintf(Temp, "%c", nValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, "");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) free(lpszBuffer);
}

long CharA_In_CharB(char* A, long lengthA, char* B, long lengthB)
{
	long i,j,k;
	long in_flag = 0;
	for (i = 0 ; i < lengthB; i++)
	{
		if (B[i] == A[0])
		{
			k = 1 ;
			for (j = 1 ; j < lengthA; j++)
			{
				if (i+j < lengthB)
				{
					if (B[i+j] == A[j])
						k +=1;
					else 
						break;
				}
			}
			if (k == lengthA)
			{
				in_flag = 1;
				break;
			}
		}
	}
	return in_flag;
}

long Check_HDD_Serial_Num(char* szModuleName,char* szFileName, long TextFlag)
{
	// ��밡���� ����� �� = 5
	HDD_INFO* HDD_List = (HDD_INFO*)malloc(sizeof(HDD_INFO) * 5);

	// 0x1000 = 4096 �˳��ϰ� �Ҵ��ϴµ�
	static BYTE buffer[0x1000];

	WCHAR path[] = L"\\\\.\\PhysicalDrive0";

	STORAGE_DEVICE_DESCRIPTOR* descriptor = (STORAGE_DEVICE_DESCRIPTOR*)buffer;
	STORAGE_PROPERTY_QUERY p = { StorageDeviceProperty, PropertyStandardQuery };
	DWORD retn;
	DWORD len = wcslen(path);

	long i = 0;
	long j = 0;

	long length_char;
	long ASCIICODE;
	while (true)
	{
		HANDLE hDisk = CreateFileW(path, 0, FILE_SHARE_READ | FILE_SHARE_WRITE, NULL, OPEN_EXISTING, 0, NULL);

		if (hDisk == INVALID_HANDLE_VALUE) break;

		if (!DeviceIoControl(hDisk, IOCTL_STORAGE_QUERY_PROPERTY, &p, sizeof(p), buffer, sizeof(buffer), &retn, 0)) break;

		length_char = 0;
		for (i=0; i < 100; i++)
		{
			// �ƽ�Ű 48~57: ���� 0~9
			// �ƽ�Ű 65~90: ���� �빮�� A~Z
			// �ƽ�Ű 97~122: ���� �ҹ��� a~z

			ASCIICODE = (int)(buffer + descriptor->SerialNumberOffset)[i];
			if ( (ASCIICODE >= 48 && ASCIICODE <= 57) || (ASCIICODE >= 65 && ASCIICODE <= 90) || (ASCIICODE >= 97 && ASCIICODE <= 122) ) 
			{	
				length_char++;
			}
			
		}

		CloseHandle(hDisk);
		path[len - 1]++;

		(HDD_List + j)->Set_HDD_Info_From_BYTE(length_char, buffer + descriptor->SerialNumberOffset);

		if (TextFlag == 1) LoggingDataCharPointer(szModuleName, szFileName, "HDD_Serial_Number",((HDD_List + j)->length_HDD_Serial), (HDD_List + j)->HDD_Serial);
		
		j++;
	}

	long temp_result = 0;
	
	for (i = 0; i < j; i++)
		temp_result = max(temp_result, check_serial(HDD_List)); // �� ���� 1�̸� 1

	for (i = 0 ; i < j; i++)
		(HDD_List + i)->Erase_HDD_Info();

	delete HDD_List;

	return temp_result;
}