#ifdef WIN32
#include "stdafx.h"
#include <direct.h>
#endif 

#include <stdlib.h>
#include <math.h>
#include "Utility.h"
#include <stdio.h>
#include <string.h>
#include <locale.h>

// Linear_interpolation_2D �Լ����� ���� ���� //2017 05 16


// 0�� 1������ ���� �߻�
double ran1(long *idum, long &iy, long *iv)
{
	long j;
	long k;
	//static long iy = 0;
	//static long iv[NTAB];
	double temp;

	if (*idum<=0 || !iy) {
		if (-(*idum)<1) *idum = 1;
		else *idum = -(*idum);
		for (j=NTAB+7;j>=0;j--) {
			k = (*idum)/IQ;
			*idum = IA*(*idum-k*IQ)-IR*k;
			if(*idum<0) *idum += IM;
			if (j<NTAB) iv[j] = *idum;
		}
		iy = iv[0];
	}
	k = (*idum)/IQ;
	*idum = IA*(*idum-k*IQ)-IR*k;
	if (*idum<0) *idum += IM;
	j = iy/NDIV;
	iy = iv[j];
	iv[j] = *idum;
	if ((temp=AM*iy)>RNMX) return RNMX;
	else return temp;
}

// ǥ�����Ժ��� ���� �߻���
// init=0�̸� �ʱ�ȭ
double randn(long init, long &idum, long &iset, double &gset, long &iy, long *iv)
{
	//static long idum = -1;
	//static long iset = 0;
	//static double gset = 0.0;
	double fac, rsq, v1, v2;

	if (init==0) {
		idum = -1;
		iset = 0;
		gset = 0.0;
	}

	if (iset==0) {
		do {
			v1 = 2.0*ran1(&idum, iy, iv)-1.0;
			v2 = 2.0*ran1(&idum, iy, iv)-1.0;
			rsq = v1*v1+v2*v2;
		} while (rsq>=1.0 || rsq==0);
		fac = sqrt(-2.0*log(rsq)/rsq);
		gset = v1*fac;
		iset = 1;
		return v2*fac;
	}
	else {
		iset = 0;
		return gset;
	}
}

void Chol_Decomp(double **A, double **L, long n)
{
	//AFX_MANAGE_STATE(AfxGetStaticModuleState());
	
	long i,j,k;
	double sum;
	double eps = 1.0e-10;

	for (i=0;i<n;i++) 
	{
		for (j=0;j<n;j++) 
		{
			L[i][j] = A[i][j];
		}
	}

	for (i=0;i<n;i++) 
	{
		for (j=0;j<n;j++) 
		{
			sum = A[i][j];
			for (k=i-1;k>=0;k--) sum -= L[i][k]*L[j][k];
			if (i==j) {
				if (sum<=0.0) sum = eps;
				L[i][i]=sqrt(sum);
			}
			else L[j][i]=sum/L[i][i];
		}
	}

	for (i=0;i<n;i++) 
	{
		for (j=i+1;j<n;j++) 
		{
			L[i][j] = 0.0;
		}
	}

}

// ���� ������ ��� �Լ�
// t[0], t[1], ... , t[nt-1] ������ ������ r[0], r[1], ... , r[nt-1]�� ���� �־���
// t[0] < t[1] < ... < t[nt-1]�̶� ����
// i=0,1, ... , nDates-1�� ��, i�Ϻ��� (i+1)�� ������ ���� �������� f[i]�� ������
long Calc_Forward_Rate(
					double *t, 
					double *r, 
					long nt, 
					double *f, 
					long nDates
)
{
	long i, j;
	double ct;
	double r1, r2;
	double dt = 1.0/365.0;

	if (dt<=t[0]) {
		r2 = r[0];
		f[0] = r2;
	}
	else if (dt>=t[nt-1]) {
		r2 = r[nt-1];
		f[0] = r2;
	}
	else {
		for (j=0;j<nt-1;j++) {
			if (dt>=t[j] && dt<t[j+1]) break;
		}
		r2 = (r[j+1]-r[j])/(t[j+1]-t[j])*(dt-t[j])+r[j];	// ��������
		f[0] = r2;
	}

	for (i=1;i<nDates;i++) {
		r1 = r2;
		ct = (i+1)*dt;

		if (ct<=t[0]) {
			r2 = r[0];
		}
		else if (ct>=t[nt-1]) {
			r2 = r[nt-1];
		}
		else {
			for (j=0;j<nt-1;j++) {
				if (ct>=t[j] && ct<t[j+1]) break;
			}
			r2 = (r[j+1]-r[j])/(t[j+1]-t[j])*(ct-t[j])+r[j];	// ��������
		}

		f[i] = (i+1)*r2-i*r1;		// ���� ������ ���
	}

	return nDates;
}

// ������ ��� �Լ�
double Calc_Disc_Factor(
					double *t, 
					double *r, 
					long nt, 
					double ct)
{
	long j;

	if (ct<=t[0]) return exp(-r[0]*ct);
	else if (ct>=t[nt-1]) return exp(-r[nt-1]*ct);
	else {
		for (j=0;j<nt-1;j++) {
			if (ct>=t[j] && ct<t[j+1]) break;
		}
		return exp(-ct*((r[j+1]-r[j])/(t[j+1]-t[j])*(ct-t[j])+r[j]));	// ��������
	}
}

// ���� ������(Local Volatility) ��� �Լ�
// t[0], t[1], ... , t[nt-1] ������ ������ vol[0], vol[1], ... , vol[nt-1]�� ���� �־���
// t[0] < t[1] < ... < t[nt-1]�̶� ����
// i=0,1, ... , nDates-1�� ��, i�Ϻ��� (i+1)�� ������ ���� �������� vol[i]�� ������
//
//		loc_vol12 * loc_vol12 = (t2 * vol2 * vol2 - t1 * vol1 * vol1) / (t2 - t1)	
//
long Calc_Local_Volatility(
					double *t, 
					double *vol, 
					long nt, 
					double *loc_vol, 
					long nDates
)
{
	long i, j;
	double ct;
	double vol1, vol2;
	double dt = 1.0/365.0;

	if (dt<=t[0]) {
		vol2 = vol[0];
		loc_vol[0] = vol2;
	}
	else if (dt>=t[nt-1]) {
		vol2 = vol[nt-1];
		loc_vol[0] = vol2;
	}
	else {
		for (j=0;j<nt-1;j++) {
			if (dt>=t[j] && dt<t[j+1]) break;
		}
		// �������� ������ ��������
		vol2 = sqrt((vol[j+1]*vol[j+1]-vol[j]*vol[j])/(t[j+1]-t[j])*(dt-t[j])+vol[j]*vol[j]);	
		loc_vol[0] = vol2;
	}

	for (i=1;i<nDates;i++) {
		vol1 = vol2;
		ct = (i+1)*dt;

		if (ct<=t[0]) {
			vol2 = vol[0];
		}
		else if (ct>=t[nt-1]) {
			vol2 = vol[nt-1];
		}
		else {
			for (j=0;j<nt-1;j++) {
				if (ct>=t[j] && ct<t[j+1]) break;
			}
			// �������� ������ ��������
			vol2 = sqrt((vol[j+1]*vol[j+1]-vol[j]*vol[j])/(t[j+1]-t[j])*(ct-t[j])+vol[j]*vol[j]);	
		}

		loc_vol[i] = sqrt((i+1) * vol2*vol2 - i * vol1*vol1);		// ���� ������ ���
	}

	return nDates;
}
/*
void LoggingData(char *lpszFolder, char *filename, char *buf1)
{
	char *lpszPath = new char[strlen(lpszFolder)+strlen(filename)+5];
	sprintf(lpszPath, "%s\\%s", lpszFolder, filename);
	_mkdir(lpszFolder);

//	char	lpszBuffer[100000];
	char *lpszBuffer = new char[strlen(buf1)+10];
	strcpy(lpszBuffer, buf1);
	strcat(lpszBuffer, "\r\n");

	FILE *fp = fopen(lpszPath, "a+");
	{
		fputs(lpszBuffer, fp);
 		fclose(fp);
	}

	if(lpszPath)
		delete [] lpszPath;
	if(lpszBuffer) 
		delete [] lpszBuffer;
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, double *dblValue)
{
	char *lpszBuffer = new char[25*nSize+10];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[50];
		sprintf(Temp, "%f", dblValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) 
		delete [] lpszBuffer;
}

void LoggingDataArray(char *lpszFolder, char *filename, char *lpszTitle, long nSize, long *nValue)
{
	char *lpszBuffer = new char[25*nSize+10];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	for(int i = 0; i < nSize; i ++)
	{
		char Temp[50];
		sprintf(Temp, "%d", nValue[i]);

		strcat(lpszBuffer, Temp);

		if(i < nSize-1)
			strcat(lpszBuffer, ", ");
	}

	LoggingData(lpszFolder, filename, lpszBuffer);
	if(lpszBuffer) 
		delete [] lpszBuffer;
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, double dblValue)
{
	char lpszBuffer[2000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[50];
	sprintf(Temp, "%f", dblValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}

void LoggingData(char *lpszFolder, char *filename, char *lpszTitle, long nValue)
{
	char lpszBuffer[5000];
	sprintf(lpszBuffer, "%s : ", lpszTitle);

	
	char Temp[50];
	sprintf(Temp, "%d", nValue);

	strcat(lpszBuffer, Temp);

	LoggingData(lpszFolder, filename, lpszBuffer);
}
*/


long Calc_Local_Volatility_2D(
					double *t, 
					double *parity, 
					double *vol, 
					long nt, 
					long n_parity,
					double **loc_vol, 
					double *S,
					long nS,
					long nDates
)
{
	long k, i, j;
	double ct;
	double vol1, vol2;
	double dt = 1.0/365.0;
	double *vol_mat;
	double eps = 1.0E-8;

	vol_mat = (double *)malloc(nt*sizeof(double));

	for (k=0;k<nS;k++) {
		if (S[k]<=parity[0]) {
			for (i=0;i<nt;i++) 
				vol_mat[i] = vol[i];
		}
		else if (S[k]>=parity[n_parity-1]) {
			for (i=0;i<nt;i++) 
				vol_mat[i] = vol[(n_parity-1)*nt+i];
		}
		else {
			for (j=0;j<n_parity-1;j++) {
				if (S[k]>=parity[j] && S[k]<parity[j+1]) break;
			}
			
			for (i=0;i<nt;i++) 
				// Parity�� ���������Ͽ� S[k]�� �ش�Ǵ� VolCurve�� vol_mat�� ����
				vol_mat[i] = (vol[(j+1)*nt+i]-vol[j*nt+i])/(parity[j+1]-parity[j])*(S[k]-parity[j])+vol[j*nt+i];	
		}

		if (dt<=t[0]) {
			vol2 = vol_mat[0];
			loc_vol[k][0] = vol2;
		}
		else if (dt>=t[nt-1]) {
			vol2 = vol_mat[nt-1];
			loc_vol[k][0] = vol2;
		}
		else {
			for (j=0;j<nt-1;j++) {
				if (dt>=t[j] && dt<t[j+1]) break;
			}
			// �������� ������ ��������
			vol2 = sqrt((vol_mat[j+1]*vol_mat[j+1]-vol_mat[j]*vol_mat[j])/(t[j+1]-t[j])*(dt-t[j])+vol_mat[j]*vol_mat[j]);	
			loc_vol[k][0] = vol2;
		}

		for (i=1;i<nDates;i++) {
			vol1 = vol2;
			ct = (i+1)*dt;

			if (ct<=t[0]) {
				vol2 = vol_mat[0];
			}
			else if (ct>=t[nt-1]) {
				vol2 = vol_mat[nt-1];
			}
			else {
				for (j=0;j<nt-1;j++) {
					if (ct>=t[j] && ct<t[j+1]) break;
				}
				// �������� ������ ��������
				vol2 = sqrt((vol_mat[j+1]*vol_mat[j+1]-vol_mat[j]*vol_mat[j])/(t[j+1]-t[j])*(ct-t[j])+vol_mat[j]*vol_mat[j]);	
			}

			// Local Volatility�� ���
			if ((i+1)*vol2*vol2-i*vol1*vol1<eps) {
				loc_vol[k][i] = sqrt(eps);
			}
			else {
				loc_vol[k][i] = sqrt((i+1)*vol2*vol2-i*vol1*vol1);
			}
		}
	}

	if(vol_mat) free(vol_mat);

	return nDates;
}


// Ư�� ������ Zero Rate ���
double Calc_Zero_Rate(
					double *t, 
					double *r, 
					short nt,
					double ct
)
{
	short j;
	double dt = 1.0/365.0;

	if (ct<=t[0]) return r[0];
	else if (ct>=t[nt-1]) return r[nt-1];
	else {
		for (j=0;j<nt-1;j++) {
			if (ct>=t[j] && ct<t[j+1]) break;
		}
		return (r[j+1]-r[j])/(t[j+1]-t[j])*(ct-t[j])+r[j];	// ��������
	}
}


double Linear_interpolation_2D(
	double value, 
	long n_vol, 
	double *t_vol, 
	long n_parity, 
	double *parity, 
	double date,
	double **vol,
	long *time_pos,
	long *parity_pos,
	long parity_interval_flag
)
{
	int i;
	int t_vol_pos1=0;
	int t_vol_pos2=0;
	int parity_pos1=0;
	int parity_pos2=0;
	double interp_value = 0;
	double alpha1=0, alpha2=0;
	long time_pos_limit = n_vol - *time_pos;

	if(value <=  parity[0] || n_parity == 1)
	{
		parity_pos1 = 0;
		parity_pos2 = 0;
		*parity_pos = 0;
	}
	else if(value >= parity[n_parity-1])
	{
		parity_pos1 = n_parity-1;
		parity_pos2 = n_parity-1;
		*parity_pos = n_parity-1;
	}
	else 
	{
		if(parity_interval_flag==1)
		{
			parity_pos1 = (int)( (value-parity[0])/(parity[1]-parity[0]) );
			parity_pos2 = parity_pos1 + 1;
		}
		else
		{
			parity_pos2 = *parity_pos;
			if(value<parity[*parity_pos])
			{
				for(i=0;i<n_parity;i++)
				{
					parity_pos2--;
					if(value>=parity[parity_pos2])
					{
						parity_pos1 = parity_pos2;
						parity_pos2++;
						*parity_pos = parity_pos2;
						break;
					}
				}
			}
			else if(value==parity[*parity_pos])
			{
				(*parity_pos)++;		//2017 05 16
				parity_pos1 = *parity_pos-1;
				parity_pos2 = *parity_pos;
			}
			else // value>parity[*parity_pos]
			{
				for(i=0;i<n_parity;i++)
				{
					parity_pos2++;
					if(value<parity[parity_pos2])
					{
						*parity_pos = parity_pos2;
						parity_pos1 = parity_pos2-1;
						break;
					}
				}
			}
		}
	}



	if(date <= t_vol[0] || n_vol==1)
	{
		t_vol_pos1 = 0;
		t_vol_pos2 = 0;
		*time_pos = 0;
	}
	else if( date >= t_vol[n_vol-1])
	{
		t_vol_pos1 = n_vol-1;
		t_vol_pos2 = n_vol-1;
		*time_pos = n_vol-1;
	}
	else
	{
		t_vol_pos2 = *time_pos;
		for(i=0;i<time_pos_limit;i++)
		{
			if(date>=t_vol[t_vol_pos2])
			{
				t_vol_pos2++;
			}
			else
			{
				break;
			}
		}
		t_vol_pos1 = t_vol_pos2-1;
		*time_pos = t_vol_pos2;
	}
	
	if(parity_pos1 != parity_pos2)
		alpha1 = (value-parity[parity_pos1])/(parity[parity_pos2]-parity[parity_pos1]);
	else 
		alpha1 = 1;

	if(t_vol_pos1 != t_vol_pos2)
		alpha2 = (date-t_vol[t_vol_pos1])/(t_vol[t_vol_pos2]-t_vol[t_vol_pos1]);
	else 
		alpha2 = 1;


	interp_value =		(1-alpha1)*(1-alpha2)*vol[parity_pos1][t_vol_pos1]
					+	(1-alpha1)*alpha2*vol[parity_pos1][t_vol_pos2]
					+	alpha1*(1-alpha2)*vol[parity_pos2][t_vol_pos1]
					+	alpha1*alpha2*vol[parity_pos2][t_vol_pos2];

	return interp_value;


}


double Linear_Interpolation_1D(double *TVol, double *Vol, long NVol, double Time ) 
{
	long i = 0;
	double Interp_Vol = 0.0;

	if(Time <= TVol[0])
	{
		Interp_Vol = Vol[0];
	}
	else if(Time >= TVol[NVol-1]) 
	{
		Interp_Vol = Vol[NVol-1];
	}
	else
	{
		for(i=1;i<NVol;i++)
		{
			if(Time<TVol[i]) 
			{
				Interp_Vol = (Vol[i] - Vol[i-1])/(TVol[i] - TVol[i-1]) * (Time - TVol[i-1]) + Vol[i-1];
				break;
			}
		}
	}

	return Interp_Vol;
	
}


// Forward �ܸ� Daily ��� Act/365 ����
long Calc_ForwardRate_Daily_Year(
	double *Tf,					// IN:  Interest Term
	double *Rf,					// IN:  Interest Rate
	long NT,					// IN:  Interest Term ����
	long NDates,				// IN:  ��� ���ڼ�
	long ForwardRateType,		// IN:  0 : ���Ӻ���, 1 : �ܸ�
	double *ForwardRate_Daily	// OUT: �ܸ��� ���� Daily Forward Rate
)
{
	long i, j;
	long ResultCode = 1;

	double T0 = 0.0;
	double T1 = 0.0;
	long Interp_Idx = 0;
	double *DailyRate_Interp = (double*)malloc(NDates*sizeof(double));
	
	for (i=0;i<NDates;i++)
	{
		T0 = (double)i / 365.0;
		T1 = (double)(i+1) / 365.0;

		// T0 Interpolation
		if(T0<=Tf[0])
		{
			DailyRate_Interp[i] = Rf[0];
		}
		else if(T0>=Tf[NT-1])
		{
			DailyRate_Interp[i] = Rf[NT-1];
		}
		else
		{
			for(j=1;j<NT;j++)
			{
				if(T0<=Tf[j])
				{
					Interp_Idx = j;
					break;
				}
			}
			DailyRate_Interp[i] = (Rf[Interp_Idx]-Rf[Interp_Idx-1])/(Tf[Interp_Idx]-Tf[Interp_Idx-1])*(T0-Tf[Interp_Idx-1]) + Rf[Interp_Idx-1];
		}

		// T1 Interpolation
		if(T1<=Tf[0])
		{
			DailyRate_Interp[i] = Rf[0];
		}
		else if(T1>=Tf[NT-1])
		{
			DailyRate_Interp[i] = Rf[NT-1];
		}
		else
		{
			for(j=1;j<NT;j++)
			{
				if(T1<=Tf[j])
				{
					Interp_Idx = j;
					break;
				}
			}
			DailyRate_Interp[i] = (Rf[Interp_Idx]-Rf[Interp_Idx-1])/(Tf[Interp_Idx]-Tf[Interp_Idx-1])*(T1-Tf[Interp_Idx-1]) + Rf[Interp_Idx-1];
		}
		
		if(ForwardRateType==0)
		{
			if(i==0)
			{
				ForwardRate_Daily[0] = DailyRate_Interp[0];
			}
			else
			{
				ForwardRate_Daily[i] = DailyRate_Interp[i]*(double)(i+1)-DailyRate_Interp[i-1]*(double)i;
			}
		}
		else
		{
			if(i==0)
			{
				ForwardRate_Daily[0] = (exp(DailyRate_Interp[0]/365.0) - 1) * 365.0;
			}
			else
			{
				ForwardRate_Daily[i] = ( exp( (DailyRate_Interp[i]*(double)(i+1)-DailyRate_Interp[i-1]*(double)i)/365.0 ) - 1 ) * 365.0;
			}
		}
	}

	if(DailyRate_Interp) free(DailyRate_Interp);

	return ResultCode;
}


// ������ 1�� �������� Act/365 �����Ͽ� Convenience Yield ���
long ConvenienceYield_Daily_Year(
	double S0,					// IN:  ���� ���� (Spot)
	double *ForwardTerm_Year,	// IN:  ���� ���� �Ⱓ����, ù��° ������ �ݵ�� Spot������ ���;� ��(Ref Curve�� Daycount Convention�� ���ٰ� ����)
	double *ForwardPrice,		// IN:  ���� ���� 
	long NForwardTerm,			// IN:  ���� ���� ��
	double *RFCrvTerm,			// IN:  ���� ������ݸ� �Ⱓ����
	double *RFCrvRate,			// IN:  ���� ������ݸ� 
	long NRFCrvTerm,			// IN:  ���� ������ݸ� �Ⱓ���� ����
	long ForwardRateType,		// IN:  ���� �ݸ� Type ( 0 : ���Ӻ���, 1 : �ܸ�)
	long NDate,					// IN:  ��������ϱ����� �ϼ�
	double *CvYield_Day			// OUT: 1�� �������� ���� CvYield_Day
)
{
	long ResultCode = 1;
	long i;

	double *RFRate_Day_Interp = (double*)malloc(NDate*sizeof(double));
	double *RFRate_Forward_Day = (double*)malloc(NDate*sizeof(double));
	double *ForwardPrice_Day = (double*)malloc(NDate*sizeof(double));

	for(i=0;i<NDate;i++)
	{
		RFRate_Day_Interp[i] = Linear_Interpolation_1D(RFCrvTerm, RFCrvRate, NRFCrvTerm, (i+1)/365.0); // Risk Free Rate Interpolation
		ForwardPrice_Day[i] = Linear_Interpolation_1D(ForwardTerm_Year, ForwardPrice, NForwardTerm, (i+1)/365.0); // Risk Free Rate Interpolation
		
		if(ForwardRateType==0)
		{
			if(i==0)
			{
				RFRate_Forward_Day[0] = RFRate_Day_Interp[0];

				CvYield_Day[0] =  -( log(ForwardPrice_Day[0]/S0) * 365.0 - RFRate_Forward_Day[0]);
			}
			else
			{	// i-1 ~ i �����ݸ� ���
				RFRate_Forward_Day[i] = RFRate_Day_Interp[i] * (i+1) - RFRate_Day_Interp[i-1] * i;

				CvYield_Day[i] =  -( log(ForwardPrice_Day[i]/ForwardPrice_Day[i-1]) * 365.0 - RFRate_Forward_Day[i] );
			}
		}
		else
		{
			if(i==0)
			{
				RFRate_Forward_Day[0] = RFRate_Day_Interp[0];

				CvYield_Day[0] =  ( exp(RFRate_Forward_Day[i]/365.0 - log(ForwardPrice_Day[i]/S0)) - 1 ) * 365.0;
			}
			else
			{	// i-1 ~ i �����ݸ� ���
				RFRate_Forward_Day[i] = RFRate_Day_Interp[i] * (i+1) - RFRate_Day_Interp[i-1] * i;

				CvYield_Day[i] =  ( exp(RFRate_Forward_Day[i]/365.0 - log(ForwardPrice_Day[i]/ForwardPrice_Day[i-1])) - 1 ) * 365.0;
			}
		}
	}

	if(RFRate_Day_Interp) free(RFRate_Day_Interp);
	if(RFRate_Forward_Day) free(RFRate_Forward_Day);
	if(ForwardPrice_Day) free(ForwardPrice_Day);

	return ResultCode;
}


