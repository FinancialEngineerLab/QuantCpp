
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct struct_hdd{
	long length_HDD_Serial;
	char* HDD_Serial;

	void Set_HDD_Info_From_BYTE(long HDD_Serial_Length, BYTE* buffer)
	{
		long i,k=0;
		long ASCIICODE;
		length_HDD_Serial = HDD_Serial_Length;
		HDD_Serial = (char*)malloc(sizeof(char) * length_HDD_Serial);
		for (i = 0 ; i < 100; i++)
		{
			// �ƽ�Ű 48~57: ���� 0~9
			// �ƽ�Ű 65~90: ���� �빮�� A~Z
			// �ƽ�Ű 97~122: ���� �ҹ��� a~z

			ASCIICODE = (int)(buffer[i]);
			if ( (ASCIICODE >= 48 && ASCIICODE <= 57) || (ASCIICODE >= 65 && ASCIICODE <= 90) || (ASCIICODE >= 97 && ASCIICODE <= 122))
			{
				HDD_Serial[k] = (char)buffer[i];
				k++;
				if (k >= HDD_Serial_Length) break;
			}
		}
	}
	void Erase_HDD_Info()
	{
		if (HDD_Serial) free(HDD_Serial);
	}
}HDD_INFO;

void LoggingDataCharPointer(char *lpszFolder, char *filename, char *lpszTitle, short nSize, char *nValue);
long CharA_In_CharB(char* A, long lengthA, char* B, long lengthB);
int check_serial(HDD_INFO* HDD_Nth);
long Check_HDD_Serial_Num(char* szModuleName,char* szFileName, long TextFlag);