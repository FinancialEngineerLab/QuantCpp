#ifndef __EXPIRYDATE_HPP
#define __EXPIRYDATE_HPP

#include<iostream>
#include<ctime>
#include"Date.h"

namespace KISQuantLib {
	class ExpiryDate
	{
	private :
		Date *expirydate;
		long AVAIL;									//0�̸� ����, 1�̸� ��ȿ

		long getToday();
	public :
		ExpiryDate(long expiry) {
			expirydate = new Date(expiry);
			Date *Today = new Date(getToday());

			if(*expirydate < *Today) {
				AVAIL = 0;
			} else {
				AVAIL = 1;
			}

			delete Today;
		}
		~ExpiryDate();

		long getAVAIL();
	};
}
#endif